/**
 * LERZA PLAYER PRO — PROFESSIONAL FIREBASE ADMIN DASHBOARD (app.js)
 * Real-time Cloud Firestore synchronization, Chart.js analytics,
 * AdMob monetization controls, remote user blocking, and FCM composer.
 */

// Official Firebase Web SDK Modular Imports via CDN
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { 
  getAuth, 
  signInAnonymously, 
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { 
  getFirestore, 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc, 
  addDoc, 
  serverTimestamp, 
  query, 
  orderBy, 
  limit 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// ============================================================
// 1. FIREBASE INITIALIZATION WITH VERIFIED PRODUCTION KEYS
// ============================================================
// Verified Default Firebase Project Credentials from google-services.json
const DEFAULT_FIREBASE_CONFIG = {
  apiKey: "AIzaSyB4GgV7ukR8TfCWmarUqYORkxMnh4ECFto",
  authDomain: "lerzaplayer-control.firebaseapp.com",
  projectId: "lerzaplayer-control",
  storageBucket: "lerzaplayer-control.firebasestorage.app",
  messagingSenderId: "357463599199",
  appId: "1:357463599199:web:5feee33eaa41f8e7de13ea",
  measurementId: "G-08KP82M3B5"
};

// Verified Default Configuration Schema matching remote_config_template.json
const DEFAULT_APP_CONFIG = {
  enable_equalizer: true,
  enable_sleep_timer: true,
  enable_feedback_system: true,
  enable_playtime_tracking: true,
  maintenance_mode: false,
  update_popup_enabled: false,
  latest_app_version_code: 4,
  update_website_url: "https://lerzaplayer.vercel.app",
  announcement_banner_text: "",
  announcement_banner_link: ""
};

const DEFAULT_AD_CONFIG = {
  show_all_ads: true,
  remove_all_ads: false,
  test_ads_enabled: false,
  banner_ad_unit_id: "ca-app-pub-7375534389683057/9757608460",
  enable_bottom_banner_ad: true,
  app_open_ad_unit_id: "ca-app-pub-7375534389683057/3906515984",
  enable_app_open_ad: true,
  interstitial_ad_unit_id: "ca-app-pub-7375534389683057/1823278127",
  enable_settings_click_ad: true,
  native_ad_unit_id: "ca-app-pub-7375534389683057/8388686475",
  enable_player_thumbnail_ad: true,
  enable_songs_list_ad: true,
  enable_videos_list_ad: true,
  rewarded_ad_unit_id: "ca-app-pub-7375534389683057/7678240038",
  enable_vault_reward_ad: true,
  interstitial_ad_frequency_clicks: 4,
  interstitial_ad_cooldown_seconds: 30,
  app_open_frequency_interval: 3,
  app_open_ad_cooldown_seconds: 30
};

// Support saved local configuration override if admin customized credentials in UI
function getActiveFirebaseConfig() {
  try {
    const saved = localStorage.getItem("lerza_custom_firebase_cfg");
    if (saved) return { ...DEFAULT_FIREBASE_CONFIG, ...JSON.parse(saved) };
  } catch (e) {
    console.warn("Error parsing custom config:", e);
  }
  return DEFAULT_FIREBASE_CONFIG;
}

const firebaseConfig = getActiveFirebaseConfig();
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Application State Store
const state = {
  devices: [],
  notifications: [],
  feedback: [],
  force_update_required: false,
  auditLogs: [],
  appConfig: { ...DEFAULT_APP_CONFIG },
  adConfig: { ...DEFAULT_AD_CONFIG },
  currentUser: null,
  charts: {
    playtime: null,
    version: null
  },
  unsubscribeListeners: []
};

// ============================================================
// 2. DOM ELEMENTS & ROUTING
// ============================================================
const elements = {
  pages: document.querySelectorAll('.page-view'),
  navItems: document.querySelectorAll('.nav-item'),
  currentBreadcrumb: document.getElementById('currentBreadcrumb'),
  syncStatusText: document.getElementById('syncStatusText'),
  lastSyncTime: document.getElementById('lastSyncTime'),
  themeToggleBtn: document.getElementById('themeToggleBtn'),
  themeIcon: document.getElementById('themeIcon'),
  sidebar: document.getElementById('sidebar'),
  sidebarToggle: document.getElementById('sidebarToggle'),
  mobileMenuBtn: document.getElementById('mobileMenuBtn'),
  manualRefreshBtn: document.getElementById('manualRefreshBtn'),
  adminEmailDisplay: document.getElementById('adminEmailDisplay'),
  logoutBtn: document.getElementById('logoutBtn'),
  toastContainer: document.getElementById('toastContainer'),
  confirmModal: document.getElementById('confirmModal'),
  modalTitle: document.getElementById('modalTitle'),
  modalMessage: document.getElementById('modalMessage'),
  modalConfirmBtn: document.getElementById('modalConfirmBtn'),
  modalCancelBtn: document.getElementById('modalCancelBtn'),
  
  // KPI Display
  kpiTotalDevices: document.getElementById('kpiTotalDevices'),
  kpiActive24h: document.getElementById('kpiActive24h'),
  kpiActivePercentage: document.getElementById('kpiActivePercentage'),
  kpiTotalMusicHours: document.getElementById('kpiTotalMusicHours'),
  kpiTodayMusicMinutes: document.getElementById('kpiTodayMusicMinutes'),
  kpiTotalVideoHours: document.getElementById('kpiTotalVideoHours'),
  navUserCount: document.getElementById('navUserCount'),
  tableDeviceCount: document.getElementById('tableDeviceCount'),

  // Tables
  devicesTableBody: document.getElementById('devicesTableBody'),
  overviewRecentDevicesBody: document.getElementById('overviewRecentDevicesBody'),
  overviewAdList: document.getElementById('overviewAdList'),
  notificationsHistoryBody: document.getElementById('notificationsHistoryBody'),
  auditLogsBody: document.getElementById('auditLogsBody'),

  // Filters & Search
  userSearchInput: document.getElementById('userSearchInput'),
  userStatusFilter: document.getElementById('userStatusFilter'),

  // Notification Composer Elements
  notifTitle: document.getElementById('notifTitle'),
  notifBody: document.getElementById('notifBody'),
  notifImage: document.getElementById('notifImage'),
  notifLink: document.getElementById('notifLink'),
  notifTargetAudience: document.getElementById('notifTargetAudience'),
  notifCountryGroup: document.getElementById('notifCountryGroup'),
  notifTargetCountry: document.getElementById('notifTargetCountry'),
  notifDeviceGroup: document.getElementById('notifDeviceGroup'),
  notifTargetDeviceId: document.getElementById('notifTargetDeviceId'),
  notifDeviceQuickSelect: document.getElementById('notifDeviceQuickSelect'),
  testNotifBtn: document.getElementById('testNotifBtn'),
  sendNotifBtn: document.getElementById('sendNotifBtn'),
  previewTitleDisplay: document.getElementById('previewTitleDisplay'),
  previewBodyDisplay: document.getElementById('previewBodyDisplay'),
  previewImgBox: document.getElementById('previewImgBox'),
  previewImgElement: document.getElementById('previewImgElement'),

  // Announcements
  announcementText: document.getElementById('announcementText'),
  announcementLink: document.getElementById('announcementLink'),
  announcementActive: document.getElementById('announcementActive'),
  announcementTargetAudience: document.getElementById('announcementTargetAudience'),
  announcementCountryGroup: document.getElementById('announcementCountryGroup'),
  announcementTargetCountry: document.getElementById('announcementTargetCountry'),
  announcementDeviceGroup: document.getElementById('announcementDeviceGroup'),
  announcementTargetDeviceId: document.getElementById('announcementTargetDeviceId'),
  announcementDeviceQuickSelect: document.getElementById('announcementDeviceQuickSelect'),
  announcementMockupText: document.getElementById('announcementMockupText'),
  publishAnnouncementBtn: document.getElementById('publishAnnouncementBtn'),

  // Remote Config Elements
  saveRemoteConfigBtn: document.getElementById('saveRemoteConfigBtn'),
  rcEnableEqualizer: document.getElementById('rcEnableEqualizer'),
  rcEnableSleepTimer: document.getElementById('rcEnableSleepTimer'),
  rcEnableFeedback: document.getElementById('rcEnableFeedback'),
  rcEnablePlaytime: document.getElementById('rcEnablePlaytime'),
  rcMaintenanceMode: document.getElementById('rcMaintenanceMode'),
  rcUpdatePopupEnabled: document.getElementById('rcUpdatePopupEnabled'),
  rcForceUpdateRequired: document.getElementById('rcForceUpdateRequired'),
  notifForceUpdate: document.getElementById('notifForceUpdate'),
  navFeedbackCount: document.getElementById('navFeedbackCount'),
  feedbackTableBody: document.getElementById('feedbackTableBody'),
  feedbackTotalCount: document.getElementById('feedbackTotalCount'),
  feedbackAvgRating: document.getElementById('feedbackAvgRating'),
  feedback5StarCount: document.getElementById('feedback5StarCount'),
  exportFeedbackCsvBtn: document.getElementById('exportFeedbackCsvBtn'),
  searchFeedbackInput: document.getElementById('searchFeedbackInput'),
  rcLatestVersionCode: document.getElementById('rcLatestVersionCode'),
  rcUpdateWebsiteUrl: document.getElementById('rcUpdateWebsiteUrl'),

  // Ad Management Elements
  saveAdConfigBtn: document.getElementById('saveAdConfigBtn'),
  adShowAllAds: document.getElementById('adShowAllAds'),
  adRemoveAllAds: document.getElementById('adRemoveAllAds'),
  adTestAdsEnabled: document.getElementById('adTestAdsEnabled'),
  adIdBanner: document.getElementById('adIdBanner'),
  adEnableBanner: document.getElementById('adEnableBanner'),
  adIdAppOpen: document.getElementById('adIdAppOpen'),
  adEnableAppOpen: document.getElementById('adEnableAppOpen'),
  adIdInterstitial: document.getElementById('adIdInterstitial'),
  adEnableSettingsClick: document.getElementById('adEnableSettingsClick'),
  adIdNative: document.getElementById('adIdNative'),
  adEnableThumbnail: document.getElementById('adEnableThumbnail'),
  adEnableSongsList: document.getElementById('adEnableSongsList'),
  adEnableVideosList: document.getElementById('adEnableVideosList'),
  adIdRewarded: document.getElementById('adIdRewarded'),
  adEnableVaultReward: document.getElementById('adEnableVaultReward'),
  adFreqClicks: document.getElementById('adFreqClicks'),
  adCooldownSec: document.getElementById('adCooldownSec'),
  valFreqClicks: document.getElementById('valFreqClicks'),
  valCooldownSec: document.getElementById('valCooldownSec'),
  adAppOpenInterval: document.getElementById('adAppOpenInterval'),
  adAppOpenCooldownSec: document.getElementById('adAppOpenCooldownSec'),
  valAppOpenInterval: document.getElementById('valAppOpenInterval'),
  valAppOpenCooldownSec: document.getElementById('valAppOpenCooldownSec'),
  adSongsListInterval: document.getElementById('adSongsListInterval'),
  valSongsListInterval: document.getElementById('valSongsListInterval'),
  sidebarBackdrop: document.getElementById('sidebarBackdrop'),
  // Modal and banner elements
  cfgApiKey: document.getElementById('cfgApiKey'),
  cfgAppId: document.getElementById('cfgAppId'),
  cfgProjectId: document.getElementById('cfgProjectId'),
  closeFirebaseBannerBtn: document.getElementById('closeFirebaseBannerBtn'),
  closeFirebaseModalBtn: document.getElementById('closeFirebaseModalBtn'),
  copyFirestoreRulesBtn: document.getElementById('copyFirestoreRulesBtn'),
  exportRemoteConfigBtn: document.getElementById('exportRemoteConfigBtn'),
  firebaseAlertBanner: document.getElementById('firebaseAlertBanner'),
  firebaseBannerActionBtn: document.getElementById('firebaseBannerActionBtn'),
  firebaseBannerText: document.getElementById('firebaseBannerText'),
  firebaseModal: document.getElementById('firebaseModal'),
  firebaseSetupBtn: document.getElementById('firebaseSetupBtn'),
  firestoreRulesCode: document.getElementById('firestoreRulesCode'),
  modalStatusDetailText: document.getElementById('modalStatusDetailText'),
  modalStatusDot: document.getElementById('modalStatusDot'),
  resetDefaultConfigBtn: document.getElementById('resetDefaultConfigBtn'),
  saveCustomConfigBtn: document.getElementById('saveCustomConfigBtn'),
  syncStatusPill: document.getElementById('syncStatusPill'),
};

// ============================================================
// 3. SINGLE-PAGE ROUTING & NAVIGATION
// ============================================================
function navigateToPage(pageId) {
  elements.pages.forEach(page => {
    if (page.id === `page-${pageId}`) {
      page.classList.add('active');
    } else {
      page.classList.remove('active');
    }
  });

  elements.navItems.forEach(item => {
    if (item.dataset.page === pageId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  const pageTitles = {
    overview: 'Executive Overview',
    users: 'Live Device Directory & Analytics',
    'remote-config': 'Remote Configuration',
    ads: 'AdMob Monetization Matrix',
    notifications: 'Push Notification Composer',
    announcements: 'In-App Announcements',
    system: 'System Health & Audit Logs'
  };

  elements.currentBreadcrumb.textContent = pageTitles[pageId] || 'Overview';
  window.location.hash = pageId;

  // Trigger chart resize if navigating to overview
  if (pageId === 'overview' && state.charts.playtime) {
    state.charts.playtime.resize();
    state.charts.version.resize();
  }
}

// ============================================================
// 4. FIREBASE AUTHENTICATION & LISTENERS
// ============================================================
function setFirebaseLiveStatus(isLive, message = '') {
  if (isLive) {
    if (elements.syncStatusPill) elements.syncStatusPill.className = 'sync-status-pill';
    if (elements.syncStatusText) elements.syncStatusText.textContent = 'Firestore Live';
    if (elements.firebaseAlertBanner) elements.firebaseAlertBanner.style.display = 'none';
    if (elements.modalStatusDot) elements.modalStatusDot.style.background = '#10b981';
    if (elements.modalStatusDetailText) elements.modalStatusDetailText.textContent = 'Live connected to Cloud Firestore (Real-time syncing)';
  } else {
    if (elements.syncStatusPill) elements.syncStatusPill.className = 'sync-status-pill error';
    if (elements.syncStatusText) elements.syncStatusText.textContent = 'Rules Blocked (403)';
    if (elements.firebaseAlertBanner) elements.firebaseAlertBanner.style.display = 'flex';
    if (elements.firebaseBannerText) {
      elements.firebaseBannerText.innerHTML = `<strong>Firebase Firestore Blocked:</strong> Missing or insufficient permissions. Please publish Firestore Security Rules in Firebase Console.`;
    }
    if (elements.modalStatusDot) elements.modalStatusDot.style.background = '#ef4444';
    if (elements.modalStatusDetailText) elements.modalStatusDetailText.textContent = message || 'Firebase Permission Denied (403): Update rules in Firebase Console';
  }
}

function handleFirebaseError(err, context = '') {
  console.error(`Firebase error [${context}]:`, err);
  if (err.code === 'permission-denied') {
    setFirebaseLiveStatus(false, 'Missing or insufficient permissions (403). Publish Firestore Rules in Firebase Console.');
    showToast('Firebase Permission Denied! Update Firestore Security Rules.', 'error');
    fetchFirestoreRestFallback();
  } else if (err.code === 'unavailable' || err.code === 'failed-precondition') {
    if (elements.syncStatusPill) elements.syncStatusPill.className = 'sync-status-pill connecting';
    if (elements.syncStatusText) elements.syncStatusText.textContent = 'Offline (Reconnecting via REST...)';
    fetchFirestoreRestFallback();
  }
}

// REST Fallback for network environments with proxy or WebSocket restrictions
async function fetchFirestoreRestFallback() {
  try {
    const cfg = getActiveFirebaseConfig();
    const url = "https://firestore.googleapis.com/v1/projects/" + cfg.projectId + "/databases/(default)/documents/devices?key=" + cfg.apiKey;
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();
    if (!data.documents || !data.documents.length) return;
    const devices = data.documents.map(docItem => {
      const fields = docItem.fields || {};
      const id = docItem.name.split("/").pop();
      const raw = {};
      for (const [k, v] of Object.entries(fields)) {
        raw[k] = v.stringValue !== undefined ? v.stringValue :
                 v.integerValue !== undefined ? Number(v.integerValue) :
                 v.doubleValue !== undefined ? Number(v.doubleValue) :
                 v.booleanValue !== undefined ? v.booleanValue :
                 v.timestampValue !== undefined ? v.timestampValue : null;
      }
      return {
        id,
        device_id: raw.device_id || raw.deviceId || id,
        device_model: raw.device_model || raw.deviceModel || "Unknown Device",
        device_manufacturer: raw.device_manufacturer || raw.manufacturer || "Android",
        android_version: raw.android_version || raw.androidVersion || "Android",
        app_version: raw.app_version || raw.appVersion || "1.0.5",
        country_code: raw.country_code || raw.country || "GLOBAL",
        fcm_token: raw.fcm_token || raw.fcmToken || "",
        audio_playtime_minutes: Number(raw.audio_playtime_minutes ?? raw.audioPlaytimeMinutes ?? 0),
        video_playtime_minutes: Number(raw.video_playtime_minutes ?? raw.videoPlaytimeMinutes ?? 0),
        total_playtime_minutes: Number(raw.total_playtime_minutes ?? raw.totalPlaytimeMinutes ?? 0),
        today_music_minutes: Number(raw.today_music_minutes ?? 0),
        session_count: Number(raw.session_count ?? raw.offlineSessionCount ?? 1),
        is_blocked: Boolean(raw.is_blocked),
        blocked_reason: raw.blocked_reason || "",
        last_active_time: raw.last_active_time || raw.lastActiveTime || null,
        ...raw
      };
    });
    if (devices.length > 0) {
      state.devices = devices;
      setFirebaseLiveStatus(true);
      renderDeviceMetrics();
      renderDevicesTable();
      updateCharts();
      updateSyncTime();
    }
  } catch (e) {
    console.warn("REST fallback note:", e);
  }
}

function initAuth() {
  // 1. Immediately launch Firestore listeners without blocking on authentication
  startRealtimeListeners();

  // 2. Initialize optional admin session in background
  try {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        state.currentUser = user;
        if (elements.adminEmailDisplay) {
          elements.adminEmailDisplay.textContent = user.isAnonymous ? 'Admin (Session Token)' : (user.email || 'Admin');
        }
      } else {
        try {
          await signInAnonymously(auth);
        } catch (err) {
          console.warn('Anonymous auth note (Firestore direct mode active):', err.message);
          if (elements.adminEmailDisplay) {
            elements.adminEmailDisplay.textContent = 'Admin (Direct Firestore)';
          }
        }
      }
    });
  } catch (err) {
    console.warn('Auth state subscription note:', err.message);
  }
}

function startRealtimeListeners() {
  // Cleanup any existing active subscriptions
  state.unsubscribeListeners.forEach(unsub => {
    try { unsub(); } catch(e) {}
  });
  state.unsubscribeListeners = [];

  if (elements.syncStatusPill) elements.syncStatusPill.className = 'sync-status-pill connecting';
  if (elements.syncStatusText) elements.syncStatusText.textContent = 'Connecting...';

  // 1. Devices Listener (Real-Time Users)
  const devicesUnsub = onSnapshot(collection(db, "devices"), (snapshot) => {
    const devices = [];
    snapshot.forEach(docSnap => {
      const raw = docSnap.data() || {};
      const normalized = {
        id: docSnap.id,
        device_id: raw.device_id || raw.deviceId || docSnap.id,
        device_model: raw.device_model || raw.deviceModel || 'Unknown Device',
        device_manufacturer: raw.device_manufacturer || raw.manufacturer || 'Android',
        android_version: raw.android_version || raw.androidVersion || 'Android',
        app_version: raw.app_version || raw.appVersion || '1.0.5',
        country_code: raw.country_code || raw.country || 'GLOBAL',
        fcm_token: raw.fcm_token || raw.fcmToken || '',
        audio_playtime_minutes: Number(raw.audio_playtime_minutes ?? raw.audioPlaytimeMinutes ?? 0),
        video_playtime_minutes: Number(raw.video_playtime_minutes ?? raw.videoPlaytimeMinutes ?? 0),
        total_playtime_minutes: Number(raw.total_playtime_minutes ?? raw.totalPlaytimeMinutes ?? 0),
        today_music_minutes: Number(raw.today_music_minutes ?? 0),
        session_count: Number(raw.session_count ?? raw.offlineSessionCount ?? 1),
        is_blocked: Boolean(raw.is_blocked),
        blocked_reason: raw.blocked_reason || '',
        last_active_time: raw.last_active_time || raw.lastActiveTime || null,
        ...raw
      };
      devices.push(normalized);
    });
    state.devices = devices;
    setFirebaseLiveStatus(true);
    renderDeviceMetrics();
    renderDevicesTable();
    updateCharts();
    updateSyncTime();
  }, (err) => {
    handleFirebaseError(err, 'Devices listener');
    if (elements.devicesTableBody) {
      elements.devicesTableBody.innerHTML = `<tr><td colspan="8" class="table-empty" style="color:#f59e0b;"><i class="fa-solid fa-triangle-exclamation"></i> Firebase Permission Blocked: ${err.message}. Click "Firebase Rules" in topbar to fix rules in Firebase Console.</td></tr>`;
    }
  });
  state.unsubscribeListeners.push(devicesUnsub);

  // 2. Notification Campaigns Listener
  const notifQuery = query(collection(db, "notifications"), orderBy("created_at", "desc"), limit(20));
  const notifUnsub = onSnapshot(notifQuery, (snapshot) => {
    const notifs = [];
    snapshot.forEach(docSnap => {
      notifs.push({ id: docSnap.id, ...docSnap.data() });
    });
    state.notifications = notifs;
    renderNotificationHistory();
  }, (err) => {
    console.warn('Notifications listener warning:', err.message);
  });
  state.unsubscribeListeners.push(notifUnsub);

  // 3. Remote Configuration & Ads Fallback Document Listener
  const configUnsub = onSnapshot(doc(db, "app_config", "general"), (docSnap) => {
    if (docSnap.exists()) {
      state.appConfig = { ...DEFAULT_APP_CONFIG, ...docSnap.data() };
      populateRemoteConfigUI(state.appConfig);
    }
  }, (err) => console.warn('App config sync warning:', err.message));
  state.unsubscribeListeners.push(configUnsub);

  const adsUnsub = onSnapshot(doc(db, "app_config", "ads"), (docSnap) => {
    if (docSnap.exists()) {
      state.adConfig = { ...DEFAULT_AD_CONFIG, ...docSnap.data() };
      populateAdConfigUI(state.adConfig);
    }
  }, (err) => console.warn('Ad config sync warning:', err.message));
  state.unsubscribeListeners.push(adsUnsub);

  // In-App Announcement Ribbon Listener
  const announcementUnsub = onSnapshot(doc(db, "app_config", "announcement"), (docSnap) => {
    if (docSnap.exists()) {
      const data = docSnap.data();
      if (elements.announcementText && document.activeElement !== elements.announcementText) {
        elements.announcementText.value = data.text || '';
        if (elements.announcementMockupText) {
          elements.announcementMockupText.textContent = data.text || 'Announcement text preview';
        }
      }
      if (elements.announcementLink && document.activeElement !== elements.announcementLink) {
        elements.announcementLink.value = data.link || '';
      }
      if (elements.announcementActive) {
        elements.announcementActive.checked = data.is_active !== false;
      }
      if (elements.announcementTargetAudience) {
        elements.announcementTargetAudience.value = data.target_audience || 'all_users';
        toggleAnnouncementAudienceUI(data.target_audience || 'all_users');
      }
      if (elements.announcementTargetCountry && data.target_country) {
        elements.announcementTargetCountry.value = data.target_country;
      }
      if (elements.announcementTargetDeviceId && data.target_device_id) {
        elements.announcementTargetDeviceId.value = data.target_device_id;
      }
    }
  }, (err) => console.warn('Announcement sync warning:', err.message));
  state.unsubscribeListeners.push(announcementUnsub);

  // 4. Audit Logs Listener
  const auditQuery = query(collection(db, "admin_audit_logs"), orderBy("timestamp", "desc"), limit(25));
  const auditUnsub = onSnapshot(auditQuery, (snapshot) => {
    const logs = [];
    snapshot.forEach(docSnap => {
      logs.push({ id: docSnap.id, ...docSnap.data() });
    });
    state.auditLogs = logs;
    renderAuditLogs();
  }, (err) => console.warn('Audit logs sync warning:', err.message));
  state.unsubscribeListeners.push(auditUnsub);
}

// ============================================================
// 5. METRIC COMPUTATION & DATA RENDERING
// ============================================================
function renderDeviceMetrics() {
  const devices = state.devices;
  const count = devices.length;

  elements.kpiTotalDevices.textContent = count.toLocaleString();
  elements.navUserCount.textContent = count;
  elements.tableDeviceCount.textContent = `Showing ${count} verified devices`;

  // Active in last 24 hours
  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  let active24h = 0;
  let totalMusicMins = 0;
  let totalVideoMins = 0;
  let todayMusicMins = 0;

  devices.forEach(d => {
    // Check timestamp
    let lastActive = null;
    if (d.last_active_time) {
      if (typeof d.last_active_time === 'object' && d.last_active_time.toDate) {
        lastActive = d.last_active_time.toDate();
      } else if (typeof d.last_active_time === 'number' || !isNaN(Number(d.last_active_time))) {
        lastActive = new Date(Number(d.last_active_time));
      } else {
        lastActive = new Date(d.last_active_time);
      }
    }
    if (lastActive && !isNaN(lastActive.getTime()) && (now - lastActive.getTime() <= dayMs)) {
      active24h++;
    }

    totalMusicMins += (d.audio_playtime_minutes || 0);
    totalVideoMins += (d.video_playtime_minutes || 0);
    todayMusicMins += (d.today_music_minutes || 0);
  });

  elements.kpiActive24h.textContent = active24h.toLocaleString();
  const pct = count > 0 ? Math.round((active24h / count) * 100) : 0;
  elements.kpiActivePercentage.textContent = `${pct}% active in last 24 hours`;

  elements.kpiTotalMusicHours.textContent = `${(totalMusicMins / 60).toFixed(1)} hrs`;
  elements.kpiTodayMusicMinutes.textContent = `${todayMusicMins.toLocaleString()} mins streamed today`;
  elements.kpiTotalVideoHours.textContent = `${(totalVideoMins / 60).toFixed(1)} hrs`;

  // Render Overview Top 5 Devices
  const getDeviceTimeMs = (d) => {
    if (!d || !d.last_active_time) return 0;
    if (typeof d.last_active_time === 'object' && d.last_active_time.toDate) return d.last_active_time.toDate().getTime();
    if (typeof d.last_active_time === 'number') return d.last_active_time;
    const n = Number(d.last_active_time);
    if (!isNaN(n) && n > 0) return n;
    const parsed = new Date(d.last_active_time).getTime();
    return isNaN(parsed) ? 0 : parsed;
  };
  const sortedByRecent = [...devices].sort((a, b) => {
    return getDeviceTimeMs(b) - getDeviceTimeMs(a);
  }).slice(0, 5);

  if (sortedByRecent.length === 0) {
    elements.overviewRecentDevicesBody.innerHTML = `<tr><td colspan="5" class="table-empty">No device telemetrics recorded in Firestore yet.</td></tr>`;
  } else {
    elements.overviewRecentDevicesBody.innerHTML = sortedByRecent.map(d => {
      const isBlocked = d.is_blocked === true;
      const totalHours = (((d.audio_playtime_minutes || 0) + (d.video_playtime_minutes || 0)) / 60).toFixed(1);
      return `
        <tr>
          <td><strong>${escapeHtml(d.device_model || 'Android Device')}</strong><br><small class="text-muted font-mono">${escapeHtml(d.device_id || d.id)}</small></td>
          <td>${escapeHtml(d.android_version || 'Android')} <span class="badge-status info">v${escapeHtml(d.app_version || '1.0.5')}</span></td>
          <td><span class="text-purple font-mono font-bold">${totalHours} hrs</span></td>
          <td>${formatDate(d.last_active_time)}</td>
          <td><span class="badge-status ${isBlocked ? 'danger' : 'success'}">${isBlocked ? 'Blocked' : 'Active'}</span></td>
        </tr>
      `;
    }).join('');
  }

  // Render Overview Ad Units Matrix
  renderOverviewAdUnits();
}

function renderOverviewAdUnits() {
  const adUnits = [
    { format: 'Banner', name: 'Baner', id: 'ca-app-pub-7375534389683057/9757608460', desc: 'Bottom library view banner' },
    { format: 'App Open', name: 'Lerza open', id: 'ca-app-pub-7375534389683057/3906515984', desc: 'Splash start screen ad' },
    { format: 'Interstitial', name: 'Setting', id: 'ca-app-pub-7375534389683057/1823278127', desc: 'Settings click & track switches' },
    { format: 'Native Advanced', name: 'Songs lest', id: 'ca-app-pub-7375534389683057/8388686475', desc: 'Full player thumbnail & songs list' },
    { format: 'Rewarded Video', name: 'Vault', id: 'ca-app-pub-7375534389683057/7678240038', desc: 'Private Vault PIN / Lock reset' }
  ];

  elements.overviewAdList.innerHTML = adUnits.map(ad => `
    <div class="ad-unit-row p-3 rounded-lg border border-glass mb-2 flex-between bg-glass-card">
      <div>
        <div class="flex items-center gap-2">
          <span class="ad-format-pill ${ad.format.toLowerCase().replace(' ', '-')}">${ad.format}</span>
          <strong class="text-sm font-semibold">${ad.name}</strong>
        </div>
        <div class="text-xs text-muted font-mono mt-1">${ad.id}</div>
      </div>
      <span class="badge-status success"><i class="fa-solid fa-circle-check"></i> Enabled</span>
    </div>
  `).join('');
}

// ============================================================
// 6. DEVICE DIRECTORY & ADMINISTRATIVE BLOCKING
// ============================================================
function populateDeviceSelectDropdowns() {
  const devices = state.devices || [];
  const optionsHtml = '<option value="">Pick from Active...</option>' + 
    devices.map(d => `<option value="${d.device_id || d.id}">${escapeHtml(d.device_model || 'Device')} (${(d.device_id || d.id).slice(-8)})</option>`).join('');

  if (elements.notifDeviceQuickSelect) elements.notifDeviceQuickSelect.innerHTML = optionsHtml;
  if (elements.announcementDeviceQuickSelect) elements.announcementDeviceQuickSelect.innerHTML = optionsHtml;
}

function renderDevicesTable() {
  populateDeviceSelectDropdowns();
  const search = elements.userSearchInput.value.toLowerCase().trim();
  const filter = elements.userStatusFilter.value;

  const filtered = state.devices.filter(d => {
    const textMatch = (d.device_id || '').toLowerCase().includes(search) ||
                      (d.device_model || '').toLowerCase().includes(search) ||
                      (d.android_version || '').toLowerCase().includes(search);

    if (!textMatch) return false;

    if (filter === 'blocked') return d.is_blocked === true;
    if (filter === 'active') return d.is_blocked !== true;
    return true;
  });

  if (filtered.length === 0) {
    elements.devicesTableBody.innerHTML = `<tr><td colspan="8" class="table-empty">No devices match your search query.</td></tr>`;
    return;
  }

  elements.devicesTableBody.innerHTML = filtered.map(d => {
    const isBlocked = d.is_blocked === true;
    const hasToken = Boolean(d.fcm_token);
    const audioMins = d.audio_playtime_minutes || 0;
    const videoMins = d.video_playtime_minutes || 0;

    return `
      <tr>
        <td>
          <div class="font-bold text-sm text-primary">${escapeHtml(d.device_model || 'Unknown Device')}</div>
          <small class="text-muted">${escapeHtml(d.device_manufacturer || 'Android')}</small>
        </td>
        <td><code class="text-xs text-purple font-mono">${escapeHtml(d.device_id || d.id)}</code></td>
        <td>
          <div>${escapeHtml(d.android_version || 'Android')}</div>
          <small class="badge-status info">v${escapeHtml(d.app_version || '1.0.5')}</small>
        </td>
        <td>
          <span class="text-purple font-mono">${Math.round(audioMins)}m music</span> / 
          <span class="text-amber font-mono">${Math.round(videoMins)}m video</span>
        </td>
        <td><span class="font-mono">${d.session_count || 1}</span></td>
        <td>
          ${hasToken 
            ? `<span class="badge-status success" title="${escapeHtml(d.fcm_token)}"><i class="fa-solid fa-bell"></i> Token Ready</span>`
            : `<span class="badge-status warning">No Token</span>`
          }
        </td>
        <td>${formatDate(d.last_active_time)}</td>
        <td>
          <button class="${isBlocked ? 'btn-success-sm' : 'btn-danger-sm'}" 
                  onclick="window.toggleBlockDevice('${d.id}', ${!isBlocked})">
            <i class="fa-solid ${isBlocked ? 'fa-unlock' : 'fa-ban'}"></i>
            ${isBlocked ? 'Unblock User' : 'Block User'}
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

// Global hook for blocking a device in real time
window.toggleBlockDevice = function(deviceId, newBlockedState) {
  const actionText = newBlockedState ? 'BLOCK' : 'UNBLOCK';
  showConfirm(
    `${actionText} Device Access`,
    `Are you sure you want to ${actionText.toLowerCase()} device "${deviceId}"? ${newBlockedState ? 'The device will be instantly barred from using Lerza Player.' : 'Access will be restored immediately.'}`,
    async () => {
      try {
        await updateDoc(doc(db, "devices", deviceId), {
          is_blocked: newBlockedState,
          blocked_reason: newBlockedState ? "Access restricted by administrator." : ""
        });

        // Record in Admin Audit Log
        await logAdminAction(
          newBlockedState ? 'DEVICE_BLOCKED' : 'DEVICE_UNBLOCKED',
          `devices/${deviceId}`,
          `Device ${deviceId} was ${actionText.toLowerCase()}ed by administrator.`
        );

        showToast(`Device ${actionText.toLowerCase()}ed successfully.`, 'success');
      } catch (err) {
        console.error('Error toggling block state:', err);
        showToast('Operation failed: ' + err.message, 'error');
      }
    }
  );
};

// ============================================================
// 7. CHART.JS VISUALIZATIONS
// ============================================================
function updateCharts() {
  const devices = state.devices;

  // Chart 1: Playtime (Music vs Video)
  let totalMusicHours = 0;
  let totalVideoHours = 0;
  devices.forEach(d => {
    totalMusicHours += (d.audio_playtime_minutes || 0) / 60;
    totalVideoHours += (d.video_playtime_minutes || 0) / 60;
  });

  const ctxPlaytime = document.getElementById('playtimeChart')?.getContext('2d');
  if (ctxPlaytime) {
    if (state.charts.playtime) {
      state.charts.playtime.data.datasets[0].data = [totalMusicHours.toFixed(1), totalVideoHours.toFixed(1)];
      state.charts.playtime.update();
    } else {
      state.charts.playtime = new Chart(ctxPlaytime, {
        type: 'bar',
        data: {
          labels: ['Music Stream Time (Hours)', 'Video Playback Time (Hours)'],
          datasets: [{
            label: 'Total Hours',
            data: [totalMusicHours.toFixed(1), totalVideoHours.toFixed(1)],
            backgroundColor: ['rgba(139, 92, 246, 0.75)', 'rgba(245, 158, 11, 0.75)'],
            borderColor: ['#8b5cf6', '#f59e0b'],
            borderWidth: 1.5,
            borderRadius: 8
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94a3b8' }
            },
            x: {
              grid: { display: false },
              ticks: { color: '#94a3b8' }
            }
          }
        }
      });
    }
  }

  // Chart 2: App Version Distribution Doughnut
  const versionCounts = {};
  devices.forEach(d => {
    const v = d.app_version || 'v1.0.5';
    versionCounts[v] = (versionCounts[v] || 0) + 1;
  });

  const versionLabels = Object.keys(versionCounts);
  const versionData = Object.values(versionCounts);

  const ctxVersion = document.getElementById('versionChart')?.getContext('2d');
  if (ctxVersion) {
    if (state.charts.version) {
      state.charts.version.data.labels = versionLabels.length ? versionLabels : ['v1.0.5'];
      state.charts.version.data.datasets[0].data = versionData.length ? versionData : [1];
      state.charts.version.update();
    } else {
      state.charts.version = new Chart(ctxVersion, {
        type: 'doughnut',
        data: {
          labels: versionLabels.length ? versionLabels : ['v1.0.5'],
          datasets: [{
            data: versionData.length ? versionData : [1],
            backgroundColor: ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'],
            borderColor: '#07090e',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: { color: '#94a3b8', font: { size: 11 } }
            }
          },
          cutout: '72%'
        }
      });
    }
  }
}

// ============================================================
// 8. REMOTE CONFIGURATION & FEATURE CONTROLS
// ============================================================
function populateRemoteConfigUI(config) {
  if (config.enable_equalizer !== undefined) elements.rcEnableEqualizer.checked = config.enable_equalizer;
  if (config.enable_sleep_timer !== undefined) elements.rcEnableSleepTimer.checked = config.enable_sleep_timer;
  if (config.enable_feedback_system !== undefined) elements.rcEnableFeedback.checked = config.enable_feedback_system;
  if (config.enable_playtime_tracking !== undefined) elements.rcEnablePlaytime.checked = config.enable_playtime_tracking;
  if (config.maintenance_mode !== undefined) elements.rcMaintenanceMode.checked = config.maintenance_mode;
  if (config.update_popup_enabled !== undefined) elements.rcUpdatePopupEnabled.checked = config.update_popup_enabled;
  if (config.force_update_required !== undefined && elements.rcForceUpdateRequired) elements.rcForceUpdateRequired.checked = config.force_update_required;
  if (config.latest_app_version_code !== undefined) elements.rcLatestVersionCode.value = config.latest_app_version_code;
  if (config.update_website_url !== undefined) elements.rcUpdateWebsiteUrl.value = config.update_website_url;
}

elements.saveRemoteConfigBtn.addEventListener('click', async () => {
  const updatedConfig = {
    enable_equalizer: elements.rcEnableEqualizer.checked,
    enable_sleep_timer: elements.rcEnableSleepTimer.checked,
    enable_feedback_system: elements.rcEnableFeedback.checked,
    enable_playtime_tracking: elements.rcEnablePlaytime.checked,
    maintenance_mode: elements.rcMaintenanceMode.checked,
    update_popup_enabled: elements.rcUpdatePopupEnabled.checked,
    force_update_required: elements.rcForceUpdateRequired ? elements.rcForceUpdateRequired.checked : false,
    latest_app_version_code: parseInt(elements.rcLatestVersionCode.value, 10) || 4,
    update_website_url: elements.rcUpdateWebsiteUrl.value.trim(),
    last_updated: serverTimestamp()
  };

  try {
    elements.saveRemoteConfigBtn.disabled = true;
    await setDoc(doc(db, "app_config", "general"), updatedConfig, { merge: true });

    await logAdminAction(
      'UPDATE_REMOTE_CONFIG',
      'app_config/general',
      'Updated player feature toggles and versioning parameters.'
    );

    showToast('Remote configuration published to Firestore successfully!', 'success');
  } catch (err) {
    console.error('Error saving remote config:', err);
    showToast('Failed to save config: ' + err.message, 'error');
  } finally {
    elements.saveRemoteConfigBtn.disabled = false;
  }
});

// ============================================================
// 9. ADMOB CONTROLS & MONETIZATION
// ============================================================
function populateAdConfigUI(adCfg) {
  if (adCfg.show_all_ads !== undefined) elements.adShowAllAds.checked = adCfg.show_all_ads;
  if (adCfg.remove_all_ads !== undefined) elements.adRemoveAllAds.checked = adCfg.remove_all_ads;
  if (adCfg.test_ads_enabled !== undefined) elements.adTestAdsEnabled.checked = adCfg.test_ads_enabled;

  if (adCfg.banner_ad_unit_id) elements.adIdBanner.value = adCfg.banner_ad_unit_id;
  if (adCfg.enable_bottom_banner_ad !== undefined) elements.adEnableBanner.checked = adCfg.enable_bottom_banner_ad;
  if (adCfg.app_open_ad_unit_id) elements.adIdAppOpen.value = adCfg.app_open_ad_unit_id;
  if (adCfg.enable_app_open_ad !== undefined) elements.adEnableAppOpen.checked = adCfg.enable_app_open_ad;

  if (adCfg.interstitial_ad_unit_id) elements.adIdInterstitial.value = adCfg.interstitial_ad_unit_id;
  if (adCfg.enable_settings_click_ad !== undefined) elements.adEnableSettingsClick.checked = adCfg.enable_settings_click_ad;

  if (adCfg.native_ad_unit_id) elements.adIdNative.value = adCfg.native_ad_unit_id;
  if (adCfg.enable_player_thumbnail_ad !== undefined) elements.adEnableThumbnail.checked = adCfg.enable_player_thumbnail_ad;
  if (adCfg.enable_songs_list_ad !== undefined) elements.adEnableSongsList.checked = adCfg.enable_songs_list_ad;
  if (adCfg.enable_videos_list_ad !== undefined) elements.adEnableVideosList.checked = adCfg.enable_videos_list_ad;

  if (adCfg.rewarded_ad_unit_id) elements.adIdRewarded.value = adCfg.rewarded_ad_unit_id;
  if (adCfg.enable_vault_reward_ad !== undefined) elements.adEnableVaultReward.checked = adCfg.enable_vault_reward_ad;

  if (adCfg.interstitial_ad_frequency_clicks) {
    elements.adFreqClicks.value = adCfg.interstitial_ad_frequency_clicks;
    elements.valFreqClicks.textContent = `${adCfg.interstitial_ad_frequency_clicks} tracks`;
  }
  if (adCfg.interstitial_ad_cooldown_seconds) {
    elements.adCooldownSec.value = adCfg.interstitial_ad_cooldown_seconds;
    elements.valCooldownSec.textContent = `${adCfg.interstitial_ad_cooldown_seconds} seconds`;
  }
}

// Sliders live text
if (elements.adSongsListInterval && elements.valSongsListInterval) {
  elements.adSongsListInterval.addEventListener('input', (e) => {
    elements.valSongsListInterval.textContent = e.target.value + " tracks";
  });
}
if (elements.adAppOpenInterval && elements.valAppOpenInterval) {
  elements.adAppOpenInterval.addEventListener('input', (e) => {
    elements.valAppOpenInterval.textContent = "Every " + e.target.value + " launches";
  });
}
if (elements.adAppOpenCooldownSec && elements.valAppOpenCooldownSec) {
  elements.adAppOpenCooldownSec.addEventListener('input', (e) => {
    elements.valAppOpenCooldownSec.textContent = e.target.value + " seconds";
  });
}
elements.adFreqClicks.addEventListener('input',  (e) => {
  elements.valFreqClicks.textContent = `${e.target.value} tracks`;
});
elements.adCooldownSec.addEventListener('input', (e) => {
  elements.valCooldownSec.textContent = `${e.target.value} seconds`;
});

elements.saveAdConfigBtn.addEventListener('click', async () => {
  const adPayload = {
    show_all_ads: elements.adShowAllAds.checked,
    remove_all_ads: elements.adRemoveAllAds.checked,
    test_ads_enabled: elements.adTestAdsEnabled.checked,

    banner_ad_unit_id: elements.adIdBanner.value.trim(),
    enable_bottom_banner_ad: elements.adEnableBanner.checked,
    app_open_ad_unit_id: elements.adIdAppOpen.value.trim(),
    enable_app_open_ad: elements.adEnableAppOpen.checked,

    interstitial_ad_unit_id: elements.adIdInterstitial.value.trim(),
    enable_settings_click_ad: elements.adEnableSettingsClick.checked,

    native_ad_unit_id: elements.adIdNative.value.trim(),
    enable_player_thumbnail_ad: elements.adEnableThumbnail.checked,
    enable_songs_list_ad: elements.adEnableSongsList.checked,
    enable_videos_list_ad: elements.adEnableVideosList.checked,

    rewarded_ad_unit_id: elements.adIdRewarded.value.trim(),
    enable_vault_reward_ad: elements.adEnableVaultReward.checked,

    interstitial_ad_frequency_clicks: parseInt(elements.adFreqClicks.value, 10),
    interstitial_ad_cooldown_seconds: parseInt(elements.adCooldownSec.value, 10),
    app_open_frequency_interval: elements.adAppOpenInterval ? parseInt(elements.adAppOpenInterval.value, 10) : 3,
    app_open_ad_cooldown_seconds: elements.adAppOpenCooldownSec ? parseInt(elements.adAppOpenCooldownSec.value, 10) : 30,
    songs_list_ad_interval: elements.adSongsListInterval ? parseInt(elements.adSongsListInterval.value, 10) : 4,
    last_updated: serverTimestamp()
  };

  try {
    elements.saveAdConfigBtn.disabled = true;
    await setDoc(doc(db, "app_config", "ads"), adPayload, { merge: true });

    await logAdminAction(
      'UPDATE_AD_CONFIG',
      'app_config/ads',
      `Saved AdMob IDs and switches. Master: ${adPayload.show_all_ads}, RemoveAll: ${adPayload.remove_all_ads}.`
    );

    showToast('AdMob configuration updated and synced to Firestore!', 'success');
  } catch (err) {
    console.error('Error saving ad config:', err);
    showToast('Failed to save ad settings: ' + err.message, 'error');
  } finally {
    elements.saveAdConfigBtn.disabled = false;
  }
});

// ============================================================
// 10. NOTIFICATION COMPOSER & PREVIEW
// ============================================================
elements.notifTitle.addEventListener('input', (e) => {
  elements.previewTitleDisplay.textContent = e.target.value || 'Notification Title';
});

elements.notifBody.addEventListener('input', (e) => {
  elements.previewBodyDisplay.textContent = e.target.value || 'Message body will appear here...';
});

elements.notifImage.addEventListener('input', (e) => {
  const url = e.target.value.trim();
  if (url) {
    elements.previewImgElement.src = url;
    elements.previewImgBox.style.display = 'block';
  } else {
    elements.previewImgBox.style.display = 'none';
  }
});

elements.testNotifBtn.addEventListener('click', async () => {
  const title = elements.notifTitle.value.trim() || '🎵 Lerza Player Quick Test';
  const body = elements.notifBody.value.trim() || 'Live test notification from Lerza Web Admin!';
  const imageUrl = elements.notifImage.value.trim();
  const deepLink = elements.notifLink.value.trim();
  try {
    elements.testNotifBtn.disabled = true;
    await addDoc(collection(db, "notifications"), {
      title,
      body,
      image_url: imageUrl || null,
      deep_link: deepLink || null,
      status: 'test_broadcast',
      target_audience: 'all_users',
      target_country: null,
      target_device_id: null,
      created_at: serverTimestamp()
    });
    showToast('Instant test notification dispatched to all connected devices!', 'success');
  } catch (err) {
    showToast('Failed to dispatch test notification: ' + err.message, 'error');
  } finally {
    elements.testNotifBtn.disabled = false;
  }
});

elements.sendNotifBtn.addEventListener('click', async () => {
  const title = elements.notifTitle.value.trim();
  const body = elements.notifBody.value.trim();
  const imageUrl = elements.notifImage.value.trim();
  const deepLink = elements.notifLink.value.trim();
  const targetAudience = elements.notifTargetAudience ? elements.notifTargetAudience.value : 'all_users';
  const targetCountry = elements.notifTargetCountry ? elements.notifTargetCountry.value : 'ALL';
  const targetDeviceId = elements.notifTargetDeviceId ? elements.notifTargetDeviceId.value.trim() : '';
  const isForceUpdateCampaign = elements.notifForceUpdate ? elements.notifForceUpdate.checked : false;

  if (!title || !body) {
    showToast('Please provide both Title and Body for the notification.', 'error');
    return;
  }

  if (targetAudience === 'specific_device' && !targetDeviceId) {
    showToast('Please enter or select a specific Device ID.', 'error');
    return;
  }

  const audienceDesc = targetAudience === 'country' 
    ? `Target Country: ${targetCountry}` 
    : targetAudience === 'specific_device' 
    ? `Target User Device: ${targetDeviceId}` 
    : 'All Global App Installations';

  showConfirm(
    'Confirm Push Broadcast',
    `Broadcast notification "${title}" (${audienceDesc}) via Firebase Cloud Messaging?`,
    async () => {
      try {
        elements.sendNotifBtn.disabled = true;

        const notifDoc = {
          title,
          body,
          image_url: imageUrl || null,
          deep_link: deepLink || null,
          status: 'broadcasted',
          target_audience: targetAudience,
          target_country: targetAudience === 'country' ? targetCountry : null,
          target_device_id: targetAudience === 'specific_device' ? targetDeviceId : null,
          is_force_update: isForceUpdateCampaign,
          created_at: serverTimestamp()
        };

        await addDoc(collection(db, "notifications"), notifDoc);
        if (isForceUpdateCampaign) {
          await setDoc(doc(db, "app_config", "general"), {
            update_popup_enabled: true,
            force_update_required: true,
            last_updated: serverTimestamp()
          }, { merge: true });
        }

        await logAdminAction(
          'BROADCAST_NOTIFICATION',
          'notifications',
          `Dispatched campaign: "${title}"`
        );

        elements.notifTitle.value = '';
        elements.notifBody.value = '';
        elements.notifImage.value = '';
        elements.notifLink.value = '';
        elements.previewImgBox.style.display = 'none';

        showToast('Push Notification campaign registered and queued for FCM broadcast!', 'success');
      } catch (err) {
        console.error('Error queuing notification:', err);
        showToast('Failed to queue broadcast: ' + err.message, 'error');
      } finally {
        elements.sendNotifBtn.disabled = false;
      }
    }
  );
});

function renderNotificationHistory() {
  const notifs = state.notifications;
  if (!notifs.length) {
    elements.notificationsHistoryBody.innerHTML = `<tr><td colspan="4" class="table-empty">No push broadcasts recorded in Firestore yet.</td></tr>`;
    return;
  }

  elements.notificationsHistoryBody.innerHTML = notifs.map(n => `
    <tr>
      <td>
        <strong class="text-sm text-primary">${escapeHtml(n.title || 'Notification')}</strong>
        <p class="text-xs text-muted mt-1">${escapeHtml(n.body || '')}</p>
        <div class="mt-1">
          ${n.target_audience === 'specific_device' 
            ? `<span class="badge-status warning font-mono"><i class="fa-solid fa-mobile"></i> Device: ${(n.target_device_id || '').slice(-8)}</span>`
            : n.target_audience === 'country'
            ? `<span class="badge-status info"><i class="fa-solid fa-globe"></i> Country: ${escapeHtml(n.target_country || 'ALL')}</span>`
            : `<span class="badge-status success"><i class="fa-solid fa-earth-americas"></i> Global</span>`
          }
        </div>
      </td>
      <td><code class="text-xs text-purple font-mono">${escapeHtml(n.deep_link || 'App Launch')}</code></td>
      <td>${formatDate(n.created_at)}</td>
      <td><span class="badge-status success"><i class="fa-solid fa-circle-check"></i> Dispatched</span></td>
    </tr>
  `).join('');
}

// ============================================================
// 11. IN-APP ANNOUNCEMENTS
// ============================================================
elements.announcementText.addEventListener('input', (e) => {
  elements.announcementMockupText.textContent = e.target.value || 'Announcement text preview';
});

function toggleAnnouncementAudienceUI(val) {
  if (elements.announcementCountryGroup) {
    elements.announcementCountryGroup.style.display = (val === 'country') ? 'block' : 'none';
  }
  if (elements.announcementDeviceGroup) {
    elements.announcementDeviceGroup.style.display = (val === 'specific_device') ? 'block' : 'none';
  }
}

function toggleNotifAudienceUI(val) {
  if (elements.notifCountryGroup) {
    elements.notifCountryGroup.style.display = (val === 'country') ? 'block' : 'none';
  }
  if (elements.notifDeviceGroup) {
    elements.notifDeviceGroup.style.display = (val === 'specific_device') ? 'block' : 'none';
  }
}

if (elements.notifTargetAudience) {
  elements.notifTargetAudience.addEventListener('change', (e) => toggleNotifAudienceUI(e.target.value));
}
if (elements.announcementTargetAudience) {
  elements.announcementTargetAudience.addEventListener('change', (e) => toggleAnnouncementAudienceUI(e.target.value));
}

if (elements.notifDeviceQuickSelect) {
  elements.notifDeviceQuickSelect.addEventListener('change', (e) => {
    if (e.target.value && elements.notifTargetDeviceId) {
      elements.notifTargetDeviceId.value = e.target.value;
    }
  });
}
if (elements.announcementDeviceQuickSelect) {
  elements.announcementDeviceQuickSelect.addEventListener('change', (e) => {
    if (e.target.value && elements.announcementTargetDeviceId) {
      elements.announcementTargetDeviceId.value = e.target.value;
    }
  });
}

elements.publishAnnouncementBtn.addEventListener('click', async () => {
  const text = elements.announcementText.value.trim();
  const link = elements.announcementLink.value.trim();
  const active = elements.announcementActive.checked;
  const targetAudience = elements.announcementTargetAudience ? elements.announcementTargetAudience.value : 'all_users';
  const targetCountry = elements.announcementTargetCountry ? elements.announcementTargetCountry.value : 'ALL';
  const targetDeviceId = elements.announcementTargetDeviceId ? elements.announcementTargetDeviceId.value.trim() : '';

  if (targetAudience === 'specific_device' && !targetDeviceId) {
    showToast('Please enter or select a specific Device ID for this announcement.', 'error');
    return;
  }

  try {
    elements.publishAnnouncementBtn.disabled = true;
    await setDoc(doc(db, "app_config", "announcement"), {
      text,
      link,
      is_active: active,
      target_audience: targetAudience,
      target_country: targetAudience === 'country' ? targetCountry : null,
      target_device_id: targetAudience === 'specific_device' ? targetDeviceId : null,
          is_force_update: isForceUpdateCampaign,
      last_updated: serverTimestamp()
    }, { merge: true });

    // Also synchronize into general config for Remote Config parity
    await setDoc(doc(db, "app_config", "general"), {
      announcement_banner_text: active ? text : "",
      announcement_banner_link: active ? link : "",
      last_updated: serverTimestamp()
    }, { merge: true });

    const audienceDesc = targetAudience === 'specific_device' 
      ? `Device: ${targetDeviceId}` 
      : targetAudience === 'country' 
      ? `Country: ${targetCountry}` 
      : 'All Users';

    await logAdminAction(
      'UPDATE_ANNOUNCEMENT',
      'app_config/announcement',
      `Banner text: "${text}", active: ${active}, audience: ${audienceDesc}`
    );

    showToast('In-app announcement ribbon published to Firestore!', 'success');
  } catch (err) {
    console.error('Error publishing announcement:', err);
    showToast('Failed to publish: ' + err.message, 'error');
  } finally {
    elements.publishAnnouncementBtn.disabled = false;
  }
});

// ============================================================
// 12. AUDIT LOGGING & SYSTEM HEALTH
// ============================================================
async function logAdminAction(action, target, details) {
  try {
    await addDoc(collection(db, "admin_audit_logs"), {
      action,
      target,
      details,
      operator: state.currentUser?.email || 'admin',
      timestamp: serverTimestamp()
    });
  } catch (e) {
    console.warn('Could not record audit log:', e);
  }
}

function renderAuditLogs() {
  const logs = state.auditLogs;
  if (!logs.length) {
    elements.auditLogsBody.innerHTML = `<tr><td colspan="5" class="table-empty">No administrator activities recorded yet.</td></tr>`;
    return;
  }

  elements.auditLogsBody.innerHTML = logs.map(l => `
    <tr>
      <td>${formatDate(l.timestamp)}</td>
      <td><span class="badge-status info">${escapeHtml(l.action || 'ACTION')}</span></td>
      <td><code class="text-xs font-mono text-purple">${escapeHtml(l.target || '')}</code></td>
      <td><small class="text-secondary">${escapeHtml(l.operator || 'admin')}</small></td>
      <td><span class="text-xs text-muted">${escapeHtml(l.details || '')}</span></td>
    </tr>
  `).join('');
}

// ============================================================
// 13. UI UTILITIES, TOASTS & MODALS
// ============================================================
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `glass-toast ${type}`;
  const iconMap = {
    success: 'fa-circle-check',
    error: 'fa-triangle-exclamation',
    info: 'fa-circle-info'
  };
  toast.innerHTML = `
    <i class="fa-solid ${iconMap[type] || 'fa-bell'}"></i>
    <span>${escapeHtml(message)}</span>
  `;
  elements.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function showConfirm(title, message, onConfirm) {
  elements.modalTitle.textContent = title;
  elements.modalMessage.textContent = message;
  elements.confirmModal.classList.add('active');

  const handleConfirm = () => {
    elements.confirmModal.classList.remove('active');
    cleanup();
    onConfirm();
  };

  const handleCancel = () => {
    elements.confirmModal.classList.remove('active');
    cleanup();
  };

  function cleanup() {
    elements.modalConfirmBtn.removeEventListener('click', handleConfirm);
    elements.modalCancelBtn.removeEventListener('click', handleCancel);
  }

  elements.modalConfirmBtn.addEventListener('click', handleConfirm);
  elements.modalCancelBtn.addEventListener('click', handleCancel);
}

function updateSyncTime() {
  const now = new Date();
  elements.lastSyncTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function formatDate(timestamp) {
  if (!timestamp) return '<span class="text-muted">Never</span>';
  let date;
  if (typeof timestamp === 'object' && timestamp.toDate) {
    date = timestamp.toDate();
  } else if (typeof timestamp === 'number' || !isNaN(Number(timestamp))) {
    date = new Date(Number(timestamp));
  } else {
    date = new Date(timestamp);
  }
  if (isNaN(date.getTime())) return '<span class="text-muted">Recently</span>';
  return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Theme Switcher
elements.themeToggleBtn.addEventListener('click', () => {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  elements.themeIcon.className = newTheme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
});

// Sidebar Toggle
elements.sidebarToggle.addEventListener('click', () => {
  elements.sidebar.classList.toggle('collapsed');
});

function closeMobileSidebar() {
  if (elements.sidebar) {
    elements.sidebar.classList.remove('mobile-open');
    elements.sidebar.classList.remove('collapsed');
  }
  if (elements.sidebarBackdrop) {
    elements.sidebarBackdrop.classList.remove('active');
  }
}

if (elements.mobileMenuBtn) {
  elements.mobileMenuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (!elements.sidebar) return;
    const willOpen = !elements.sidebar.classList.contains('mobile-open');
    if (willOpen) {
      elements.sidebar.classList.add('mobile-open');
      if (elements.sidebarBackdrop) elements.sidebarBackdrop.classList.add('active');
    } else {
      closeMobileSidebar();
    }
  });
}

if (elements.sidebarBackdrop) {
  elements.sidebarBackdrop.addEventListener('click', (e) => {
    e.stopPropagation();
    closeMobileSidebar();
  });
  elements.sidebarBackdrop.addEventListener('touchstart', (e) => {
    e.stopPropagation();
    closeMobileSidebar();
  }, { passive: true });
}

// Seamless one-tap outside dismiss for mobile
document.addEventListener('click', (e) => {
  if (elements.sidebar && elements.sidebar.classList.contains('mobile-open')) {
    if (!elements.sidebar.contains(e.target) && (!elements.mobileMenuBtn || !elements.mobileMenuBtn.contains(e.target))) {
      closeMobileSidebar();
    }
  }
});
document.addEventListener('touchstart', (e) => {
  if (elements.sidebar && elements.sidebar.classList.contains('mobile-open')) {
    if (!elements.sidebar.contains(e.target) && (!elements.mobileMenuBtn || !elements.mobileMenuBtn.contains(e.target))) {
      closeMobileSidebar();
    }
  }
}, { passive: true });

// Navigation Item Click Handler (Instant Routing & Close Mobile Menu)
elements.navItems.forEach(item => {
  item.addEventListener('click', (e) => {
    const pageId = item.dataset.page;
    if (pageId) {
      navigateToPage(pageId);
    }
    closeMobileSidebar();
  });
});

// Search & Filter Listeners
elements.userSearchInput.addEventListener('input', () => renderDevicesTable());
elements.userStatusFilter.addEventListener('change', () => renderDevicesTable());

// Manual Refresh
elements.manualRefreshBtn.addEventListener('click', () => {
  showToast('Refreshing real-time Firestore listeners...', 'info');
  startRealtimeListeners();
});

// Logout
elements.logoutBtn.addEventListener('click', () => {
  signOut(auth).then(() => {
    showToast('Signed out of admin session.', 'info');
  });
});

// Hash Routing Listener
window.addEventListener('hashchange', () => {
  const hash = window.location.hash.replace('#', '') || 'overview';
  navigateToPage(hash);
});

// Date display
const dateDisplay = document.getElementById('currentDateDisplay');
if (dateDisplay) {
  dateDisplay.textContent = new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}


// ============================================================
// 14. FIREBASE RULES & MODAL CONTROLLERS
// ============================================================
function openFirebaseModal() {
  if (elements.firebaseModal) {
    elements.firebaseModal.classList.add('active');
  }
}

function closeFirebaseModal() {
  if (elements.firebaseModal) {
    elements.firebaseModal.classList.remove('active');
  }
}

if (elements.firebaseSetupBtn) {
  elements.firebaseSetupBtn.addEventListener('click', openFirebaseModal);
}
if (elements.closeFirebaseModalBtn) {
  elements.closeFirebaseModalBtn.addEventListener('click', closeFirebaseModal);
}
if (elements.firebaseBannerActionBtn) {
  elements.firebaseBannerActionBtn.addEventListener('click', openFirebaseModal);
}
if (elements.closeFirebaseBannerBtn) {
  elements.closeFirebaseBannerBtn.addEventListener('click', () => {
    if (elements.firebaseAlertBanner) elements.firebaseAlertBanner.style.display = 'none';
  });
}

// Copy Firestore Rules button
if (elements.copyFirestoreRulesBtn) {
  elements.copyFirestoreRulesBtn.addEventListener('click', () => {
    const rules = elements.firestoreRulesCode.textContent;
    navigator.clipboard.writeText(rules).then(() => {
      showToast('Firestore Security Rules copied to clipboard!', 'success');
      elements.copyFirestoreRulesBtn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
      setTimeout(() => {
        elements.copyFirestoreRulesBtn.innerHTML = '<i class="fa-regular fa-copy"></i> Copy Code';
      }, 2500);
    });
  });
}

// Export Remote Config JSON template for Firebase Console
function exportRemoteConfigTemplate() {
  const currentGeneral = state.appConfig || {};
  const currentAds = state.adConfig || {};
  const template = {
    parameters: {
      show_all_ads: { defaultValue: { value: String(currentAds.show_all_ads ?? true) }, valueType: "BOOLEAN" },
      remove_all_ads: { defaultValue: { value: String(currentAds.remove_all_ads ?? false) }, valueType: "BOOLEAN" },
      test_ads_enabled: { defaultValue: { value: String(currentAds.test_ads_enabled ?? false) }, valueType: "BOOLEAN" },
      banner_ad_unit_id: { defaultValue: { value: currentAds.banner_ad_unit_id || "ca-app-pub-7375534389683057/9757608460" }, valueType: "STRING" },
      app_open_ad_unit_id: { defaultValue: { value: currentAds.app_open_ad_unit_id || "ca-app-pub-7375534389683057/8777123456" }, valueType: "STRING" },
      interstitial_ad_unit_id: { defaultValue: { value: currentAds.interstitial_ad_unit_id || "ca-app-pub-7375534389683057/1823278127" }, valueType: "STRING" },
      native_ad_unit_id: { defaultValue: { value: currentAds.native_ad_unit_id || "ca-app-pub-7375534389683057/3847321588" }, valueType: "STRING" },
      rewarded_ad_unit_id: { defaultValue: { value: currentAds.rewarded_ad_unit_id || "ca-app-pub-7375534389683057/7678240038" }, valueType: "STRING" },
      enable_app_open_ad: { defaultValue: { value: String(currentAds.enable_app_open_ad ?? true) }, valueType: "BOOLEAN" },
      enable_player_thumbnail_ad: { defaultValue: { value: String(currentAds.enable_player_thumbnail_ad ?? true) }, valueType: "BOOLEAN" },
      enable_songs_list_ad: { defaultValue: { value: String(currentAds.enable_songs_list_ad ?? true) }, valueType: "BOOLEAN" },
      enable_videos_list_ad: { defaultValue: { value: String(currentAds.enable_videos_list_ad ?? true) }, valueType: "BOOLEAN" },
      enable_settings_click_ad: { defaultValue: { value: String(currentAds.enable_settings_click_ad ?? true) }, valueType: "BOOLEAN" },
      enable_vault_reward_ad: { defaultValue: { value: String(currentAds.enable_vault_reward_ad ?? true) }, valueType: "BOOLEAN" },
      interstitial_ad_frequency_clicks: { defaultValue: { value: String(currentAds.interstitial_ad_frequency_clicks ?? 4) }, valueType: "NUMBER" },
      interstitial_ad_cooldown_seconds: { defaultValue: { value: String(currentAds.interstitial_ad_cooldown_seconds ?? 45) }, valueType: "NUMBER" },
      enable_equalizer: { defaultValue: { value: String(currentGeneral.enable_equalizer ?? true) }, valueType: "BOOLEAN" },
      enable_sleep_timer: { defaultValue: { value: String(currentGeneral.enable_sleep_timer ?? true) }, valueType: "BOOLEAN" },
      enable_feedback_system: { defaultValue: { value: String(currentGeneral.enable_feedback_system ?? true) }, valueType: "BOOLEAN" },
      enable_playtime_tracking: { defaultValue: { value: String(currentGeneral.enable_playtime_tracking ?? true) }, valueType: "BOOLEAN" },
      maintenance_mode: { defaultValue: { value: String(currentGeneral.maintenance_mode ?? false) }, valueType: "BOOLEAN" },
      update_popup_enabled: { defaultValue: { value: String(currentGeneral.update_popup_enabled ?? false) }, valueType: "BOOLEAN" },
      latest_app_version_code: { defaultValue: { value: String(currentGeneral.latest_app_version_code ?? 4) }, valueType: "NUMBER" },
      update_website_url: { defaultValue: { value: currentGeneral.update_website_url || "https://lerzaplayer.vercel.app" }, valueType: "STRING" },
      announcement_banner_text: { defaultValue: { value: currentGeneral.announcement_banner_text || "" }, valueType: "STRING" },
      announcement_banner_link: { defaultValue: { value: currentGeneral.announcement_banner_link || "" }, valueType: "STRING" }
    }
  };
  const blob = new Blob([JSON.stringify(template, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "remote_config_template.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("Firebase Remote Config JSON exported successfully!", "success");
}

if (elements.exportRemoteConfigBtn) {
  elements.exportRemoteConfigBtn.addEventListener('click', exportRemoteConfigTemplate);
}

// Custom Config Save & Reset
if (elements.saveCustomConfigBtn) {
  elements.saveCustomConfigBtn.addEventListener('click', () => {
    const customCfg = {
      apiKey: elements.cfgApiKey.value.trim(),
      projectId: elements.cfgProjectId.value.trim(),
      appId: elements.cfgAppId.value.trim()
    };
    localStorage.setItem("lerza_custom_firebase_cfg", JSON.stringify(customCfg));
    showToast("Custom Firebase credentials saved! Reloading dashboard...", "success");
    setTimeout(() => window.location.reload(), 1000);
  });
}

if (elements.resetDefaultConfigBtn) {
  elements.resetDefaultConfigBtn.addEventListener('click', () => {
    localStorage.removeItem("lerza_custom_firebase_cfg");
    showToast("Reset to default credentials. Reloading...", "info");
    setTimeout(() => window.location.reload(), 1000);
  });
}

// Initialize Application with production defaults
populateRemoteConfigUI(state.appConfig);
populateAdConfigUI(state.adConfig);
initAuth();
const initialHash = window.location.hash.replace('#', '') || 'overview';
navigateToPage(initialHash);


// ============================================================
// 12. REAL-TIME USER FEEDBACK LISTENER & EXPORT
// ============================================================
function initFeedbackListener() {
  try {
    const feedbackQuery = query(collection(db, "feedback"), orderBy("created_at", "desc"), limit(100));
    onSnapshot(feedbackQuery, (snapshot) => {
      const items = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() });
      });
      state.feedback = items;
      renderFeedbackList();
    }, (err) => {
      console.warn("Feedback listener warning:", err);
      // Fallback try without orderBy if index is creating
      onSnapshot(collection(db, "feedback"), (snapshot) => {
        const items = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() });
        });
        state.feedback = items;
        renderFeedbackList();
      });
    });
  } catch (err) {
    console.error("Error setting up feedback listener:", err);
  }
}

function renderFeedbackList() {
  const list = state.feedback;
  if (elements.navFeedbackCount) elements.navFeedbackCount.textContent = list.length;
  if (elements.feedbackTotalCount) elements.feedbackTotalCount.textContent = list.length;

  if (!list.length) {
    if (elements.feedbackTableBody) {
      elements.feedbackTableBody.innerHTML = `<tr><td colspan="5" class="table-empty">No feedback received from users yet. Submissions from the app will show here in real-time.</td></tr>`;
    }
    return;
  }

  let totalRating = 0;
  let fiveStarCount = 0;
  list.forEach(item => {
    const r = parseInt(item.rating || 5, 10);
    totalRating += r;
    if (r === 5) fiveStarCount++;
  });

  const avg = (totalRating / list.length).toFixed(1);
  if (elements.feedbackAvgRating) elements.feedbackAvgRating.textContent = avg;
  if (elements.feedback5StarCount) elements.feedback5StarCount.textContent = fiveStarCount;

  const filterText = elements.searchFeedbackInput ? elements.searchFeedbackInput.value.toLowerCase().trim() : '';
  const filtered = filterText ? list.filter(i => 
    (i.message && i.message.toLowerCase().includes(filterText)) ||
    (i.contact && i.contact.toLowerCase().includes(filterText)) ||
    (i.device && i.device.toLowerCase().includes(filterText))
  ) : list;

  if (elements.feedbackTableBody) {
    elements.feedbackTableBody.innerHTML = filtered.map(item => {
      const stars = "⭐".repeat(Math.max(1, Math.min(5, parseInt(item.rating || 5, 10))));
      const dateStr = item.formatted_date || (item.created_at?.toDate ? item.created_at.toDate().toLocaleString() : 'Recent');
      return `
        <tr>
          <td style="white-space: nowrap; font-size: 12px; color: #94a3b8;">
            <i class="fa-regular fa-clock text-cyan"></i> ${dateStr}
          </td>
          <td style="white-space: nowrap;">
            <span style="letter-spacing: 2px;">${stars}</span>
            <span class="badge" style="margin-left: 6px; background: rgba(255,184,0,0.15); color: #ffb800; border: 1px solid rgba(255,184,0,0.3); font-size: 11px;">${item.rating || 5}/5</span>
          </td>
          <td>
            <div style="font-weight: 500; color: #f8fafc; line-height: 1.4;">${escapeHtml(item.message || 'No comment')}</div>
          </td>
          <td style="white-space: nowrap; font-size: 12.5px;">
            <i class="fa-regular fa-user text-purple"></i> ${escapeHtml(item.contact || 'Anonymous')}
          </td>
          <td style="font-size: 12px; color: #94a3b8;">
            <div><i class="fa-solid fa-mobile-screen"></i> ${escapeHtml(item.device || 'Android Device')}</div>
            <span class="badge" style="font-size: 10px; background: rgba(148,163,184,0.1);">${escapeHtml(item.appVersion || 'v1.0.5')}</span>
          </td>
        </tr>
      `;
    }).join('');
  }
}

function exportFeedbackToCsv() {
  const list = state.feedback;
  if (!list.length) {
    showToast("No feedback entries available to export.", "info");
    return;
  }
  const headers = ["ID", "Date", "Rating", "Message", "Contact", "Device", "AppVersion"];
  const rows = list.map(item => [
    item.id || '',
    `"${(item.formatted_date || '').replace(/"/g, '""')}"`,
    item.rating || 5,
    `"${(item.message || '').replace(/"/g, '""')}"`,
    `"${(item.contact || '').replace(/"/g, '""')}"`,
    `"${(item.device || '').replace(/"/g, '""')}"`,
    `"${(item.appVersion || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `lerza_player_feedback_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast("Feedback exported to CSV successfully! You can import this directly into Google Sheets.", "success");
}

if (elements.exportFeedbackCsvBtn) {
  elements.exportFeedbackCsvBtn.addEventListener('click', exportFeedbackToCsv);
}
if (elements.searchFeedbackInput) {
  elements.searchFeedbackInput.addEventListener('input', renderFeedbackList);
}
