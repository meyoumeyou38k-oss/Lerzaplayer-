/**
 * ====================================================================
 * 🎵 LERZA PLAYER PRO - GOOGLE SHEETS FEEDBACK WEBHOOK SCRIPT (2026)
 * ====================================================================
 * 
 * یہ گوگل ایپس اسکرپٹ (Google Apps Script) کا مکمل خودکار کوڈ ہے۔
 * یہ ایپ سے موصول ہونے والے تمام فیڈ بیک میسجز کو آپ کی گوگل شیٹ میں
 * خودکار طور پر نئی قطار (Row) کے طور پر سیو کر دیتا ہے۔
 *
 * آسان 4 مراحل میں سیٹ اپ کا طریقہ:
 * 1. گوگل شیٹس کھولیں (https://sheets.google.com) اور نئی شیٹ بنائیں۔
 * 2. اوپر مینو میں جائیں: Extensions > Apps Script پر کلک کریں۔
 * 3. وہاں پہلے سے موجود کوڈ ڈیلیٹ کریں اور یہ سارا کوڈ کاپی کر کے پیسٹ کریں۔
 * 4. اوپر نیلے بٹن "Deploy" پر کلک کریں > "New deployment" منتخب کریں:
 *    - Select type: "Web app" منتخب کریں
 *    - Description: "Lerza Player Feedback Webhook"
 *    - Execute as: "Me (آپ کا ای میل)"
 *    - Who has access: "Anyone" (تاکہ یوزرز کا فیڈ بیک شیٹ میں آ سکے)
 *    - "Deploy" دبائیں اور پرمیشن منظور کریں۔
 *    - گوگل آپ کو ایک Web App URL دے گا (مثلاً: https://script.google.com/macros/s/.../exec)
 * 5. وہ لنک ایپ کی سیٹنگز میں پیسٹ کر دیں، بس کام مکمل!
 */

function doPost(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getActiveSheet();

    // اگر شیٹ بالکل خالی ہے تو خودکار خوبصورت ہیڈرز بنا دے
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Date & Time",
        "Feedback Message",
        "Rating",
        "User Contact / Name",
        "Device & Android",
        "App Version"
      ]);
      
      // ہیڈر کا خوبصورت ڈیزائن
      var headerRange = sheet.getRange(1, 1, 1, 6);
      headerRange.setBackground("#059669"); // Emerald Green
      headerRange.setFontColor("#FFFFFF");
      headerRange.setFontWeight("bold");
      headerRange.setFontSize(11);
      headerRange.setHorizontalAlignment("center");
      sheet.setFrozenRows(1);
    }

    var data;
    if (e && e.postData && e.postData.contents) {
      data = JSON.parse(e.postData.contents);
    } else if (e && e.parameter) {
      data = e.parameter;
    } else {
      data = {};
    }

    var date = data.date || Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+5", "yyyy-MM-dd HH:mm:ss");
    var message = data.message || "No message provided";
    var numRating = parseInt(data.rating, 10) || 5;
    if (numRating < 1) numRating = 1;
    if (numRating > 5) numRating = 5;
    var starSymbols = "";
    for (var s = 0; s < numRating; s++) {
      starSymbols += "⭐";
    }
    var rating = starSymbols + " (" + numRating + "/5)";
    var contact = data.contact || "Anonymous";
    var device = data.device || "Android Device";
    var appVersion = data.appVersion || "v1.0.5";

    // گوگل شیٹ میں نیا ڈیٹا درج کریں
    sheet.appendRow([date, message, rating, contact, device, appVersion]);

    // خودکار کالم کی چوڑائی ایڈجسٹ کریں
    sheet.autoResizeColumns(1, 6);

    return ContentService
      .createTextOutput(JSON.stringify({ 
        status: "success", 
        message: "Feedback recorded in Google Sheet successfully!" 
      }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ 
        status: "error", 
        message: err.toString() 
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput("✅ Lerza Player Pro Feedback Webhook is LIVE and ready to receive feedbacks!");
}
