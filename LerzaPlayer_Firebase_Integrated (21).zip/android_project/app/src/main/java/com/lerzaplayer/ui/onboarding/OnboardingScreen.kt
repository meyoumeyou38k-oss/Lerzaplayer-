package com.lerzaplayer.ui.onboarding

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch
import java.security.MessageDigest

/**
 * Ultra-Modern Luxury Glassmorphic & Bubbly Onboarding Wizard (8 Steps)
 * Designed with liquid glowing gradients, frosted glass cards, and fluid transitions.
 */
@Composable
fun OnboardingScreen(
    prefManager: PreferenceManager,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activeColor = ThemeManager.currentThemeColor
    val colors = LocalLerzaColors.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    var currentStep by remember { mutableIntStateOf(1) }
    val totalSteps = 8

    // Language state
    val currentLang by LanguageManager.currentLanguage.collectAsState()

    // Theme state
    var selectedThemeMode by remember { mutableStateOf(ThemeManager.currentThemeMode) }

    // User name state
    var userNameInput by remember { mutableStateOf("") }

    // Vault 4-Digit In-App Keypad State
    var enteredPin by remember { mutableStateOf("") }
    var tempPinFirst by remember { mutableStateOf("") }
    var isConfirmStep by remember { mutableStateOf(false) }
    var isVaultPinConfigured by remember { mutableStateOf(false) }
    var pinErrorMessage by remember { mutableStateOf<String?>(null) }

    // Interactive Notification Preview States in Step 6
    var previewIsPlaying by remember { mutableStateOf(true) }

    // Permission states
    var isNotificationAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var isAudioAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isVideoAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isPhotosAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isAllFilesAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else true
        )
    }

    // Permission Launchers
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationAllowed = granted
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isAudioAllowed = granted
    }

    val videoPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isVideoAllowed = granted
    }

    val allFilesPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            isAllFilesAllowed = Environment.isExternalStorageManager()
        }
    }

    // Auto-prompt notification on step 6
    LaunchedEffect(currentStep) {
        if (currentStep == 6) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                isNotificationAllowed = granted
                if (!granted) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            } else {
                isNotificationAllowed = true
            }
        }
        if (currentStep == 7) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                isAllFilesAllowed = Environment.isExternalStorageManager()
            }
        }
    }

    BackHandler(enabled = currentStep > 1) {
        currentStep -= 1
    }

    fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(pin.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    // Step 5 handles PIN logic when 4 digits are entered
    LaunchedEffect(enteredPin) {
        if (enteredPin.length == 4) {
            if (!isConfirmStep) {
                tempPinFirst = enteredPin
                enteredPin = ""
                isConfirmStep = true
                pinErrorMessage = null
            } else {
                if (enteredPin == tempPinFirst) {
                    val hashed = hashPin(enteredPin)
                    scope.launch {
                        prefManager.setVaultPin(hashed)
                        VaultManager.getInstance(context).updatePin(enteredPin)
                    }
                    isVaultPinConfigured = true
                    pinErrorMessage = null
                } else {
                    pinErrorMessage = if (currentLang == AppLanguage.URDU) "پن کوڈ مماثل نہیں ہے۔ دوبارہ درج کریں۔" else "PINs do not match. Please re-enter."
                    enteredPin = ""
                    tempPinFirst = ""
                    isConfirmStep = false
                }
            }
        }
    }

    val allStep7PermissionsGranted = isAudioAllowed && isVideoAllowed && isAllFilesAllowed

    val isNextEnabled = when (currentStep) {
        5 -> isVaultPinConfigured
        6 -> isNotificationAllowed
        7 -> allStep7PermissionsGranted
        else -> true
    }

    // Liquid glowing background container
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D1A))
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                })
            }
    ) {
        // Floating ambient liquid glowing bubbles in background
        Box(
            modifier = Modifier
                .size(280.dp)
                .offset(x = (-40).dp, y = (-40).dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(activeColor.copy(alpha = 0.22f), Color.Transparent)
                    ),
                    shape = CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(260.dp)
                .align(Alignment.CenterEnd)
                .offset(x = 60.dp, y = 80.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF06B6D4).copy(alpha = 0.16f), Color.Transparent)
                    ),
                    shape = CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(240.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-30).dp, y = 40.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF8B5CF6).copy(alpha = 0.18f), Color.Transparent)
                    ),
                    shape = CircleShape
                )
        )

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Bubbly Back Button
                        if (currentStep > 1) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.08f))
                                    .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)), CircleShape)
                                    .clickable { currentStep -= 1 },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(40.dp))
                        }

                        // Glowing Step Pill Badge
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = activeColor.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, activeColor.copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = "STEP $currentStep OF $totalSteps",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.2.sp,
                                color = activeColor,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        // Skip option on non-critical steps
                        if (currentStep in listOf(3, 4)) {
                            Text(
                                text = "Skip",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { currentStep += 1 }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        } else {
                            Spacer(modifier = Modifier.size(40.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Bubbly Liquid Progress Dots Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (step in 1..totalSteps) {
                            val isCompleted = step < currentStep
                            val isCurrent = step == currentStep

                            Box(
                                modifier = Modifier
                                    .weight(if (isCurrent) 2.2f else 1f)
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isCurrent -> Brush.horizontalGradient(
                                                listOf(activeColor, Color(0xFF06B6D4))
                                            )
                                            isCompleted -> Brush.horizontalGradient(
                                                listOf(activeColor.copy(alpha = 0.7f), activeColor.copy(alpha = 0.4f))
                                            )
                                            else -> Brush.horizontalGradient(
                                                listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.08f))
                                            )
                                        }
                                    )
                            )
                        }
                    }
                }
            },
            bottomBar = {
                // Liquid Glowing Floating Action Bar
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    color = Color.Transparent
                ) {
                    Button(
                        onClick = {
                            if (currentStep < totalSteps) {
                                currentStep += 1
                            } else {
                                scope.launch {
                                    prefManager.setOnboardingV2Completed(true)
                                    prefManager.setUserName(userNameInput.trim())
                                    onComplete()
                                }
                            }
                        },
                        enabled = isNextEnabled,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (currentStep == totalSteps) Color(0xFF10B981) else activeColor,
                            disabledContainerColor = Color.White.copy(alpha = 0.08f)
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = when (currentStep) {
                                    totalSteps -> if (currentLang == AppLanguage.URDU) "لرزا پلیئر شروع کریں" else "Launch Lerza Player"
                                    5 -> if (isVaultPinConfigured) "PIN Saved • Continue" else "Set 4-Digit PIN to Continue"
                                    6 -> if (isNotificationAllowed) "Continue" else "Allow Notifications"
                                    7 -> if (allStep7PermissionsGranted) "All Permissions Ready • Continue" else "Grant Permissions to Continue"
                                    else -> if (currentLang == AppLanguage.URDU) "اگلا مرحلہ" else "Continue"
                                },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isNextEnabled) Color.White else Color.White.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = if (currentStep == totalSteps) Icons.Default.RocketLaunch else Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = if (isNextEnabled) Color.White else Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> -width } + fadeOut()
                        )
                    } else {
                        (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> width } + fadeOut()
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                label = "StepContent"
            ) { targetStep ->
                when (targetStep) {
                    // 🌟 STEP 1: WELCOME & AUDIO EXPERIENCE
                    1 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Spacer(modifier = Modifier.height(6.dp))

                            // Glowing Soundwave Orb
                            Box(
                                modifier = Modifier
                                    .size(92.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(activeColor, Color(0xFF06B6D4))
                                        )
                                    )
                                    .border(2.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                                    .shadow(16.dp, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(46.dp)
                                )
                            }

                            BubblyStepHeader(
                                badge = "PREMIUM AUDIO SUITE",
                                title = if (currentLang == AppLanguage.URDU) "خوش آمدید لرزا پلیئر میں" else if (currentLang == AppLanguage.HINDI) "लर्ज़ा प्लेयर में आपका स्वागत है" else "Welcome to Lerza Player",
                                desc = if (currentLang == AppLanguage.URDU) "اعلیٰ ترین آواز، جدید لیکوڈ ڈیزائن اور شاندار کنٹرولز کا بے مثال امتزاج۔" else "Experience studio-grade lossless audio, liquid glass aesthetics, and instant hardware playback.",
                                activeColor = activeColor
                            )

                            // Frosted Liquid Feature Card
                            LiquidGlassCard(activeColor = activeColor) {
                                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                    LiquidFeatureRow(
                                        icon = Icons.Default.Headphones,
                                        title = "Studio Lossless 320kbps",
                                        desc = "Hi-Res lossless playback engine with zero latency audio decoding.",
                                        activeColor = activeColor
                                    )
                                    LiquidFeatureRow(
                                        icon = Icons.Default.Shield,
                                        title = "Private Media Vault",
                                        desc = "Military-grade SHA-256 encrypted hidden storage for private songs and videos.",
                                        activeColor = Color(0xFF06B6D4)
                                    )
                                    LiquidFeatureRow(
                                        icon = Icons.Default.Tune,
                                        title = "5-Band Master Equalizer",
                                        desc = "Deep bass boost, 3D surround virtualization, and custom audio presets.",
                                        activeColor = Color(0xFF10B981)
                                    )
                                }
                            }
                        }
                    }

                    // 🌟 STEP 2: LANGUAGE SELECTION
                    2 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            BubblyStepHeader(
                                badge = "GLOBAL LOCALIZATION",
                                title = if (currentLang == AppLanguage.URDU) "اپنی پسندیدہ زبان منتخب کریں" else if (currentLang == AppLanguage.HINDI) "अपनी पसंदीदा भाषा चुनें" else "Choose Your Language",
                                desc = if (currentLang == AppLanguage.URDU) "آپ کسی بھی وقت سیٹنگز سے زبان تبدیل کر سکتے ہیں۔" else "Select your preferred application language. You can change this anytime in Settings.",
                                activeColor = activeColor
                            )

                            BubblyLanguageCard(
                                title = "Urdu",
                                nativeTitle = "اردو (قومی زبان)",
                                isSelected = currentLang == AppLanguage.URDU,
                                activeColor = activeColor,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.URDU)
                                    }
                                }
                            )

                            BubblyLanguageCard(
                                title = "English",
                                nativeTitle = "English (International)",
                                isSelected = currentLang == AppLanguage.ENGLISH,
                                activeColor = activeColor,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.ENGLISH)
                                    }
                                }
                            )

                            BubblyLanguageCard(
                                title = "Hindi",
                                nativeTitle = "हिन्दी (Official)",
                                isSelected = currentLang == AppLanguage.HINDI,
                                activeColor = activeColor,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.HINDI)
                                    }
                                }
                            )
                        }
                    }

                    // 🌟 STEP 3: THEME & LIQUID ACCENTS
                    3 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            BubblyStepHeader(
                                badge = "AESTHETICS & THEME",
                                title = if (currentLang == AppLanguage.URDU) "تھیم اور رنگ کا انتخاب" else "Theme & Liquid Accents",
                                desc = if (currentLang == AppLanguage.URDU) "اپنی پسند کے مطابق ڈارک یا ایمولیڈ تھیم اور شاندار رنگ منتخب کریں۔" else "Personalize your visual experience with liquid glass glow and high-contrast colorways.",
                                activeColor = activeColor
                            )

                            // Theme Mode Selection
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                listOf(
                                    Triple(ThemeMode.DARK, "Dark", Icons.Default.DarkMode),
                                    Triple(ThemeMode.BLACK, "AMOLED", Icons.Default.BrightnessMedium),
                                    Triple(ThemeMode.LIGHT, "Light", Icons.Default.LightMode)
                                ).forEach { (mode, label, icon) ->
                                    val isSelected = selectedThemeMode == mode
                                    Surface(
                                        onClick = {
                                            selectedThemeMode = mode
                                            scope.launch {
                                                prefManager.setThemeMode(mode.name)
                                                ThemeManager.updateTheme(mode, activeColor)
                                            }
                                        },
                                        shape = RoundedCornerShape(18.dp),
                                        color = if (isSelected) activeColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                                        border = BorderStroke(
                                            1.5.dp,
                                            if (isSelected) activeColor else Color.White.copy(alpha = 0.1f)
                                        ),
                                        modifier = Modifier.weight(1f).height(74.dp)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = null,
                                                tint = if (isSelected) activeColor else Color.White.copy(alpha = 0.7f),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = label,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }

                            // 6 Liquid Accent Colors
                            Text(
                                text = "Liquid Accent Preset",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.padding(top = 8.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val presets = listOf(
                                    Color(0xFF8B5CF6), // Violet
                                    Color(0xFF06B6D4), // Cyan
                                    Color(0xFF10B981), // Emerald
                                    Color(0xFFF43F5E), // Rose
                                    Color(0xFFF59E0B), // Amber
                                    Color(0xFF3B82F6)  // Blue
                                )

                                presets.forEach { color ->
                                    val isChosen = activeColor == color
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .clickable {
                                                scope.launch {
                                                    prefManager.setAccentColor(color.value.toLong())
                                                    ThemeManager.updateTheme(selectedThemeMode, color)
                                                }
                                            }
                                            .border(
                                                width = if (isChosen) 3.5.dp else 1.dp,
                                                color = if (isChosen) Color.White else Color.White.copy(alpha = 0.3f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isChosen) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 🌟 STEP 4: USER NAME & PROFILE
                    4 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            BubblyStepHeader(
                                badge = "PERSONALIZATION",
                                title = if (currentLang == AppLanguage.URDU) "آپ کا نام کیا ہے؟" else "What Should We Call You?",
                                desc = if (currentLang == AppLanguage.URDU) "اپنا نام درج کریں تاکہ ہوم اسکرین پر ذاتی نوعیت کا تجربہ مل سکے۔" else "Enter your name to personalize your player profile and playlists.",
                                activeColor = activeColor
                            )

                            // Initial Avatar Bubble
                            Box(
                                modifier = Modifier
                                    .size(86.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(listOf(activeColor, Color(0xFF06B6D4)))
                                    )
                                    .border(2.dp, Color.White.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (userNameInput.isNotBlank()) userNameInput.take(1).uppercase() else "L",
                                    fontSize = 36.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }

                            LiquidGlassCard(activeColor = activeColor) {
                                OutlinedTextField(
                                    value = userNameInput,
                                    onValueChange = { userNameInput = it },
                                    placeholder = {
                                        Text(
                                            text = if (currentLang == AppLanguage.URDU) "اپنا نام یہاں لکھیں..." else "Enter your name...",
                                            color = Color.White.copy(alpha = 0.4f)
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                        focusedBorderColor = activeColor,
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    // 🌟 STEP 5: VAULT PIN KEYPAD
                    5 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            BubblyStepHeader(
                                badge = "MANDATORY VAULT SECURITY",
                                title = if (isConfirmStep) {
                                    if (currentLang == AppLanguage.URDU) "پن کوڈ کی تصدیق کریں" else "Confirm Your 4-Digit PIN"
                                } else {
                                    if (currentLang == AppLanguage.URDU) "پرائیویٹ والٹ پن کوڈ بنائیں" else "Create Private Vault PIN"
                                },
                                desc = if (isConfirmStep) "Re-enter the same 4 digits to lock your secure private vault." else "Set a 4-digit code to protect your hidden songs, videos, and private recordings.",
                                activeColor = activeColor
                            )

                            // 4 PIN Capsule Dots
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 12.dp)
                            ) {
                                for (i in 0 until 4) {
                                    val isFilled = enteredPin.length > i
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isFilled) activeColor else Color.White.copy(alpha = 0.12f)
                                            )
                                            .border(
                                                width = 1.5.dp,
                                                color = if (isFilled) Color.White else Color.White.copy(alpha = 0.3f),
                                                shape = CircleShape
                                            )
                                    )
                                }
                            }

                            // Error text
                            if (pinErrorMessage != null) {
                                Text(
                                    text = pinErrorMessage!!,
                                    color = Color(0xFFFF416C),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else if (isVaultPinConfigured) {
                                Text(
                                    text = "✓ PIN Successfully Configured!",
                                    color = Color(0xFF10B981),
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Bubbly Keypad
                            LiquidKeypad(
                                onDigit = { digit ->
                                    if (enteredPin.length < 4) {
                                        enteredPin += digit
                                    }
                                },
                                onDelete = {
                                    if (enteredPin.isNotEmpty()) {
                                        enteredPin = enteredPin.dropLast(1)
                                    }
                                },
                                onClear = {
                                    enteredPin = ""
                                    tempPinFirst = ""
                                    isConfirmStep = false
                                    pinErrorMessage = null
                                }
                            )
                        }
                    }

                    // 🌟 STEP 6: NOTIFICATION PREVIEW & PERMISSION
                    6 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            BubblyStepHeader(
                                badge = "BACKGROUND PLAYBACK",
                                title = if (currentLang == AppLanguage.URDU) "نوٹیفکیشن اور بیک گراؤنڈ پلیئر" else "Media Notification & Lockscreen",
                                desc = "Control songs seamlessly when your phone screen is locked or while using other apps.",
                                activeColor = activeColor
                            )

                            // Realistic Glass Lockscreen Notification Mockup
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = Color.White.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, activeColor.copy(alpha = 0.4f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(12.dp, RoundedCornerShape(22.dp))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // Album art bubble
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(
                                                    Brush.linearGradient(listOf(activeColor, Color(0xFF06B6D4)))
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MusicNote,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Moonlight Resonance (Lossless)",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = "Lerza Audio Engine • 320kbps",
                                                fontSize = 11.5.sp,
                                                color = Color.White.copy(alpha = 0.6f)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Mock playback controls
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = {}) {
                                            Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape)
                                                .background(activeColor)
                                                .clickable { previewIsPlaying = !previewIsPlaying },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (previewIsPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(26.dp)
                                            )
                                        }
                                        IconButton(onClick = {}) {
                                            Icon(Icons.Default.SkipNext, null, tint = Color.White)
                                        }
                                    }
                                }
                            }

                            // Notification Permission Switch Card
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = if (isNotificationAllowed) Color(0xFF10B981).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.05f),
                                border = BorderStroke(
                                    1.dp,
                                    if (isNotificationAllowed) Color(0xFF10B981).copy(alpha = 0.4f) else Color.White.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = if (isNotificationAllowed) Color(0xFF10B981) else activeColor
                                        )
                                        Column {
                                            Text(
                                                text = "Notification Permission",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Text(
                                                text = if (isNotificationAllowed) "Granted & Active" else "Required for background audio",
                                                fontSize = 11.5.sp,
                                                color = Color.White.copy(alpha = 0.6f)
                                            )
                                        }
                                    }

                                    if (isNotificationAllowed) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF10B981).copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "✓ Allowed",
                                                color = Color(0xFF10B981),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else {
                                        Button(
                                            onClick = {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                } else {
                                                    isNotificationAllowed = true
                                                }
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Allow", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 🌟 STEP 7: STORAGE & PERMISSIONS
                    7 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            BubblyStepHeader(
                                badge = "DEVICE ACCESS",
                                title = if (currentLang == AppLanguage.URDU) "اسٹوریج اور میڈیا کی اجازت" else "Storage & Media Permissions",
                                desc = "Lerza Player operates 100% locally on your device. We require permission to discover and play your local audio and video files.",
                                activeColor = activeColor
                            )

                            BubblyPermissionCard(
                                icon = Icons.Default.MusicNote,
                                title = "Music & Audio Tracks",
                                desc = "Scans MP3, FLAC, AAC, WAV and displays high-res album covers.",
                                isGranted = isAudioAllowed,
                                activeColor = activeColor,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }
                            )

                            BubblyPermissionCard(
                                icon = Icons.Default.Videocam,
                                title = "Video Files & Clips",
                                desc = "Hardware-accelerated playback for MP4, MKV, AVI video files.",
                                isGranted = isVideoAllowed,
                                activeColor = Color(0xFF06B6D4),
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_MEDIA_VIDEO)
                                    } else {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }
                            )

                            BubblyPermissionCard(
                                icon = Icons.Default.Folder,
                                title = "All Storage & Vault Access",
                                desc = "Required for folder browsing, playlist creation, and private vault encryption.",
                                isGranted = isAllFilesAllowed,
                                activeColor = Color(0xFF10B981),
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        try {
                                            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                            allFilesPermissionLauncher.launch(intent)
                                        } catch (e: Exception) {
                                            val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                                            allFilesPermissionLauncher.launch(intent)
                                        }
                                    } else {
                                        isAllFilesAllowed = true
                                    }
                                }
                            )
                        }
                    }

                    // 🌟 STEP 8: CELEBRATION & READY TO LAUNCH
                    8 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Spacer(modifier = Modifier.height(8.dp))

                            // Celebration Rocket Orb
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0xFF10B981), Color(0xFF059669))
                                        )
                                    )
                                    .border(2.5.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                    .shadow(20.dp, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RocketLaunch,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(50.dp)
                                )
                            }

                            BubblyStepHeader(
                                badge = "SETUP COMPLETED",
                                title = if (currentLang == AppLanguage.URDU) "مبارک ہو! تیاری مکمل ہے" else "All Set & Ready to Play!",
                                desc = if (currentLang == AppLanguage.URDU) "آپ کا لرزا پلیئر مکمل طور پر ترتیب پا چکا ہے۔ اعلیٰ معیار کی موسیقی کا لطف اٹھائیں۔" else "Your personalized audio engine is primed. Step into next-generation music playback.",
                                activeColor = Color(0xFF10B981)
                            )

                            // Summary Review Card
                            LiquidGlassCard(activeColor = Color(0xFF10B981)) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    ReviewSummaryRow(label = "Selected Language", value = currentLang.displayName)
                                    ReviewSummaryRow(label = "Theme", value = selectedThemeMode.name)
                                    ReviewSummaryRow(label = "Private Vault", value = "Configured & SHA-256 Protected")
                                    ReviewSummaryRow(label = "Storage Permissions", value = "Granted & Indexed")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Modern Bubbly Step Header with glowing gradient text & badge
 */
@Composable
fun BubblyStepHeader(
    badge: String,
    title: String,
    desc: String,
    activeColor: Color
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = activeColor.copy(alpha = 0.15f),
            border = BorderStroke(1.dp, activeColor.copy(alpha = 0.35f))
        ) {
            Text(
                text = badge,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                color = activeColor,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Text(
            text = title,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )
        Text(
            text = desc,
            fontSize = 13.sp,
            color = Color.White.copy(alpha = 0.65f),
            lineHeight = 18.sp
        )
    }
}

/**
 * Frosted Liquid Glass Card container
 */
@Composable
fun LiquidGlassCard(
    activeColor: Color,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF0F172A).copy(alpha = 0.72f),
        border = BorderStroke(
            1.2.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.25f),
                    activeColor.copy(alpha = 0.3f),
                    Color.Transparent
                )
            )
        ),
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(22.dp))
    ) {
        Box(modifier = Modifier.padding(18.dp)) {
            content()
        }
    }
}

/**
 * Feature highlight row with glowing bubble icon
 */
@Composable
fun LiquidFeatureRow(
    icon: ImageVector,
    title: String,
    desc: String,
    activeColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(activeColor.copy(alpha = 0.18f))
                .border(BorderStroke(1.dp, activeColor.copy(alpha = 0.35f)), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = activeColor,
                modifier = Modifier.size(24.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = desc,
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.6f),
                lineHeight = 16.sp
            )
        }
    }
}

/**
 * Bubbly Language Card with native typography and glowing indicator
 */
@Composable
fun BubblyLanguageCard(
    title: String,
    nativeTitle: String,
    isSelected: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) activeColor.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.05f),
        border = BorderStroke(
            1.5.dp,
            if (isSelected) activeColor else Color.White.copy(alpha = 0.12f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = nativeTitle,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) activeColor else Color.White.copy(alpha = 0.08f)
                    )
                    .border(
                        1.dp,
                        if (isSelected) Color.White else Color.White.copy(alpha = 0.2f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Bubbly Permission Card with glowing status pill
 */
@Composable
fun BubblyPermissionCard(
    icon: ImageVector,
    title: String,
    desc: String,
    isGranted: Boolean,
    activeColor: Color,
    onAllow: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isGranted) Color(0xFF10B981).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.05f),
        border = BorderStroke(
            1.2.dp,
            if (isGranted) Color(0xFF10B981).copy(alpha = 0.4f) else Color.White.copy(alpha = 0.12f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isGranted) Color(0xFF10B981).copy(alpha = 0.2f) else activeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isGranted) Color(0xFF10B981) else activeColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = desc,
                    fontSize = 11.5.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    lineHeight = 15.sp
                )
            }

            if (isGranted) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "✓ Granted",
                        color = Color(0xFF10B981),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            } else {
                Button(
                    onClick = onAllow,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Allow", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Tactile bubbly circular keypad for 4-digit PIN creation
 */
@Composable
fun LiquidKeypad(
    onDigit: (String) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("C", "0", "⌫")
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        rows.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)), CircleShape)
                            .clickable {
                                when (key) {
                                    "C" -> onClear()
                                    "⌫" -> onDelete()
                                    else -> onDigit(key)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = key,
                            fontSize = if (key in listOf("C", "⌫")) 16.sp else 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

/**
 * Review summary row for Step 8
 */
@Composable
fun ReviewSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF10B981),
                modifier = Modifier.size(16.dp)
            )
            Text(text = label, fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
        }
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
