package com.lerzaplayer.ui.player

import com.lerzaplayer.ads.AdManager
import com.lerzaplayer.ads.PlayerThumbnailAd
import android.media.RingtoneManager
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.playback.PlayerManager
import androidx.compose.animation.core.RepeatMode
import androidx.compose.ui.graphics.vector.ImageVector
import com.lerzaplayer.data.model.SongLyrics
import com.lerzaplayer.lyrics.LyricsManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.theme.PaletteExtractor
import com.lerzaplayer.ui.common.AddToPlaylistDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.collect
import kotlin.math.roundToInt

@Composable
fun FullPlayerScreen(
    playerManager: PlayerManager,
    onCollapse: () -> Unit,
    onFavoriteToggle: (SongItem) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val configuration = LocalConfiguration.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPosition.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffle.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val sleepMinutes by playerManager.sleepTimerRemainingMinutes.collectAsState()
    val isEqEnabled by com.lerzaplayer.config.RemoteConfigManager.enableEqualizer.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showEqSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsDialog by remember { mutableStateOf(false) }
    var showAddToPlaylistDialog by remember { mutableStateOf(false) }

    var lyricsState by remember { mutableStateOf<SongLyrics?>(null) }
    var isLoadingLyrics by remember { mutableStateOf(false) }
    var lyricsLanguage by remember { mutableStateOf("Original") }

    LaunchedEffect(currentSong?.id) {
        val song = currentSong
        if (song != null) {
            isLoadingLyrics = true
            lyricsState = LyricsManager.getLyricsForSong(context, song)
            isLoadingLyrics = false
        } else {
            lyricsState = null
        }
        lyricsLanguage = "Original"
    }

    val dynamicPalette = remember(currentSong?.id) {
        PaletteExtractor.extractPalette(null, currentSong?.id ?: 0L)
    }

    // सॉलिड اور لائٹ بیک گراؤنڈ کلر تیار کرنا
    val solidLightBackgroundColor = remember(dynamicPalette) {
        val dom = dynamicPalette.dominantColor
        Color(
            red = dom.red + (1f - dom.red) * 0.70f,
            green = dom.green + (1f - dom.green) * 0.70f,
            blue = dom.blue + (1f - dom.blue) * 0.70f,
            alpha = 1f
        )
    }

    val dragOffsetY = remember { androidx.compose.animation.core.Animatable(0f) }
    var isCollapsing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    // Ensure state starts clean whenever the screen opens
    LaunchedEffect(Unit) {
        dragOffsetY.snapTo(0f)
        isCollapsing = false
    }

    // Intercept back press to dismiss with smooth single downward slide
    BackHandler(enabled = !isCollapsing) {
        isCollapsing = true
        coroutineScope.launch {
            dragOffsetY.animateTo(
                targetValue = 2500f,
                animationSpec = androidx.compose.animation.core.tween(
                    durationMillis = 240,
                    easing = androidx.compose.animation.core.FastOutSlowInEasing
                )
            )
            onCollapse()
        }
    }

    val draggableState = rememberDraggableState { delta ->
        if (!isCollapsing && (delta > 0 || dragOffsetY.value > 0)) {
            coroutineScope.launch {
                dragOffsetY.snapTo((dragOffsetY.value + delta).coerceAtLeast(0f))
            }
        }
    }

    val pagerState = rememberPagerState(
        initialPage = currentIndex.coerceAtLeast(0),
        pageCount = { queue.size.coerceAtLeast(1) }
    )

    LaunchedEffect(currentIndex) {
        if (queue.isNotEmpty() && currentIndex in queue.indices && pagerState.currentPage != currentIndex) {
            pagerState.scrollToPage(currentIndex)
        }
    }

    // 🌟 سوائپ ٹو نیکسٹ بگ کا 100% حل: جب بھی یوزر سوائپ مکمل کرے، نیا گانا فوری پلے ہوگا
    LaunchedEffect(pagerState) {
        androidx.compose.runtime.snapshotFlow { pagerState.settledPage }
            .collect { page ->
                if (queue.isNotEmpty() && page in queue.indices && page != playerManager.currentIndex.value) {
                    playerManager.playTrackAtIndex(page)
                }
            }
    }

    val progressFraction = if (duration > 0) {
        (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset { IntOffset(0, dragOffsetY.value.roundToInt()) }
            .graphicsLayer {
                alpha = (1f - (dragOffsetY.value / 800f)).coerceIn(0.1f, 1f)
            }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = { velocity ->
                    if (isCollapsing) return@draggable
                    // If dragged beyond threshold (100f) or flung fast downwards (velocity > 350f)
                    if (dragOffsetY.value > 100f || velocity > 350f) {
                        isCollapsing = true
                        coroutineScope.launch {
                            val target = 2500f
                            val remaining = (target - dragOffsetY.value).coerceAtLeast(50f)
                            val duration = (remaining / 4.0f).roundToInt().coerceIn(160, 260)
                            dragOffsetY.animateTo(
                                targetValue = target,
                                animationSpec = androidx.compose.animation.core.tween(
                                    durationMillis = duration,
                                    easing = androidx.compose.animation.core.FastOutSlowInEasing
                                )
                            )
                            onCollapse()
                            // No snapTo(0f) here! Prevents any double-drop or jump.
                        }
                    } else {
                        coroutineScope.launch {
                            dragOffsetY.animateTo(
                                targetValue = 0f,
                                animationSpec = androidx.compose.animation.core.spring(
                                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioNoBouncy,
                                    stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow
                                )
                            )
                        }
                    }
                }
            )
            .background(solidLightBackgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = {
                        if (!isCollapsing) {
                            isCollapsing = true
                            coroutineScope.launch {
                                dragOffsetY.animateTo(
                                    targetValue = 2500f,
                                    animationSpec = androidx.compose.animation.core.tween(
                                        durationMillis = 240,
                                        easing = androidx.compose.animation.core.FastOutSlowInEasing
                                    )
                                )
                                onCollapse()
                            }
                        }
                    },
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(
                        imageVector = LerzaIcons.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(32.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "LERZA PLAYER",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color(0xFF1C1B1F)
                    )
                }

                IconButton(
                    onClick = { showOptionsSheet = true },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp),
                pageSpacing = 24.dp
            ) { page ->
                val songForPage = queue.getOrNull(page) ?: currentSong
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .shadow(
                                elevation = 20.dp,
                                shape = RoundedCornerShape(24.dp),
                                spotColor = dynamicPalette.accentColor,
                                ambientColor = dynamicPalette.dominantColor
                            )
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF131A26)),
                        contentAlignment = Alignment.Center
                    ) {
                        var isAdLoaded by remember { mutableStateOf(false) }

                        // 🌟 اگر ویب سائٹ پر ماسٹر ایڈز آن ہوں تو تھمب نیل کی جگہ ایڈ شو ہوگا
                        if (AdManager.isMasterAdsEnabled) {
                            PlayerThumbnailAd(
                                modifier = Modifier.fillMaxSize(),
                                onAdLoaded = { loaded: Boolean -> isAdLoaded = loaded }
                            )
                        }

                        // اگر ایڈز آف ہوں یا ابھی ایڈ لوڈ نہ ہوا ہو تو اصل سونگ کا تھمب نیل نظر آئے گا
                        if (!AdManager.isMasterAdsEnabled || !isAdLoaded) {
                            if (songForPage?.albumArtUri != null) {
                                AsyncImage(
                                    model = songForPage.albumArtUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                val pageSong = songForPage ?: currentSong
                                val sId = pageSong?.id ?: 0L
                                val sTitle = pageSong?.title ?: ""
                                val themeIdx = kotlin.math.abs((sId.hashCode() xor (sTitle.hashCode() * 31))) % 4
                                val (gradColors: List<Color>, artIcon: ImageVector) = when (themeIdx) {
                                    0 -> listOf(Color(0xFF00C6FF), Color(0xFF0072FF)) to LerzaIcons.MusicNote
                                    1 -> listOf(Color(0xFFFF0844), Color(0xFFFFB199)) to LerzaIcons.Headphones
                                    2 -> listOf(Color(0xFF00E676), Color(0xFF00B0FF)) to LerzaIcons.GraphicEq
                                    else -> listOf(Color(0xFFF355DA), Color(0xFF7000FF)) to LerzaIcons.Album
                                }

                                val infiniteTransition = rememberInfiniteTransition(label = "vinylSpin")
                                val vinylAngle by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = 360f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(12000, easing = LinearEasing),
                                        repeatMode = RepeatMode.Restart
                                    ),
                                    label = "vinylAngle"
                                )
                                val effectiveAngle = if (isPlaying) vinylAngle else 0f

                                Box(
                                    modifier = Modifier
                                        .size(240.dp)
                                        .graphicsLayer { rotationZ = effectiveAngle }
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(
                                                    Color(0xFF22222B),
                                                    Color(0xFF14141A),
                                                    Color(0xFF0D0D12),
                                                    Color(0xFF191922)
                                                )
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val r = size.minDimension / 2f
                                        drawCircle(color = Color.White.copy(alpha = 0.08f), radius = r * 0.88f, style = Stroke(width = 1.dp.toPx()))
                                        drawCircle(color = Color.White.copy(alpha = 0.05f), radius = r * 0.74f, style = Stroke(width = 1.dp.toPx()))
                                        drawCircle(color = Color.White.copy(alpha = 0.07f), radius = r * 0.60f, style = Stroke(width = 1.dp.toPx()))
                                        drawCircle(color = Color.White.copy(alpha = 0.05f), radius = r * 0.46f, style = Stroke(width = 1.dp.toPx()))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(96.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(colors = gradColors)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = artIcon,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(42.dp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF0A0A0E))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Song Title & Artist + Favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentSong?.title ?: "No Track Playing",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1C1B1F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentSong?.artist ?: "Unknown Artist",
                        fontSize = 14.sp,
                        color = Color(0xFF49454F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = {
                        currentSong?.let { song ->
                            onFavoriteToggle(song)
                        }
                    },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (currentSong?.isFavorite == true) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (currentSong?.isFavorite == true) Color(0xFFFF334B) else Color(0xFF1C1B1F).copy(alpha = 0.7f),
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider & Timing
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        val targetMs = (frac * duration).toLong()
                        playerManager.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = dynamicPalette.accentColor,
                        activeTrackColor = dynamicPalette.accentColor,
                        inactiveTrackColor = Color.Black.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val posSec = currentPosition / 1000
                    val durSec = duration / 1000
                    Text(
                        text = "%d:%02d".format(posSec / 60, posSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF49454F)
                    )
                    Text(
                        text = "%d:%02d".format(durSec / 60, durSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF49454F)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Playback Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { playerManager.toggleShuffle() }) {
                    Icon(
                        imageVector = LerzaIcons.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) Color(0xFF00B0FF) else Color(0xFF1C1B1F).copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.playPreviousTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(38.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF00B0FF))
                            )
                        )
                        .clickable { playerManager.playPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(40.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.playNextTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipNext,
                        contentDescription = "Next",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { playerManager.cycleRepeatMode() }) {
                    Icon(
                        imageVector = if (repeatMode == 1) LerzaIcons.RepeatOne else LerzaIcons.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode != 0) Color(0xFF00B0FF) else Color(0xFF1C1B1F).copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Auxiliary Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (isEqEnabled) {
                    IconButton(onClick = { showEqSheet = true }) {
                        Icon(
                            imageVector = LerzaIcons.Tune,
                            contentDescription = "Equalizer",
                            tint = Color(0xFF1C1B1F).copy(alpha = 0.8f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(24.dp))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                        .clickable { showLyricsDialog = true }
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lyrics,
                            contentDescription = null,
                            tint = Color(0xFF1C1B1F),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Lyrics",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1C1B1F)
                        )
                    }
                }

                IconButton(onClick = { showQueueSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color(0xFF1C1B1F).copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    // 🌟 FullPlayerOptionsSheet
    if (showOptionsSheet && currentSong != null) {
        FullPlayerOptionsSheet(
            song = currentSong!!,
            playerManager = playerManager,
            dynamicPalette = dynamicPalette,
            onDismiss = { showOptionsSheet = false },
            onAddToPlaylist = {
                showAddToPlaylistDialog = true
            },
            onHideInVault = {
                currentSong?.let { song ->
                    (context.applicationContext as? com.lerzaplayer.LerzaApp)?.vaultManager?.let { vault ->
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            vault.hideSong(song)
                        }
                    }
                }
            },
            onDeleteSong = {
                currentSong?.let { song ->
                    onCollapse()
                    (context as? com.lerzaplayer.MainActivity)?.let { activity ->
                        activity.lifecycleScope.launch {
                            com.lerzaplayer.data.repository.MediaRepository(context).deleteMedia(song)
                        }
                    }
                }
            }
        )
    }

    // 🌟 AddToPlaylistDialog Display
    if (showAddToPlaylistDialog && currentSong != null) {
        AddToPlaylistDialog(
            songs = listOf(currentSong!!),
            onDismiss = { showAddToPlaylistDialog = false }
        )
    }

    if (showEqSheet) {
        EqualizerSheet(
            playerManager = playerManager,
            dynamicPalette = dynamicPalette,
            onDismiss = { showEqSheet = false }
        )
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF131A26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playing Queue (${queue.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    TextButton(onClick = { playerManager.clearQueue() }) {
                        Text("Clear All", color = Color(0xFFFF334B))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                queue.forEachIndexed { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { playerManager.playSongList(queue, index) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            fontSize = 13.sp,
                            color = if (index == currentIndex) Color(0xFF00E5FF) else Color.Gray,
                            modifier = Modifier.width(28.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (song.albumArtUri != null) {
                                AsyncImage(
                                    model = song.albumArtUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    LerzaIcons.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.65f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                fontSize = 14.sp,
                                fontWeight = if (index == currentIndex) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == currentIndex) Color(0xFF00E5FF) else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        IconButton(onClick = { playerManager.removeFromQueue(index) }) {
                            Icon(LerzaIcons.Close, contentDescription = "Remove", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    if (showLyricsDialog && currentSong != null) {
        val song = currentSong!!
        val dom = dynamicPalette.dominantColor
        val lyricsSheetBg = Color(
            red = (dom.red * 0.18f).coerceIn(0.08f, 0.20f),
            green = (dom.green * 0.17f).coerceIn(0.07f, 0.18f),
            blue = (dom.blue * 0.17f).coerceIn(0.07f, 0.18f),
            alpha = 0.98f
        )
        val accent = dynamicPalette.accentColor

        var selectedLanguage by remember { mutableStateOf("Original") }
        var showTranslateMenu by remember { mutableStateOf(false) }

        val currentLines = remember(lyricsState, selectedLanguage) {
            if (selectedLanguage == "Original") {
                lyricsState?.lines ?: emptyList()
            } else {
                com.lerzaplayer.lyrics.LyricsManager.generateAILyricsBySong(song, selectedLanguage)
            }
        }

        val lyricsListState = androidx.compose.foundation.lazy.rememberLazyListState()
        val activeLyricIndex = remember(currentPosition, currentLines) {
            currentLines.indexOfLast { currentPosition >= it.timestampMs }
        }

        LaunchedEffect(activeLyricIndex) {
            if (activeLyricIndex >= 0) {
                try {
                    lyricsListState.animateScrollToItem(maxOf(0, activeLyricIndex - 2))
                } catch (e: Exception) {}
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showLyricsDialog = false },
            containerColor = lyricsSheetBg,
            contentColor = Color.White,
            dragHandle = {
                Box(
                    Modifier
                        .padding(top = 10.dp, bottom = 4.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f)
                    .navigationBarsPadding()
                    .padding(horizontal = 22.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (song.albumArtUri != null) {
                            AsyncImage(
                                model = song.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(LerzaIcons.MusicNote, contentDescription = null, tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = song.artist,
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(
                        onClick = { playerManager.playPause() },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lyrics",
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box {
                            Surface(
                                onClick = { showTranslateMenu = true },
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Translate,
                                        contentDescription = "Translate",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = selectedLanguage,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showTranslateMenu,
                                onDismissRequest = { showTranslateMenu = false },
                                modifier = Modifier.background(Color(0xFF1E2628))
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Original (اصلی)", color = Color.White) },
                                    onClick = { selectedLanguage = "Original"; showTranslateMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("Urdu (اردو میں)", color = Color.White) },
                                    onClick = { selectedLanguage = "Urdu"; showTranslateMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("Hindi (हिंदी میں)", color = Color.White) },
                                    onClick = { selectedLanguage = "Hindi"; showTranslateMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("English (انگریزی میں)", color = Color.White) },
                                    onClick = { selectedLanguage = "English"; showTranslateMenu = false }
                                )
                            }
                        }

                        IconButton(onClick = {
                            android.widget.Toast.makeText(context, "Tap any line to jump audio to that point", android.widget.Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit",
                                tint = Color.White.copy(alpha = 0.75f),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(onClick = { showLyricsDialog = false }) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Close",
                                tint = Color.White.copy(alpha = 0.75f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                val aiHeadingText = when (selectedLanguage) {
                    "Urdu" -> "یہ مواد AI کی مدد سے تیار کیا گیا ہے"
                    "Hindi" -> "यह AI जनरेटेड सामग्री ہے"
                    else -> "This is AI generated content"
                }

                Text(
                    text = aiHeadingText,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFFFD494),
                    letterSpacing = 0.3.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (currentLines.isNotEmpty()) {
                    androidx.compose.foundation.lazy.LazyColumn(
                        state = lyricsListState,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(currentLines.size) { idx ->
                            val line = currentLines[idx]
                            val isActive = idx == activeLyricIndex

                            Text(
                                text = line.text,
                                fontSize = if (isActive) 19.sp else 16.5.sp,
                                fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isActive) Color.White else Color.White.copy(alpha = 0.42f),
                                lineHeight = 28.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        playerManager.seekTo(line.timestampMs)
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = accent)
                    }
                }
            }
        }
    }
}
