package com.lerzaplayer.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R
import com.lerzaplayer.analytics.FirebaseSyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class LerzaFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New Firebase Cloud Messaging Token: $token")
        FirebaseSyncManager.updateFcmToken(applicationContext, token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "From: ${remoteMessage.from}")

        val title = remoteMessage.notification?.title 
            ?: remoteMessage.data["title"] 
            ?: "Lerza Player"
        val body = remoteMessage.notification?.body 
            ?: remoteMessage.data["body"] 
            ?: "Enjoy your favorite music and video experience!"

        val targetUrl = remoteMessage.data["url"] ?: remoteMessage.data["deep_link"]
        val imageUrl = remoteMessage.notification?.imageUrl?.toString() ?: remoteMessage.data["image_url"]

        serviceScope.launch {
            sendNotification(title, body, targetUrl, imageUrl)
        }
    }

    private suspend fun sendNotification(title: String, messageBody: String, targetUrl: String?, imageUrl: String?) {
        val pendingIntent: PendingIntent = if (!targetUrl.isNullOrBlank() &&
            (targetUrl.startsWith("http://", ignoreCase = true) || targetUrl.startsWith("https://", ignoreCase = true))) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            PendingIntent.getActivity(
                this,
                (System.currentTimeMillis() % 10000).toInt(),
                browserIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else {
            val appIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                if (!targetUrl.isNullOrBlank()) {
                    putExtra("extra_target_url", targetUrl)
                }
            }
            PendingIntent.getActivity(
                this,
                (System.currentTimeMillis() % 10000).toInt(),
                appIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val channelId = getString(R.string.default_notification_channel_id).ifBlank { "lerza_notifications_channel" }
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val brandLogoBitmap: Bitmap? = try {
            BitmapFactory.decodeResource(resources, R.drawable.brand_logo)
        } catch (e: Exception) {
            null
        }

        var bannerBitmap: Bitmap? = null
        if (!imageUrl.isNullOrBlank() && (imageUrl.startsWith("http://") || imageUrl.startsWith("https://"))) {
            bannerBitmap = withContext(Dispatchers.IO) {
                try {
                    val url = URL(imageUrl)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.connectTimeout = 4000
                    conn.readTimeout = 4000
                    conn.doInput = true
                    conn.connect()
                    val stream = conn.inputStream
                    BitmapFactory.decodeStream(stream)
                } catch (e: Exception) {
                    null
                }
            }
        }

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.brand_logo)
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)

        if (brandLogoBitmap != null) {
            notificationBuilder.setLargeIcon(brandLogoBitmap)
        }

        if (bannerBitmap != null) {
            notificationBuilder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(bannerBitmap)
                    .setBigContentTitle(title)
                    .setSummaryText(messageBody)
            )
        } else {
            notificationBuilder.setStyle(
                NotificationCompat.BigTextStyle().bigText(messageBody)
            )
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Lerza Player Announcements",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Updates, features, and playback notifications for Lerza Player"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notificationId = (System.currentTimeMillis() % 10000).toInt()
        notificationManager.notify(notificationId, notificationBuilder.build())
    }

    companion object {
        private const val TAG = "LerzaFCMService"
    }
}
