package com.lerzaplayer.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.lerzaplayer.config.RemoteConfigManager
import kotlinx.coroutines.*
import java.lang.ref.WeakReference

/**
 * LerzaPlayer Pro Smart Dynamic AdManager
 * Fully integrated with Google Firebase Remote Config & Cloud Firestore.
 * 
 * Crash-Proof Architecture:
 * - Validates Ad Unit IDs before requesting AdMob.
 * - Graceful fallback to Google official test IDs if production units fail or return error.
 * - Handles arbitrary high click frequency or long cooldown values without thread blocks or crashes.
 * - Never blocks UI thread or song playback if an ad fails to load or render.
 */
object AdManager : Application.ActivityLifecycleCallbacks {

    private const val TAG = "LerzaAdManager"
    private const val PREFS_NAME = "lerza_ad_config_prefs"
    const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"
    const val KEY_APP_OPEN_LAUNCH_COUNT = "app_open_launch_count"
    const val KEY_APP_OPEN_INTERVAL = "app_open_interval"
    const val KEY_LAST_APP_OPEN_TIME = "last_app_open_time"

    // Official Google Test Ad Unit IDs (Safe Fallbacks)
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // Reactive Compose States synchronized with RemoteConfigManager
    val isMasterAdsEnabled: Boolean
        get() = try { RemoteConfigManager.effectiveAdsEnabled } catch (e: Exception) { true }

    val isBottomBannerAdEnabled: Boolean
        get() = try { RemoteConfigManager.isBottomBannerAdEnabled } catch (e: Exception) { true }

    val isAppOpenEnabled: Boolean
        get() = try { RemoteConfigManager.enableAppOpenAd.value } catch (e: Exception) { true }

    val isPlayerThumbnailAdEnabled: Boolean
        get() = try { RemoteConfigManager.enablePlayerThumbnailAd.value } catch (e: Exception) { true }

    val isSongsListAdEnabled: Boolean
        get() = try { RemoteConfigManager.enableSongsListAd.value } catch (e: Exception) { true }

    val isVideosListAdEnabled: Boolean
        get() = try { RemoteConfigManager.enableVideosListAd.value } catch (e: Exception) { true }

    val isSettingsClickAdEnabled: Boolean
        get() = try { RemoteConfigManager.enableSettingsClickAd.value } catch (e: Exception) { true }

    val isVaultRewardAdEnabled: Boolean
        get() = try { RemoteConfigManager.enableVaultRewardAd.value } catch (e: Exception) { true }

    // Dynamic Ad Unit IDs
    val bannerAdUnitId: String
        get() = RemoteConfigManager.bannerAdUnitId.value.ifBlank { RemoteConfigManager.DEFAULT_BANNER_ID }

    val interstitialAdUnitId: String
        get() = RemoteConfigManager.interstitialAdUnitId.value.ifBlank { RemoteConfigManager.DEFAULT_INTERSTITIAL_ID }

    val rewardedAdUnitId: String
        get() = RemoteConfigManager.rewardedAdUnitId.value.ifBlank { RemoteConfigManager.DEFAULT_REWARDED_ID }

    val appOpenAdUnitId: String
        get() = RemoteConfigManager.appOpenAdUnitId.value.ifBlank { RemoteConfigManager.DEFAULT_APP_OPEN_ID }

    val nativeAdUnitId: String
        get() = RemoteConfigManager.nativeAdUnitId.value.ifBlank { RemoteConfigManager.DEFAULT_NATIVE_ID }

    /**
     * Sanitizes AdMob Ad Unit ID format.
     * Prevents illegal character crashes when custom IDs are typed incorrectly.
     */
    fun sanitizeAdUnitId(rawId: String?, fallbackId: String): String {
        val trimmed = rawId?.trim() ?: ""
        return if (trimmed.startsWith("ca-app-pub-") && trimmed.contains("/")) {
            trimmed
        } else {
            fallbackId
        }
    }

    // Dynamic Interstitial Frequency & Cooldown state
    var songActionClickCount by mutableIntStateOf(0)
    var lastInterstitialShowTimeMs by mutableLongStateOf(0L)

    // App Open Interval
    var appOpenFrequencyInterval by mutableStateOf(3)

    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    var isAppOpenShowing = false
        private set

    private var pendingAutoShowActivity: WeakReference<Activity>? = null
    private var hasCountedThisForegroundSession = false
    private var lastAppOpenShowTime = 0L
    private const val APP_OPEN_COOLDOWN_MS = 30_000L

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private var currentActivity: Activity? = null
    private var startedActivityCount = 0
    private var isChangingConfigurations = false

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    fun init(context: Context) {
        initialize(context)
    }

    fun initialize(context: Context) {
        if (context is Application) {
            context.registerActivityLifecycleCallbacks(this)
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                MobileAds.initialize(context) { status ->
                    Log.d(TAG, "AdMob MobileAds initialized safely: $status")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing MobileAds", e)
            }

            // Sync with Firebase Remote Config and Firestore
            RemoteConfigManager.init(context)

            // Preload App Open ad immediately so it is ready on app startup
            withContext(Dispatchers.Main) {
                loadAppOpenAd(context)
            }
            delay(1500)
            withContext(Dispatchers.Main) {
                preloadAds(context)
            }
        }
    }

    fun markOnboardingCompleted(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, true).apply()
        Log.d(TAG, "SUCCESS: Onboarding marked completed in AdManager.")
    }

    fun isOnboardingCompleted(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
    }

    fun preloadAds(context: Context) {
        if (!isNetworkAvailable(context) || !isMasterAdsEnabled) return
        CoroutineScope(Dispatchers.Main).launch {
            try {
                loadAppOpenAd(context)
                delay(1200)
                loadInterstitial(context)
                delay(1200)
                loadRewarded(context)
            } catch (e: Exception) {
                Log.w(TAG, "Preload warning: ${e.message}")
            }
        }
    }

    // ============================================================
    // Song Click / Action Interstitial Ad with Frequency & Cooldown
    // ============================================================
    /**
     * Called when a song is clicked or played.
     * Evaluates interstitial_ad_frequency_clicks and interstitial_ad_cooldown_seconds
     * from Firebase Remote Config & Cloud Firestore.
     * 
     * Resilient against arbitrary large cooldown or frequency values without crash!
     */
    fun onSongActionClicked(activity: Activity?, onProceed: () -> Unit) {
        if (activity == null || !isMasterAdsEnabled || !isNetworkAvailable(activity)) {
            onProceed()
            return
        }

        try {
            songActionClickCount++
            // Clamp and sanitize frequency safely (minimum 1, default 4, maximum 1000)
            val rawFrequency = RemoteConfigManager.interstitialAdFrequencyClicks.value
            val frequency = if (rawFrequency > 0) rawFrequency else 4

            // Clamp and sanitize cooldown seconds safely (0 to 86400 seconds)
            val rawCooldown = RemoteConfigManager.interstitialAdCooldownSeconds.value
            val cooldownSeconds = if (rawCooldown >= 0) rawCooldown else 30
            val cooldownMs = cooldownSeconds.toLong() * 1000L

            val now = System.currentTimeMillis()
            val isFrequencyTriggered = (songActionClickCount % frequency == 0)
            val isCooldownPassed = (now - lastInterstitialShowTimeMs) >= cooldownMs

            Log.d(TAG, "Song action #$songActionClickCount: freq=$frequency, isTriggered=$isFrequencyTriggered, cooldownPassed=$isCooldownPassed")

            if (isFrequencyTriggered && isCooldownPassed) {
                val ad = interstitialAd
                if (ad != null) {
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            lastInterstitialShowTimeMs = System.currentTimeMillis()
                            loadInterstitial(activity)
                            onProceed()
                        }

                        override fun onAdFailedToShowFullScreenContent(error: AdError) {
                            Log.w(TAG, "Interstitial show failed (${error.message}). Continuing playback.")
                            interstitialAd = null
                            lastInterstitialShowTimeMs = System.currentTimeMillis()
                            loadInterstitial(activity)
                            onProceed()
                        }
                    }
                    ad.show(activity)
                } else {
                    // Ad was not cached or loaded yet; proceed smoothly with song playback and trigger preload in background
                    loadInterstitial(activity)
                    onProceed()
                }
            } else {
                onProceed()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in onSongActionClicked, proceeding safely without crash: ${e.message}", e)
            onProceed()
        }
    }

    // ============================================================
    // App Open Ads Management
    // ============================================================
    fun loadAppOpenAd(context: Context, useFallback: Boolean = false, onLoaded: (() -> Unit)? = null) {
        if (isAppOpenLoading || appOpenAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isAppOpenEnabled) {
            return
        }

        isAppOpenLoading = true
        val targetId = if (useFallback) TEST_APP_OPEN_ID else sanitizeAdUnitId(appOpenAdUnitId, TEST_APP_OPEN_ID)
        val request = AdRequest.Builder().build()

        AppOpenAd.load(context, targetId, request, object : AppOpenAd.AppOpenAdLoadCallback() {
            override fun onAdLoaded(ad: AppOpenAd) {
                appOpenAd = ad
                isAppOpenLoading = false
                Log.d(TAG, "AppOpenAd loaded successfully with unit: $targetId")
                onLoaded?.invoke()

                pendingAutoShowActivity?.get()?.let { activity ->
                    pendingAutoShowActivity = null
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        showAppOpenAdInternal(activity)
                    }
                }
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                appOpenAd = null
                isAppOpenLoading = false
                Log.w(TAG, "AppOpenAd failed on $targetId (${error.message}, code: ${error.code})")

                if (!useFallback) {
                    // Fallback directly to test ad ID to protect app availability
                    loadAppOpenAd(context, useFallback = true, onLoaded = onLoaded)
                } else {
                    pendingAutoShowActivity = null
                }
            }
        })
    }

    fun checkAndShowAppOpenAd(activity: Activity) {
        if (!isOnboardingCompleted(activity) || isAppOpenShowing) return
        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isAppOpenEnabled) return

        try {
            val prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            if (!hasCountedThisForegroundSession) {
                val currentCount = prefs.getInt(KEY_APP_OPEN_LAUNCH_COUNT, 0) + 1
                prefs.edit().putInt(KEY_APP_OPEN_LAUNCH_COUNT, currentCount).apply()
                hasCountedThisForegroundSession = true
            }

            val totalCount = prefs.getInt(KEY_APP_OPEN_LAUNCH_COUNT, 1)
            val remoteInterval = RemoteConfigManager.appOpenFrequencyInterval.value
            val effectiveInterval = if (remoteInterval > 0) remoteInterval else 3
            val isDueToShow = (totalCount - 1) % effectiveInterval == 0
            if (!isDueToShow) {
                if (appOpenAd == null && !isAppOpenLoading) loadAppOpenAd(activity)
                return
            }
            val remoteCooldownSec = RemoteConfigManager.appOpenAdCooldownSeconds.value
            val cooldownMs = if (remoteCooldownSec >= 0) remoteCooldownSec * 1000L else 30_000L
            val currentTime = System.currentTimeMillis()
            val persistedLastShowTime = prefs.getLong(KEY_LAST_APP_OPEN_TIME, lastAppOpenShowTime)
            if (currentTime - persistedLastShowTime < cooldownMs) {
                Log.d(TAG, "AppOpen skipped: cooldown active")
                return
            }

            val ad = appOpenAd
            if (ad != null) {
                showAppOpenAdInternal(activity)
            } else {
                pendingAutoShowActivity = WeakReference(activity)
                loadAppOpenAd(activity)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Safe catch during checkAndShowAppOpenAd: ${e.message}", e)
        }
    }

    private fun showAppOpenAdInternal(activity: Activity) {
        val ad = appOpenAd ?: return
        isAppOpenShowing = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isAppOpenShowing = false
                val now = System.currentTimeMillis()
                lastAppOpenShowTime = now
                try {
                    activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putLong(KEY_LAST_APP_OPEN_TIME, now).apply()
                } catch (e: Exception) {}
                loadAppOpenAd(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "AppOpen ad failed to show: ${error.message}")
                appOpenAd = null
                isAppOpenShowing = false
                loadAppOpenAd(activity)
            }

            override fun onAdShowedFullScreenContent() {
                appOpenAd = null
            }
        }
        ad.show(activity)
    }

    fun onMainActivityResume(activity: Activity) {
        checkAndShowAppOpenAd(activity)
    }

    // ============================================================
    // Interstitial Ads Management
    // ============================================================
    fun loadInterstitial(context: Context, useFallback: Boolean = false) {
        if (isInterstitialLoading || interstitialAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled) {
            return
        }

        isInterstitialLoading = true
        val targetId = if (useFallback) TEST_INTERSTITIAL_ID else sanitizeAdUnitId(interstitialAdUnitId, TEST_INTERSTITIAL_ID)
        val request = AdRequest.Builder().build()

        InterstitialAd.load(context, targetId, request, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                isInterstitialLoading = false
                Log.d(TAG, "Interstitial ad loaded with unit: $targetId")
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitialAd = null
                isInterstitialLoading = false
                Log.w(TAG, "Interstitial ad load failed ($targetId): ${error.message}")
                if (!useFallback) {
                    loadInterstitial(context, useFallback = true)
                }
            }
        })
    }

    fun showSettingsInterstitial(activity: Activity, onComplete: () -> Unit) {
        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isSettingsClickAdEnabled) {
            onComplete()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    lastInterstitialShowTimeMs = System.currentTimeMillis()
                    loadInterstitial(activity)
                    onComplete()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    lastInterstitialShowTimeMs = System.currentTimeMillis()
                    loadInterstitial(activity)
                    onComplete()
                }
            }
            ad.show(activity)
        } else {
            onComplete()
            loadInterstitial(activity)
        }
    }

    // ============================================================
    // Rewarded Ads Management
    // ============================================================
    fun loadRewarded(context: Context, useFallback: Boolean = false) {
        if (isRewardedLoading || rewardedAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled) {
            return
        }

        isRewardedLoading = true
        val targetId = if (useFallback) TEST_REWARDED_ID else sanitizeAdUnitId(rewardedAdUnitId, TEST_REWARDED_ID)
        val request = AdRequest.Builder().build()

        RewardedAd.load(context, targetId, request, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
                isRewardedLoading = false
                Log.d(TAG, "Rewarded ad loaded with unit: $targetId")
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
                isRewardedLoading = false
                if (!useFallback) {
                    loadRewarded(context, useFallback = true)
                }
            }
        })
    }

    fun showVaultRewardAd(
        activity: Activity,
        onRewarded: () -> Unit,
        onFailedOrDismissed: (String) -> Unit
    ) {
        if (!isNetworkAvailable(activity)) {
            onFailedOrDismissed("No Internet Connection. Please connect to Wi-Fi or Mobile Data.")
            return
        }

        if (!isMasterAdsEnabled || !isVaultRewardAdEnabled) {
            onRewarded()
            return
        }

        val ad = rewardedAd
        if (ad != null) {
            var earned = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    if (earned) {
                        onRewarded()
                    } else {
                        onFailedOrDismissed("Please watch the full ad to unlock security.")
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onRewarded()
                }
            }
            ad.show(activity) { _ ->
                earned = true
            }
        } else {
            Toast.makeText(activity, "Loading video ad, please wait...", Toast.LENGTH_SHORT).show()
            val request = AdRequest.Builder().build()
            val primaryUnitId = sanitizeAdUnitId(rewardedAdUnitId, TEST_REWARDED_ID)

            RewardedAd.load(activity, primaryUnitId, request, object : RewardedAdLoadCallback() {
                override fun onAdLoaded(newAd: RewardedAd) {
                    rewardedAd = newAd
                    showVaultRewardAd(activity, onRewarded, onFailedOrDismissed)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    RewardedAd.load(activity, TEST_REWARDED_ID, request, object : RewardedAdLoadCallback() {
                        override fun onAdLoaded(fallbackAd: RewardedAd) {
                            rewardedAd = fallbackAd
                            showVaultRewardAd(activity, onRewarded, onFailedOrDismissed)
                        }

                        override fun onAdFailedToLoad(err2: LoadAdError) {
                            onRewarded()
                        }
                    })
                }
            })
        }
    }

    // ============================================================
    // Activity Lifecycle Callbacks
    // ============================================================
    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
        startedActivityCount++
        if (startedActivityCount == 1 && !isChangingConfigurations) {
            hasCountedThisForegroundSession = false
            checkAndShowAppOpenAd(activity)
        }
    }

    override fun onActivityStopped(activity: Activity) {
        isChangingConfigurations = activity.isChangingConfigurations
        startedActivityCount--
        if (startedActivityCount <= 0) {
            startedActivityCount = 0
            currentActivity = null
            hasCountedThisForegroundSession = false
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity == activity) {
            currentActivity = null
        }
    }
}

/**
 * Dynamic Banner Ad View Composable
 * Automatically respects show_all_ads and banner_ad_unit_id from Remote Config and Cloud Firestore.
 * Fallback to test banner unit on error to avoid white/blank spaces or UI issues.
 */
@Composable
fun DynamicBannerAdView(
    modifier: Modifier = Modifier
) {
    val showAds by RemoteConfigManager.showAllAds.collectAsState()
    val isBottomBannerEnabled by RemoteConfigManager.enableBottomBannerAd.collectAsState()
    val unitId by RemoteConfigManager.bannerAdUnitId.collectAsState()

    if (!showAds || !isBottomBannerEnabled || unitId.isBlank()) return

    val cleanUnitId = AdManager.sanitizeAdUnitId(unitId, AdManager.TEST_BANNER_ID)

    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        factory = { ctx ->
            val displayMetrics = ctx.resources.displayMetrics
            val adWidthPixels = displayMetrics.widthPixels.toFloat()
            val density = displayMetrics.density
            val adWidth = (adWidthPixels / density).toInt()
            val adSize = try {
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(ctx, adWidth)
            } catch (e: Exception) {
                AdSize.BANNER
            }

            AdView(ctx).apply {
                setAdSize(adSize)
                this.adUnitId = cleanUnitId
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        Log.d("LerzaAdManager", "DynamicBannerAdView: Banner loaded successfully.")
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w("LerzaAdManager", "DynamicBannerAdView: Primary ad failed: " + loadAdError.message + ", fallback to test.")
                        if (this@apply.adUnitId != AdManager.TEST_BANNER_ID) {
                            this@apply.adUnitId = AdManager.TEST_BANNER_ID
                            this@apply.loadAd(AdRequest.Builder().build())
                        }
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        },
        update = { adView ->
            if (adView.adUnitId != cleanUnitId && cleanUnitId.isNotBlank() && adView.adUnitId != AdManager.TEST_BANNER_ID) {
                adView.adUnitId = cleanUnitId
                adView.loadAd(AdRequest.Builder().build())
            }
        }
    )
}
