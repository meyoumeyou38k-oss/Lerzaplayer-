package com.lerzaplayer.playback

import com.lerzaplayer.LerzaApp
import com.lerzaplayer.R
import kotlinx.coroutines.flow.first

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.media.AudioManager
import android.content.Intent
import android.os.Bundle
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var playerManager: PlayerManager

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                if (playerManager.autoPauseHeadphones.value) {
                    playerManager.pause()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        playerManager = PlayerManager.getInstance(this)
        registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))

        // ForwardingPlayer guarantees that Next & Previous commands remain available
        // to Android System Media Controls (Android 13/14/15) even when ExoPlayer
        // manages tracks individually.
        val forwardingPlayer = object : ForwardingPlayer(playerManager.exoPlayer) {
            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return command == Player.COMMAND_SEEK_TO_NEXT ||
                        command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM ||
                        command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                        command == Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM ||
                        super.isCommandAvailable(command)
            }

            override fun seekToNext() {
                playerManager.playNextTrack()
            }

            override fun seekToNextMediaItem() {
                playerManager.playNextTrack()
            }

            override fun seekToPrevious() {
                playerManager.playPreviousTrack()
            }

            override fun seekToPreviousMediaItem() {
                playerManager.playPreviousTrack()
            }

            override fun hasNextMediaItem(): Boolean {
                return true
            }

            override fun hasPreviousMediaItem(): Boolean {
                return true
            }
        }

        val sessionCallback = object : MediaSession.Callback {
            override fun onConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo
            ): MediaSession.ConnectionResult {
                val connectionResult = super.onConnect(session, controller)
                val sessionCommands = connectionResult.availableSessionCommands.buildUpon()
                    .add(SessionCommand(ACTION_FAVORITE, Bundle.EMPTY))
                    .add(SessionCommand(ACTION_CLOSE, Bundle.EMPTY))
                    .build()

                val availablePlayerCommands = connectionResult.availablePlayerCommands.buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .build()

                val isFav = playerManager.currentSong.value?.isFavorite == true
                val favCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
                val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
                val favButton = CommandButton.Builder()
                    .setDisplayName(if (isFav) "Favorited" else "Favorite")
                    .setIconResId(if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border)
                    .setSessionCommand(favCommand)
                    .setEnabled(true)
                    .build()
                val closeButton = CommandButton.Builder()
                    .setDisplayName("Close")
                    .setIconResId(R.drawable.ic_close)
                    .setSessionCommand(closeCommand)
                    .setEnabled(true)
                    .build()

                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(sessionCommands)
                    .setAvailablePlayerCommands(availablePlayerCommands)
                    .setCustomLayout(listOf(favButton, closeButton))
                    .build()
            }

            override fun onPostConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo
            ) {
                super.onPostConnect(session, controller)
                val isFav = playerManager.currentSong.value?.isFavorite == true
                val favCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
                val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
                val favButton = CommandButton.Builder()
                    .setDisplayName(if (isFav) "Favorited" else "Favorite")
                    .setIconResId(if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border)
                    .setSessionCommand(favCommand)
                    .setEnabled(true)
                    .build()
                val closeButton = CommandButton.Builder()
                    .setDisplayName("Close")
                    .setIconResId(R.drawable.ic_close)
                    .setSessionCommand(closeCommand)
                    .setEnabled(true)
                    .build()
                session.setCustomLayout(controller, listOf(favButton, closeButton))
            }

            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                customCommand: SessionCommand,
                args: Bundle
            ): ListenableFuture<SessionResult> {
                when (customCommand.customAction) {
                    ACTION_FAVORITE -> {
                        toggleFavorite()
                        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                    }
                    ACTION_CLOSE -> {
                        closePlaybackAndNotification()
                        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                    }
                }
                return super.onCustomCommand(session, controller, customCommand, args)
            }
        }

        mediaSession = MediaSession.Builder(this, forwardingPlayer)
            .setCallback(sessionCallback)
            .build()

        // Set custom MediaNotification.Provider so Media3 builds notification with Heart & Close buttons
        val customNotificationProvider = object : androidx.media3.session.DefaultMediaNotificationProvider(this) {
            override fun getMediaButtons(
                session: MediaSession,
                playerCommands: Player.Commands,
                customLayout: com.google.common.collect.ImmutableList<CommandButton>,
                showWhenCompact: Boolean
            ): com.google.common.collect.ImmutableList<CommandButton> {
                val isFav = playerManager.currentSong.value?.isFavorite == true
                val favCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
                val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)

                val favButton = CommandButton.Builder()
                    .setDisplayName(if (isFav) "Favorited" else "Favorite")
                    .setIconResId(if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border)
                    .setSessionCommand(favCommand)
                    .setEnabled(true)
                    .build()

                val closeButton = CommandButton.Builder()
                    .setDisplayName("Close")
                    .setIconResId(R.drawable.ic_close)
                    .setSessionCommand(closeCommand)
                    .setEnabled(true)
                    .build()

                val defaultButtons = super.getMediaButtons(session, playerCommands, customLayout, showWhenCompact)
                val list = mutableListOf<CommandButton>()
                // Slot 0: Favorite (Heart) button
                list.add(favButton)
                // Middle slots: Standard playback controls
                list.addAll(defaultButtons)
                // Slot 4: Close (✕) button
                list.add(closeButton)

                return com.google.common.collect.ImmutableList.copyOf(list)
            }
        }
        setMediaNotificationProvider(customNotificationProvider)

        // Broadcast initial custom layout to System UI
        val isFav = playerManager.currentSong.value?.isFavorite == true
        val favCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
        val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
        val favButton = CommandButton.Builder()
            .setDisplayName(if (isFav) "Favorited" else "Favorite")
            .setIconResId(if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border)
            .setSessionCommand(favCommand)
            .setEnabled(true)
            .build()
        val closeButton = CommandButton.Builder()
            .setDisplayName("Close")
            .setIconResId(R.drawable.ic_close)
            .setSessionCommand(closeCommand)
            .setEnabled(true)
            .build()
        mediaSession?.setCustomLayout(listOf(favButton, closeButton))

        val prefManager = LerzaApp.instance.preferenceManager
        serviceScope.launch { playerManager.currentSong.collect { updateNotification() } }
        serviceScope.launch { playerManager.isPlaying.collect { updateNotification() } }
        serviceScope.launch { playerManager.duration.collect { updateNotification() } }
        serviceScope.launch { prefManager.mediaPlayerNotificationFlow.collect { updateNotification() } }
    }

    private fun toggleFavorite() {
        val song = playerManager.currentSong.value ?: return
        val newFav = !song.isFavorite
        playerManager.updateFavoriteStatus(song.id, newFav)
        serviceScope.launch(Dispatchers.IO) {
            val favDao = com.lerzaplayer.data.database.AppDatabase.getDatabase(this@PlaybackService).favoriteDao()
            if (!newFav) {
                favDao.removeFavorite(song.id, "AUDIO")
            } else {
                favDao.addFavorite(com.lerzaplayer.data.database.FavoriteEntity(song.id, "AUDIO"))
            }
        }
        updateNotification()
    }

    private fun closePlaybackAndNotification() {
        runCatching {
            playerManager.pause()
            playerManager.clearQueue()
            mediaSession?.player?.stop()
            mediaSession?.player?.clearMediaItems()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.cancel(NotificationHelper.NOTIFICATION_ID)
        stopSelf()
    }

    private fun updateNotification() {
        val song = playerManager.currentSong.value
        val isPlaying = playerManager.isPlaying.value
        val position = playerManager.currentPosition.value
        val duration = playerManager.duration.value
        val session = mediaSession

        serviceScope.launch(Dispatchers.IO) {
            val prefManager = LerzaApp.instance.preferenceManager
            val isTimelineNotificationEnabled = try { prefManager.mediaPlayerNotificationFlow.first() } catch (e: Exception) { true }
            val art = if (song != null) {
                ThumbnailExtractor.getSongCover(this@PlaybackService, song.contentUri, song.id)
            } else {
                null
            }

            // Sync MediaSession custom command buttons for Android 13/14/15 SystemUI Media Controls
            val isFav = song?.isFavorite == true
            val favCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
            val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
            val favButton = CommandButton.Builder()
                .setDisplayName(if (isFav) "Favorited" else "Favorite")
                .setIconResId(if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border)
                .setSessionCommand(favCommand)
                .setEnabled(true)
                .build()
            val closeButton = CommandButton.Builder()
                .setDisplayName("Close")
                .setIconResId(R.drawable.ic_close)
                .setSessionCommand(closeCommand)
                .setEnabled(true)
                .build()

            withContext(Dispatchers.Main) {
                mediaSession?.let { session ->
                    for (controller in session.connectedControllers) {
                        session.setCustomLayout(controller, listOf(favButton, closeButton))
                    }
                    session.setCustomLayout(listOf(favButton, closeButton))
                }
            }

            val notification = NotificationHelper.buildMediaNotification(
                context = this@PlaybackService,
                song = song,
                isPlaying = isPlaying,
                albumArt = art,
                currentPosition = position,
                duration = duration,
                mediaSession = session,
                showPlaybackControls = isTimelineNotificationEnabled
            )

            withContext(Dispatchers.Main) {
                if (isPlaying || song != null) {
                    startForeground(NotificationHelper.NOTIFICATION_ID, notification)
                } else {
                    stopForeground(STOP_FOREGROUND_DETACH)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefManager = LerzaApp.instance.preferenceManager
        val isControlsEnabled = runCatching {
            kotlinx.coroutines.runBlocking { prefManager.mediaPlayerNotificationFlow.first() }
        }.getOrDefault(true)

        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            NotificationHelper.buildMediaNotification(
                context = this,
                song = playerManager.currentSong.value,
                isPlaying = playerManager.isPlaying.value,
                albumArt = null,
                currentPosition = playerManager.currentPosition.value,
                duration = playerManager.duration.value,
                mediaSession = mediaSession,
                showPlaybackControls = isControlsEnabled
            )
        )

        when (intent?.action) {
            ACTION_PLAY -> playerManager.play()
            ACTION_PAUSE -> playerManager.pause()
            ACTION_NEXT -> playerManager.playNextTrack()
            ACTION_PREV -> playerManager.playPreviousTrack()
            ACTION_FAVORITE -> toggleFavorite()
            ACTION_STOP, ACTION_CLOSE -> closePlaybackAndNotification()
        }

        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        runCatching { unregisterReceiver(noisyReceiver) }
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.lerzaplayer.ACTION_PLAY"
        const val ACTION_PAUSE = "com.lerzaplayer.ACTION_PAUSE"
        const val ACTION_NEXT = "com.lerzaplayer.ACTION_NEXT"
        const val ACTION_PREV = "com.lerzaplayer.ACTION_PREV"
        const val ACTION_STOP = "com.lerzaplayer.ACTION_STOP"
        const val ACTION_FAVORITE = "com.lerzaplayer.ACTION_FAVORITE"
        const val ACTION_CLOSE = "com.lerzaplayer.ACTION_CLOSE"
    }
}