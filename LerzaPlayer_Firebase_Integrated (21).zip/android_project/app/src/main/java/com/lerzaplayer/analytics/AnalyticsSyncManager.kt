package com.lerzaplayer.analytics

import android.content.Context

/**
 * AnalyticsSyncManager - Backward-compatible facade delegating directly to FirebaseSyncManager.
 * All Turso SQL calls and external server endpoints have been removed.
 */
object AnalyticsSyncManager {
    fun getPermanentDeviceId(context: Context): String = FirebaseSyncManager.getPermanentDeviceId(context)

    fun init(context: Context) {
        FirebaseSyncManager.init(context)
    }

    fun syncNow(context: Context) {
        FirebaseSyncManager.syncNow(context)
    }
}
