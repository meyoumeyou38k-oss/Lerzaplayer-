package com.lerzaplayer.data.feedback

import android.content.Context
import android.os.Build
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.lerzaplayer.analytics.FirebaseSyncManager
import com.lerzaplayer.config.RemoteConfigManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * FeedbackManager for submitting user reviews directly to Firebase Firestore.
 * Clean, real-time collection: 'feedback'
 * Controlled dynamically by Firebase Remote Config: enable_feedback_system
 */
object FeedbackManager {
    suspend fun sendFeedback(
        context: Context,
        message: String,
        rating: Int = 5,
        userContact: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // Check if feedback system is enabled via Firebase Remote Config
            if (!RemoteConfigManager.enableFeedbackSystem.value) {
                throw Exception("Feedback system is currently paused by administrator.")
            }

            val deviceId = FirebaseSyncManager.getPermanentDeviceId(context)
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"
            val appVersionName = try {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "v1.0.5"
            } catch (e: Exception) {
                "v1.0.5"
            }

            val feedbackData = mapOf(
                "device_id" to deviceId,
                "message" to message.trim(),
                "rating" to rating,
                "contact" to userContact.ifBlank { "Anonymous" },
                "device" to deviceModel,
                "appVersion" to appVersionName,
                "formatted_date" to timestamp,
                "created_at" to FieldValue.serverTimestamp()
            )

            suspendCancellableCoroutine<String> { cont ->
                val firestore = FirebaseFirestore.getInstance()
                firestore.collection("feedback")
                    .add(feedbackData)
                    .addOnSuccessListener {
                        if (cont.isActive) {
                            cont.resume("Feedback submitted successfully to Firebase!")
                        }
                    }
                    .addOnFailureListener { error ->
                        if (cont.isActive) {
                            cont.resumeWithException(error)
                        }
                    }
            }
        }
    }
}
