package com.lerzaplayer.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.DynamicArtPalette
import com.lerzaplayer.theme.LocalLerzaColors
import kotlin.math.roundToInt

data class LarkPreset(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val isBooster: Boolean = false,
    val bands: List<Int>, // 10 bands (-10 to +10 dB)
    val bassStrength: Int = 0 // 0 to 1000
)

val LARK_PRESETS = listOf(
    // Booster Group
    LarkPreset("custom", "Custom", Icons.Default.GraphicEq, isBooster = true, bands = listOf(0,0,0,0,0,0,0,0,0,0), bassStrength = 0),
    LarkPreset("bass_booster", "Bass Booster", Icons.Default.VolumeUp, isBooster = true, bands = listOf(7, 6, 5, 3, 1, 0, 0, 0, 1, 2), bassStrength = 950),
    LarkPreset("vocal_booster", "Vocal Booster", Icons.Default.Mic, isBooster = true, bands = listOf(-2, -2, -1, 1, 4, 5, 3, 1, 0, -1), bassStrength = 100),
    LarkPreset("treble_booster", "Treble Booster", Icons.Default.SettingsVoice, isBooster = true, bands = listOf(-1, -1, 0, 0, 1, 2, 4, 6, 7, 7), bassStrength = 0),
    
    // Genre Group
    LarkPreset("normal", "Normal", Icons.Default.SentimentSatisfied, isBooster = false, bands = listOf(0,0,0,0,0,0,0,0,0,0), bassStrength = 0),
    LarkPreset("pop", "Pop", Icons.Default.MusicNote, isBooster = false, bands = listOf(-1, 1, 3, 4, 3, 1, -1, -1, 1, 2), bassStrength = 300),
    LarkPreset("hiphop", "HipHop", Icons.Default.Headphones, isBooster = false, bands = listOf(5, 4, 2, 1, -1, -1, 1, 2, 3, 3), bassStrength = 750),
    LarkPreset("rock", "Rock", Icons.Default.Whatshot, isBooster = false, bands = listOf(4, 3, 2, -1, -2, -1, 2, 3, 4, 4), bassStrength = 500),
    LarkPreset("electronic", "Electronic", Icons.Default.Bolt, isBooster = false, bands = listOf(4, 3, 1, 0, -2, 2, 1, 2, 4, 5), bassStrength = 650),
    LarkPreset("heavy_metal", "Heavy Metal", Icons.Default.ElectricBolt, isBooster = false, bands = listOf(3, 2, 0, 0, -1, 1, 3, 4, 2, 0), bassStrength = 450),
    LarkPreset("rnb", "R&B", Icons.Default.Nightlife, isBooster = false, bands = listOf(3, 6, 4, 1, -2, -1, 2, 3, 4, 4), bassStrength = 700),
    LarkPreset("folk", "Folk", Icons.Default.Audiotrack, isBooster = false, bands = listOf(2, 1, 0, 2, 2, 1, 0, 1, 1, 0), bassStrength = 200),
    LarkPreset("dance", "Dance", Icons.Default.Album, isBooster = false, bands = listOf(5, 4, 2, 0, 2, 3, 4, 3, 2, 0), bassStrength = 800),
    LarkPreset("jazz", "Jazz", Icons.Default.QueueMusic, isBooster = false, bands = listOf(3, 3, 2, 0, -1, -1, 0, 2, 3, 4), bassStrength = 350),
    LarkPreset("classic", "Classic", Icons.Default.Piano, isBooster = false, bands = listOf(4, 3, 2, 2, -1, -1, 0, 2, 3, 3), bassStrength = 250),
    LarkPreset("latin", "Latin", Icons.Default.LibraryMusic, isBooster = false, bands = listOf(2, 1, 0, 0, -1, -1, 0, 2, 3, 4), bassStrength = 300)
)

val FREQUENCIES_10 = listOf("31", "63", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    playerManager: PlayerManager,
    dynamicPalette: DynamicArtPalette? = null,
    onDismiss: () -> Unit
) {
    val enabled by playerManager.equalizerEnabled.collectAsState()
    val virtualBands by playerManager.virtual10Bands.collectAsState()
    val activePresetId by playerManager.activePresetId.collectAsState()
    val themeColors = LocalLerzaColors.current

    val accentColor = dynamicPalette?.accentColor ?: themeColors.primary
    val dominantColor = dynamicPalette?.dominantColor ?: themeColors.surface
    val sheetBackgroundColor = Color(0xFF0D111A)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = sheetBackgroundColor,
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 12.dp, bottom = 6.dp)
                    .width(42.dp)
                    .height(4.5.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.28f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 36.dp)
        ) {
            // Header Row: "Equalizer" + Neon Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.18f))
                            .border(1.dp, accentColor.copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Sound Equalizer",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (enabled) "10-Band Studio DSP Engine Active" else "Master EQ Bypass (Tap switch to turn on)",
                            fontSize = 11.5.sp,
                            color = if (enabled) accentColor else Color.White.copy(alpha = 0.5f)
                        )
                    }
                }

                Switch(
                    checked = enabled,
                    onCheckedChange = { playerManager.setEqualizerEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = accentColor,
                        uncheckedThumbColor = Color(0xFF64748B),
                        uncheckedTrackColor = Color(0xFF1E293B)
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 10-Band Vertical Slider Console
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF131826),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (enabled) accentColor.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.06f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Decibel Guide Markers Row (+10dB, 0dB, -10dB)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("+10 dB", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                        Text("Studio EQ", fontSize = 10.sp, color = if (enabled) accentColor else Color(0xFF475569), fontWeight = FontWeight.Bold)
                        Text("-10 dB", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FREQUENCIES_10.forEachIndexed { index, freqLabel ->
                            val bandVal = virtualBands.getOrElse(index) { 0 }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {
                                // Real-time dB Value readout
                                Text(
                                    text = if (bandVal > 0) "+$bandVal" else "$bandVal",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (enabled) (if (bandVal != 0) accentColor else Color.White.copy(alpha = 0.7f)) else Color.Gray
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Vertical Modern Slider with Neon Pill
                                LarkVerticalSlider(
                                    value = bandVal,
                                    range = -10..10,
                                    accentColor = accentColor,
                                    enabled = enabled,
                                    onValueChange = { newVal ->
                                        playerManager.setVirtual10Band(index, newVal)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .width(28.dp)
                                        .padding(vertical = 4.dp)
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Frequency Label
                                Text(
                                    text = freqLabel,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Booster Presets Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Bolt, null, tint = accentColor, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ACOUSTIC BOOSTERS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val boosterPresets = remember { LARK_PRESETS.filter { it.isBooster } }
            PresetGrid(
                presets = boosterPresets,
                activePresetId = activePresetId,
                accentColor = accentColor,
                enabled = enabled,
                onSelectPreset = { preset -> playerManager.applyLarkPreset(preset) }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Genre Presets Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.QueueMusic, null, tint = accentColor, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "GENRE PRESETS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val genrePresets = remember { LARK_PRESETS.filter { !it.isBooster } }
            PresetGrid(
                presets = genrePresets,
                activePresetId = activePresetId,
                accentColor = accentColor,
                enabled = enabled,
                onSelectPreset = { preset -> playerManager.applyLarkPreset(preset) }
            )
        }
    }
}

@Composable
private fun PresetGrid(
    presets: List<LarkPreset>,
    activePresetId: String,
    accentColor: Color,
    enabled: Boolean,
    onSelectPreset: (LarkPreset) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val chunked = presets.chunked(2)
        chunked.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { preset ->
                    val isSelected = activePresetId == preset.id
                    val isDarkText = accentColor.luminance() > 0.45f
                    val selectedTextColor = if (isDarkText) Color(0xFF0F172A) else Color.White
                    val unselectedBg = Color(0xFF141926)

                    Surface(
                        onClick = { if (enabled) onSelectPreset(preset) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (isSelected) accentColor else unselectedBg,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) accentColor else Color.White.copy(alpha = 0.06f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(68.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = preset.icon,
                                contentDescription = null,
                                tint = if (isSelected) selectedTextColor else Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = preset.name,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                color = if (isSelected) selectedTextColor else Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun LarkVerticalSlider(
    value: Int,
    range: IntRange = -10..10,
    accentColor: Color,
    enabled: Boolean,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalRange = (range.last - range.first).coerceAtLeast(1)
    val fraction = ((value - range.first).toFloat() / totalRange.toFloat()).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .then(
                if (enabled) {
                    Modifier
                        .pointerInput(range) {
                            fun updateY(y: Float) {
                                val trackH = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((y - 12f) / trackH)).coerceIn(0f, 1f)
                                val computed = (range.first + amount * totalRange).roundToInt()
                                onValueChange(computed.coerceIn(range.first, range.last))
                            }
                            detectTapGestures { updateY(it.y) }
                        }
                        .pointerInput(range) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val trackH = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((change.position.y - 12f) / trackH)).coerceIn(0f, 1f)
                                val computed = (range.first + amount * totalRange).roundToInt()
                                onValueChange(computed.coerceIn(range.first, range.last))
                            }
                        }
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        // Background track line
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
        )
        // Center zero-point notch
        Box(
            modifier = Modifier
                .width(10.dp)
                .height(1.5.dp)
                .background(Color.White.copy(alpha = 0.3f))
        )
        // Glowing Neon Thumb Pill
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val trackH = (size.height - 24.dp.toPx()).coerceAtLeast(1f)
            val thumbY = (size.height - 12.dp.toPx()) - (fraction * trackH)
            val pillWidth = 9.dp.toPx()
            val pillHeight = 24.dp.toPx()
            drawRoundRect(
                color = if (enabled) accentColor else Color(0xFF64748B),
                topLeft = androidx.compose.ui.geometry.Offset((size.width - pillWidth) / 2f, thumbY - pillHeight / 2f),
                size = androidx.compose.ui.geometry.Size(pillWidth, pillHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(pillWidth / 2f, pillWidth / 2f)
            )
        }
    }
}
