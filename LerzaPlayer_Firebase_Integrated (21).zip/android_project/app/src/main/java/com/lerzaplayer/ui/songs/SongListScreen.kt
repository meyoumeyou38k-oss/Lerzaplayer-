package com.lerzaplayer.ui.songs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow
import com.lerzaplayer.config.RemoteConfigManager
import com.lerzaplayer.ads.NativeAdFeedItem
import com.lerzaplayer.ads.AdManager
import androidx.compose.foundation.lazy.itemsIndexed

@Composable
fun SongListScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    currentSort: SortOption,
    selectedSongIds: Set<Long>,
    isMultiSelectMode: Boolean,
    densityScale: Float = 1.15f, // موٹائی و سائز اسکیل (سلائیڈر کے لیے)
    onSongClick: (SongItem, Int) -> Unit,
    onToggleSelect: (Long) -> Unit,
    onStartMultiSelect: (Long) -> Unit,
    onSortChanged: (SortOption) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onPlayNext: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    onAddToPlaylist: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var sortMenuExpanded by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val currentLang by com.lerzaplayer.data.language.LanguageManager.currentLanguage.collectAsState()
    val isUrdu = currentLang == com.lerzaplayer.data.language.AppLanguage.URDU
    val songsListAdInterval by RemoteConfigManager.songsListAdInterval.collectAsState()
    val showAllAds by RemoteConfigManager.showAllAds.collectAsState()
    val removeAllAds by RemoteConfigManager.removeAllAds.collectAsState()
    val isSongsListAdEnabled by RemoteConfigManager.enableSongsListAd.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isUrdu) "${songs.size} گانے دستیاب ہیں" else "${songs.size} Songs Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.card)
                        .clickable { sortMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SwapVert,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    val activeSortLabel = if (isUrdu) {
                        when (currentSort) {
                            SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                            SortOption.DATE_ADDED_DESC -> "تاریخ"
                            SortOption.TITLE_ASC -> "عنوان"
                            SortOption.ARTIST_ASC -> "فنکار"
                            SortOption.DURATION_DESC -> "دورانیہ"
                            SortOption.SIZE_DESC -> "سائز"
                        }
                    } else currentSort.displayName
                    Text(
                        text = if (isUrdu) "ترتیب: $activeSortLabel" else "Sort: $activeSortLabel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.textPrimary
                    )
                    Icon(
                        imageVector = LerzaIcons.ArrowDropDown,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    SortOption.values().forEach { option ->
                        val optName = if (isUrdu) {
                            when (option) {
                                SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                                SortOption.DATE_ADDED_DESC -> "شامل کرنے کی تاریخ"
                                SortOption.TITLE_ASC -> "عنوان (الف تا ے)"
                                SortOption.ARTIST_ASC -> "فنکار"
                                SortOption.DURATION_DESC -> "دورانیہ"
                                SortOption.SIZE_DESC -> "فائل سائز"
                            }
                        } else option.displayName
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = optName,
                                    fontSize = 13.sp,
                                    color = if (currentSort == option) Color(0xFF1E60F2) else colors.textPrimary
                                )
                            },
                            onClick = {
                                sortMenuExpanded = false
                                onSortChanged(option)
                            }
                        )
                    }
                }
            }
        }

        // بیزل کے بغیر لسٹ - 120 FPS ہموار سکرولنگ فِلنگ کے ساتھ
        LazyColumn(
            state = listState,
            flingBehavior = ScrollableDefaults.flingBehavior(),
            contentPadding = PaddingValues(bottom = if (isMultiSelectMode) 80.dp else 140.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(
                items = songs,
                key = { _, song -> song.id },
                contentType = { _, _ -> "song_row" }
            ) { index, song ->
                val isSelected = selectedSongIds.contains(song.id)
                val isCurrent = currentSong?.id == song.id
                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = isCurrent,
                    isMultiSelectActive = isMultiSelectMode,
                    isSelected = isSelected,
                    densityScale = densityScale,
                    isUrdu = isUrdu,
                    onSongClick = {
                        onSongClick(song, index)
                    },
                    onSongLongClick = {
                        onStartMultiSelect(song.id)
                    },
                    onToggleSelect = {
                        onToggleSelect(song.id)
                    },
                    onToggleFavorite = {
                        onToggleFavorite(song)
                    },
                    onPlayNext = {
                        onPlayNext(song)
                    },
                    onAddToQueue = {
                        onAddToQueue(song)
                    },
                    onAddToPlaylist = {
                        onAddToPlaylist(song)
                    },
                    onHideInVault = {
                        onHideInVault(song)
                    },
                    onDelete = {
                        onDelete(song)
                    }
                )
                if (showAllAds && !removeAllAds && isSongsListAdEnabled) {
                    val interval: Int = songsListAdInterval.coerceAtLeast(2)
                    if ((index + 1) % interval == 0) {
                        NativeAdFeedItem()
                    }
                }
            }
        }
    }
}