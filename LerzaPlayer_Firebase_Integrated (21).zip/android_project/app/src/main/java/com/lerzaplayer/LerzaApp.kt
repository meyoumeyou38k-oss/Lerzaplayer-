package com.lerzaplayer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.MediaDownloadMonitor
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.vault.VaultManager
import com.lerzaplayer.ads.AdManager
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LerzaApp : Application(), ImageLoaderFactory {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: AppDatabase
        private set

    lateinit var preferenceManager: PreferenceManager
        private set

    lateinit var playerManager: PlayerManager
        private set

    lateinit var vaultManager: VaultManager
        private set

    private lateinit var mediaDownloadMonitor: MediaDownloadMonitor

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                coil.memory.MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                coil.disk.DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(100L * 1024 * 1024)
                    .build()
            }
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(false) // Instant 120 FPS rendering without animation lag during scroll
            .respectCacheHeaders(false)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        try {
            // Configure persistent cache settings to eliminate repeated cache reload stalls
            val firestore = FirebaseFirestore.getInstance()
            val firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                .build()
            firestore.firestoreSettings = firestoreSettings
        } catch (e: Exception) {
            android.util.Log.w("LerzaApp", "Firestore cache settings note: ${e.message}")
        }

        try {
            // Initialize local AdMob and cached Remote Config (lightweight, zero UI blocking)
            // This ensures the App Open Ad check can evaluate cleanly on launch
            AdManager.initialize(this)
        } catch (e: Exception) {
            android.util.Log.e("LerzaApp", "Initialization error: ${e.message}", e)
        }

        database = AppDatabase.getDatabase(this)
        preferenceManager = PreferenceManager(this)
        playerManager = PlayerManager.getInstance(this)
        vaultManager = VaultManager.getInstance(this)

        // 🌟 DEFERRED & STAGGERED FIREBASE BACKGROUND WORKER:
        // Starts after ~75 seconds so cold-launch UI, animations, and scrolling run at 120 FPS smoothness
        // Connects to Firebase services one by one smoothly without UI hanging or cache reload thrashing
        appScope.launch(Dispatchers.IO) {
            // Step 1: Local media download monitoring & periodic scan after 2 seconds
            delay(2000)
            try {
                vaultManager.startPeriodicAutoScan(appScope)
                mediaDownloadMonitor = MediaDownloadMonitor(this@LerzaApp)
                mediaDownloadMonitor.start()
                com.lerzaplayer.playback.MediaScannerJobService.schedule(this@LerzaApp)
            } catch (e: Exception) {
                android.util.Log.w("LerzaApp", "Deferred media scan note: ${e.message}")
            }

            // Step 2: Wait until user has been in app for ~75 seconds before starting Firebase sync
            delay(75_000)
            try {
                android.util.Log.d("LerzaApp", "Starting Phase 1: Device identification & Status")
                com.lerzaplayer.analytics.FirebaseSyncManager.init(this@LerzaApp)
            } catch (e: Exception) {
                android.util.Log.w("LerzaApp", "Deferred FirebaseSyncManager init note: ${e.message}")
            }

            // Step 3: Wait another 20 seconds, then sync analytics & usage stats
            delay(20_000)
            try {
                android.util.Log.d("LerzaApp", "Starting Phase 2: Analytics & Playtime sync")
                com.lerzaplayer.analytics.FirebaseSyncManager.syncNow(this@LerzaApp)
            } catch (e: Exception) {
                android.util.Log.w("LerzaApp", "Deferred syncNow note: ${e.message}")
            }

            // Step 4: Wait another 20 seconds, then start listening for push notifications
            delay(20_000)
            try {
                android.util.Log.d("LerzaApp", "Starting Phase 3: Real-time Notifications")
                com.lerzaplayer.notifications.FirestoreNotificationManager.startListening(this@LerzaApp)
            } catch (e: Exception) {
                android.util.Log.w("LerzaApp", "Deferred FirestoreNotificationManager note: ${e.message}")
            }
        }
    }

    fun startMediaDownloadMonitoring() {
        if (::mediaDownloadMonitor.isInitialized) mediaDownloadMonitor.start()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_UI_HIDDEN) {
            vaultManager.onAppBackgrounded()
        }
    }

    companion object {
        lateinit var instance: LerzaApp
            private set
    }
}
