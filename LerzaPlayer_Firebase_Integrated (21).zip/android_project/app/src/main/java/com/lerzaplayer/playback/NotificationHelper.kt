package com.lerzaplayer.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R
import com.lerzaplayer.data.model.SongItem

object NotificationHelper {

    const val CHANNEL_PLAYBACK_ID = "lerza_playback_channel"
    const val CHANNEL_REMINDER_ID = "lerza_reminder_channel"
    const val CHANNEL_DOWNLOAD_ID = "lerza_new_media_channel"

    const val NOTIFICATION_ID = 1001
    const val REMINDER_NOTIFICATION_ID = 2001
    private const val NEW_MEDIA_NOTIFICATION_ID_BASE = 3000

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_PLAYBACK_ID, "Playback Controls", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Now playing controls and song timeline"
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_REMINDER_ID, "Music Recommendations & Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Music recommendations and listening reminders"
                    enableVibration(true)
                }
            )
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_DOWNLOAD_ID, "New downloads", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Notifies you when a new song or video is added to your device"
                    setShowBadge(true)
                }
            )
        }
    }

    fun buildMediaNotification(
        context: Context,
        song: SongItem?,
        isPlaying: Boolean,
        albumArt: Bitmap?,
        currentPosition: Long = 0L,
        duration: Long = 0L,
        mediaSession: MediaSession? = null,
        showPlaybackControls: Boolean = true
    ): Notification {
        createNotificationChannels(context)

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Actions: 0 = Favorite (Heart), 1 = Previous, 2 = Play/Pause, 3 = Next, 4 = Close (Cross)
        val isFav = song?.isFavorite == true
        val favIcon = if (isFav) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        val favTitle = if (isFav) "Favorited" else "Favorite"
        val favoritePending = broadcastPendingIntent(context, 4, PlaybackService.ACTION_FAVORITE)
        val prevPending = broadcastPendingIntent(context, 1, PlaybackService.ACTION_PREV)
        val playPausePending = broadcastPendingIntent(
            context, 2, if (isPlaying) PlaybackService.ACTION_PAUSE else PlaybackService.ACTION_PLAY
        )
        val nextPending = broadcastPendingIntent(context, 3, PlaybackService.ACTION_NEXT)
        val closePending = broadcastPendingIntent(context, 5, PlaybackService.ACTION_CLOSE)

        val builder = NotificationCompat.Builder(context, CHANNEL_PLAYBACK_ID)
            .setSmallIcon(R.drawable.brand_logo)
            .setContentTitle(song?.title ?: "Lerza Player Pro")
            .setContentText(song?.artist ?: "Ready to Play")
            .setSubText("Lerza Player Pro")
            .setContentIntent(mainPendingIntent)
            .setDeleteIntent(closePending)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)

        if (showPlaybackControls) {
            builder.addAction(favIcon, favTitle, favoritePending)
            builder.addAction(R.drawable.ic_skip_previous, "Previous", prevPending)
            builder.addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Pause" else "Play",
                playPausePending
            )
            builder.addAction(R.drawable.ic_skip_next, "Next", nextPending)
            builder.addAction(R.drawable.ic_close, "Close", closePending)

            if (mediaSession != null) {
                builder.setStyle(
                    MediaStyleNotificationHelper.MediaStyle(mediaSession)
                        .setShowActionsInCompactView(0, 2, 4)
                        .setShowCancelButton(true)
                        .setCancelButtonIntent(closePending)
                )
            }
        } else {
            // When user disables player notification controls in settings, hide Prev, Play/Pause, Next buttons!
            builder.addAction(favIcon, favTitle, favoritePending)
            builder.addAction(R.drawable.ic_close, "Close", closePending)

            if (mediaSession != null) {
                builder.setStyle(
                    MediaStyleNotificationHelper.MediaStyle(mediaSession)
                        .setShowActionsInCompactView(1)
                        .setShowCancelButton(true)
                        .setCancelButtonIntent(closePending)
                )
            }
        }

        val brandLogoBitmap = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.brand_logo)
        }.getOrNull()
        val effectiveLargeIcon = albumArt ?: brandLogoBitmap
        if (effectiveLargeIcon != null) {
            builder.setLargeIcon(effectiveLargeIcon)
        }

        return builder.build()
    }

    fun cancelAllNewMediaNotifications(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        for (i in 0..50) {
            notificationManager?.cancel(NEW_MEDIA_NOTIFICATION_ID_BASE + i)
        }
    }

    private fun broadcastPendingIntent(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun servicePendingIntent(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, PlaybackService::class.java).setAction(action)
        return PendingIntent.getService(
            context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showNewMediaNotification(
        context: Context,
        heading: String,
        title: String,
        detail: String,
        thumbnail: Bitmap?,
        mediaKey: String
    ) {
        createNotificationChannels(context)
        val isVideo = mediaKey.startsWith("video:")
        val mediaId = mediaKey.substringAfter(":").toLongOrNull() ?: -1L

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("play_media_key", mediaKey)
            putExtra("media_type", if (isVideo) "video" else "audio")
            putExtra("media_id", mediaId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            mediaKey.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val brandLogoBitmap = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.brand_logo)
        }.getOrNull()
        val effectiveThumbnail = thumbnail ?: brandLogoBitmap

        val builder = NotificationCompat.Builder(context, CHANNEL_DOWNLOAD_ID)
            .setSmallIcon(R.drawable.brand_logo)
            .setContentTitle(heading)
            .setContentText(title)
            .setSubText("Lerza Player")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setOnlyAlertOnce(true)

        if (effectiveThumbnail != null) {
            builder.setLargeIcon(effectiveThumbnail)
            builder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(effectiveThumbnail)
                    .bigLargeIcon(null as Bitmap?)
                    .setBigContentTitle(heading)
                    .setSummaryText("$title • $detail")
            )
        } else {
            builder.setStyle(NotificationCompat.BigTextStyle().bigText("$title • $detail"))
        }

        val playActionTitle = if (isVideo) "Watch Now" else "Play Now"
        builder.addAction(
            R.drawable.ic_play,
            playActionTitle,
            pendingIntent
        )

        val notificationId = NEW_MEDIA_NOTIFICATION_ID_BASE + (mediaKey.hashCode() and 0x7fffffff) % 100000
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { notificationManager.notify(notificationId, builder.build()) }
    }

    fun showInactivityReminder(context: Context, songTitle: String, artist: String) {
        createNotificationChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val brandLogoBitmap = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.brand_logo)
        }.getOrNull()

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.brand_logo)
            .apply {
                if (brandLogoBitmap != null) setLargeIcon(brandLogoBitmap)
            }
            .setContentTitle("Missing your tunes? Play \"$songTitle\"")
            .setContentText("Tap to resume listening to $artist!")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Your favorite song \"$songTitle\" by $artist is ready. Tap to open Lerza Player Pro!")
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(REMINDER_NOTIFICATION_ID, notification)
    }
}