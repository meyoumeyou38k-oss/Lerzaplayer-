package com.lerzaplayer.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.data.language.AppLanguage
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager

@Composable
fun TabsRow(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor
        val currentLang = LanguageManager.currentLanguage.collectAsState().value
    val s = remember(currentLang) { LanguageManager.getStringsFor(currentLang) }
    val tabs = listOf(s.tabVideos, s.tabSongs, s.tabPlaylists, s.tabFolders, s.tabAlbums, s.tabArtists)

    Surface(
        color = colors.surface.copy(alpha = 0.95f),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, tabTitle ->
                val isSelected = selectedTab == index
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isSelected) activeColor else colors.card
                        )
                        .clickable { onTabSelected(index) }
                        .padding(horizontal = 16.dp, vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (index == 0) {
                            Icon(
                                imageVector = LerzaIcons.Videocam,
                                contentDescription = null,
                                tint = if (isSelected) colors.onPrimary else colors.textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        } else if (index == 3) {
                            Icon(
                                imageVector = LerzaIcons.Folder,
                                contentDescription = null,
                                tint = if (isSelected) colors.onPrimary else colors.textSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        Text(
                            text = tabTitle,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) colors.onPrimary else colors.textPrimary
                        )
                    }
                }
            }
        }
    }
}