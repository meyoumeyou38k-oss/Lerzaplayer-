# 🚀 Lerza Player Pro - Complete Firebase & Remote Config Architecture

This guide details the complete configuration inventory, Firestore schemas, AdMob controls, and instructions for building Lerza Player.

---

## 🛠️ 1. Resolved Compilation Fix
- **Error fixed**: `MainActivity.kt:398:59 Unresolved reference: background`
- **Cause**: Missing import for `androidx.compose.foundation.background` when rendering the access suspension overlay.
- **Solution**: Explicitly added `import androidx.compose.foundation.background` at the top of `MainActivity.kt`.

---

## 🎛️ 2. Complete Firebase Remote Config Parameter Inventory

| Parameter Key | Data Type | Default Value | Description & Purpose | Validation & Clamping Rule |
| :--- | :--- | :--- | :--- | :--- |
| `show_all_ads` | `Boolean` | `true` | Global Master Switch to enable/disable all ads | Boolean toggle |
| `remove_all_ads` | `Boolean` | `false` | Master Ad-Removal Killswitch (VIP/Entitlement) | When `true`, overrides all ad placements to `false` |
| `test_ads_enabled` | `Boolean` | `false` | Toggle official Google AdMob test IDs | When `true`, all requests switch to test ad units |
| `enable_app_open_ad` | `Boolean` | `true` | Toggle App Open ad on startup/foreground | Boolean toggle |
| `enable_player_thumbnail_ad` | `Boolean` | `true` | Native ad in place of song artwork during playback | Boolean toggle |
| `enable_songs_list_ad` | `Boolean` | `true` | Native ads between songs in library list | Boolean toggle |
| `enable_videos_list_ad` | `Boolean` | `true` | Native ads between videos in library list | Boolean toggle |
| `enable_settings_click_ad` | `Boolean` | `true` | Interstitial ad on clicking Settings gear icon | Boolean toggle |
| `enable_vault_reward_ad` | `Boolean` | `true` | Rewarded ad before resetting private vault PIN | Boolean toggle |
| `banner_ad_unit_id` | `String` | `ca-app-pub-7375534389683057/9757608460` | Verified AdMob unit ID for bottom banner | Valid AdMob unit format |
| `app_open_ad_unit_id` | `String` | `ca-app-pub-7375534389683057/3906515984` | Verified AdMob unit ID for App Open | Valid AdMob unit format |
| `interstitial_ad_unit_id`| `String` | `ca-app-pub-7375534389683057/1823278127` | Verified AdMob unit ID for Interstitials | Valid AdMob unit format |
| `native_ad_unit_id` | `String` | `ca-app-pub-7375534389683057/8388686475` | Verified AdMob unit ID for Native Advanced | Valid AdMob unit format |
| `rewarded_ad_unit_id` | `String` | `ca-app-pub-7375534389683057/7678240038` | Verified AdMob unit ID for Rewarded Video | Valid AdMob unit format |
| `interstitial_ad_frequency_clicks` | `Number` | `4` | Number of song clicks between interstitial ads | Integer, min: 1, max: 20 |
| `interstitial_ad_cooldown_seconds` | `Number` | `30` | Minimum seconds between consecutive interstitials | Integer, min: 5, max: 300 |
| `max_interstitials_per_session` | `Number` | `15` | Maximum interstitials per foreground session | Integer, min: 1, max: 50 |
| `enable_feedback_system` | `Boolean` | `true` | Enable feedback submission to Firestore | Boolean toggle |
| `enable_playtime_tracking` | `Boolean` | `true` | Enable background playtime metrics sync | Boolean toggle |
| `enable_equalizer` | `Boolean` | `true` | Enable 5-band equalizer & bass boost | Boolean toggle |
| `enable_sleep_timer` | `Boolean` | `true` | Enable sleep timer feature in options | Boolean toggle |
| `latest_app_version_code` | `Number` | `4` | Latest available app version code | Positive Integer |
| `update_popup_enabled` | `Boolean` | `false` | Show recommended update modal | Boolean toggle |
| `update_website_url` | `String` | `https://lerzaplayer.vercel.app` | URL to direct users for APK update | Valid HTTPS URL |
| `maintenance_mode` | `Boolean` | `false` | Enable maintenance mode banner | Boolean toggle |
| `announcement_banner_text` | `String` | `""` | Broadcast promotional announcement banner | String <= 250 chars |
| `announcement_banner_link` | `String` | `""` | Deep link or URL for announcement banner | Valid HTTPS or deep link |

---

## 🗄️ 3. Cloud Firestore Database Collections & Schemas

### Collection: `devices/{deviceId}`
Tracks unique installation metrics, aggregate play times, FCM push tokens, and administrative blocking:
```json
{
  "device_id": "dev_a1b2c3d4...",
  "device_model": "Infinix Note 30",
  "device_manufacturer": "Infinix",
  "android_version": "Android 14 (API 34)",
  "app_version": "1.0.5",
  "app_language": "ur",
  "audio_playtime_minutes": 240,
  "video_playtime_minutes": 65,
  "total_playtime_minutes": 305,
  "today_music_minutes": 45,
  "month_music_minutes": 240,
  "session_count": 12,
  "fcm_token": "fX9...",
  "is_blocked": false,
  "blocked_reason": "Access restricted by administrator.",
  "first_install_time": 1728564000000,
  "last_active_time": "FieldValue.serverTimestamp()"
}
```

### Collection: `feedback/{feedbackId}`
User reviews submitted directly from the app:
```json
{
  "device_id": "dev_a1b2c3d4...",
  "message": "Player performance is smooth!",
  "rating": 5,
  "contact": "sajjadmunawar025@gmail.com",
  "device": "Infinix Note 30 (Android 14)",
  "appVersion": "1.0.5",
  "formatted_date": "2026-10-10 12:45:00",
  "created_at": "FieldValue.serverTimestamp()"
}
```

### Collection: `notifications/{campaignId}`
Scheduled notification campaigns managed by admin:
```json
{
  "title": "New Update Available!",
  "body": "Download Lerza Player v1.0.6 for new features.",
  "image_url": "https://example.com/banner.png",
  "target_url": "https://lerzaplayer.vercel.app",
  "created_at": "FieldValue.serverTimestamp()"
}
```

---

## 🛡️ 4. Offline Safety & Resilient Behavior
1. **Local Offline Caching**: `remote_config_defaults.xml` caches all parameters locally. If offline, the app runs with zero lag.
2. **Offline Media Playback**: Core media browsing, playlist management, equalizer, and video playback function 100% offline.
3. **No Credential Leaks**: Only the client `google-services.json` is bundled. Private service accounts are never included in the app.
