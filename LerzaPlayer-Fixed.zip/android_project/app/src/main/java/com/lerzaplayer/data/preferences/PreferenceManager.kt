package com.lerzaplayer.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.ViewMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "lerza_preferences")

class PreferenceManager(private val context: Context) {

    companion object {
        val KEY_THEME = stringPreferencesKey("app_theme")
        val KEY_SONG_SORT = stringPreferencesKey("song_sort")
        val KEY_VIDEO_SORT = stringPreferencesKey("video_sort")
        val KEY_VIDEO_VIEW_MODE = stringPreferencesKey("video_view_mode")
        val KEY_AUTO_PLAY = booleanPreferencesKey("auto_play")
        val KEY_RESUME_PLAYBACK = booleanPreferencesKey("resume_playback")
        val KEY_WALLPAPER_URI = stringPreferencesKey("custom_wallpaper_uri")
        val KEY_WALLPAPER_PRESET_ID = stringPreferencesKey("wallpaper_preset_id")
        val KEY_WALLPAPER_OPACITY = floatPreferencesKey("wallpaper_opacity")
        val KEY_VAULT_PIN = stringPreferencesKey("vault_pin_hash")
        val KEY_VAULT_PATTERN = stringPreferencesKey("vault_pattern_hash")
        val KEY_VAULT_LOCK_TYPE = stringPreferencesKey("vault_lock_type")
        val KEY_AUDIO_SPEED = floatPreferencesKey("audio_speed")
        val KEY_BASS_BOOST = intPreferencesKey("bass_boost_level")
        val KEY_VIRTUALIZER = booleanPreferencesKey("virtualizer_enabled")
        val KEY_EQ_PRESET = intPreferencesKey("eq_preset_index")
        val KEY_SONG_ITEM_DENSITY = floatPreferencesKey("song_item_density")
        val KEY_APP_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_HI_RES_AUDIO = booleanPreferencesKey("hires_audio_enabled")
        val KEY_SPATIAL_SURROUND = booleanPreferencesKey("spatial_surround_enabled")
        val KEY_GAPLESS_PLAYBACK = booleanPreferencesKey("gapless_playback_enabled")
        val KEY_AUTO_PAUSE_HEADPHONES = booleanPreferencesKey("auto_pause_headphones_enabled")
        val KEY_CROSSFADE_SECONDS = floatPreferencesKey("crossfade_seconds")
        val KEY_VOCAL_BOOST = intPreferencesKey("vocal_boost_level")
        val KEY_NEW_MEDIA_NOTIFICATION = booleanPreferencesKey("new_media_notification_enabled")
        val KEY_MEDIA_PLAYER_NOTIFICATION = booleanPreferencesKey("media_player_notification_enabled")
        // 🌟 خودکار اپڈیٹ پرمیشن ڈائیلاگ کا ٹریکر
        val KEY_INSTALL_PERMISSION_PROMPTED = booleanPreferencesKey("install_permission_prompted")
        // 🌟 آن بورڈنگ وزرڈ اور صارف کا نام
        val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val KEY_ONBOARDING_V2_COMPLETED = booleanPreferencesKey("onboarding_v2_completed")
        val KEY_USER_NAME = stringPreferencesKey("user_display_name")
        val KEY_SEARCH_HISTORY = stringPreferencesKey("search_history_csv")
        val KEY_FEEDBACK_WEBHOOK_URL = stringPreferencesKey("feedback_webhook_url")

        const val THEME_AMOLED = "AMOLED Black"
        const val THEME_WHITE = "Pure White"
        const val THEME_ROSE = "Soft Rose"
        const val THEME_MINT = "Mint Sage"
        const val THEME_SKY = "Pastel Sky"
        const val THEME_LAVENDER = "Soft Lavender"
        const val THEME_AMBER = "Sunset Amber"
    }

    val themeFlow: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: THEME_WHITE }
    val songSortFlow: Flow<SortOption> = context.dataStore.data.map {
        val name = it[KEY_SONG_SORT] ?: SortOption.DATE_ADDED_DESC.name
        try { SortOption.valueOf(name) } catch (e: Exception) { SortOption.DATE_ADDED_DESC }
    }
    val videoViewModeFlow: Flow<ViewMode> = context.dataStore.data.map {
        val name = it[KEY_VIDEO_VIEW_MODE] ?: ViewMode.GRID.name
        try { ViewMode.valueOf(name) } catch (e: Exception) { ViewMode.GRID }
    }
    val wallpaperUriFlow: Flow<String?> = context.dataStore.data.map { it[KEY_WALLPAPER_URI] }
    val wallpaperPresetIdFlow: Flow<String> = context.dataStore.data.map { it[KEY_WALLPAPER_PRESET_ID] ?: "default_nature" }
    val wallpaperOpacityFlow: Flow<Float> = context.dataStore.data.map { it[KEY_WALLPAPER_OPACITY] ?: 0.75f }
    val vaultPinFlow: Flow<String?> = context.dataStore.data.map { it[KEY_VAULT_PIN] }
    val vaultPatternFlow: Flow<String?> = context.dataStore.data.map { it[KEY_VAULT_PATTERN] }
    val vaultLockTypeFlow: Flow<VaultLockType> = context.dataStore.data.map {
        val type = it[KEY_VAULT_LOCK_TYPE] ?: VaultLockType.PIN.name
        try { VaultLockType.valueOf(type) } catch (e: Exception) { VaultLockType.PIN }
    }
    val audioSpeedFlow: Flow<Float> = context.dataStore.data.map { it[KEY_AUDIO_SPEED] ?: 1.0f }
    val bassBoostFlow: Flow<Int> = context.dataStore.data.map { it[KEY_BASS_BOOST] ?: 0 }
    val virtualizerFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_VIRTUALIZER] ?: false }
    val eqPresetFlow: Flow<Int> = context.dataStore.data.map { it[KEY_EQ_PRESET] ?: 0 }
    val songItemDensityFlow: Flow<Float> = context.dataStore.data.map { it[KEY_SONG_ITEM_DENSITY] ?: 1.15f }
    val appLanguageFlow: Flow<String> = context.dataStore.data.map { it[KEY_APP_LANGUAGE] ?: "en" }
    val hiResAudioFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_HI_RES_AUDIO] ?: true }
    val spatialSurroundFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_SPATIAL_SURROUND] ?: true }
    val gaplessPlaybackFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_GAPLESS_PLAYBACK] ?: true }
    val autoPauseHeadphonesFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_AUTO_PAUSE_HEADPHONES] ?: true }
    val crossfadeSecondsFlow: Flow<Float> = context.dataStore.data.map { it[KEY_CROSSFADE_SECONDS] ?: 3f }
    val vocalBoostFlow: Flow<Int> = context.dataStore.data.map { it[KEY_VOCAL_BOOST] ?: 0 }
    val newMediaNotificationFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_NEW_MEDIA_NOTIFICATION] ?: true }
    val mediaPlayerNotificationFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_MEDIA_PLAYER_NOTIFICATION] ?: true }
    val installPermissionPromptedFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_INSTALL_PERMISSION_PROMPTED] ?: false }
    val onboardingCompletedFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_ONBOARDING_COMPLETED] ?: false }
    val onboardingV2CompletedFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_ONBOARDING_V2_COMPLETED] ?: false }
    val userNameFlow: Flow<String> = context.dataStore.data.map { it[KEY_USER_NAME] ?: "" }
    val searchHistoryFlow: Flow<List<String>> = context.dataStore.data.map {
        val raw = it[KEY_SEARCH_HISTORY] ?: "ghmagh,tututu,Sad mood,new release,Arjit Singh,Aura player"
        raw.split(",").map { s -> s.trim() }.filter { s -> s.isNotBlank() }
    }
    val feedbackWebhookUrlFlow: Flow<String> = context.dataStore.data.map {
        it[KEY_FEEDBACK_WEBHOOK_URL] ?: ""
    }

    suspend fun setFeedbackWebhookUrl(url: String) {
        context.dataStore.edit { it[KEY_FEEDBACK_WEBHOOK_URL] = url }
    }

    suspend fun setTheme(theme: String) { context.dataStore.edit { it[KEY_THEME] = theme } }
    suspend fun setThemeMode(mode: String) { setTheme(mode) }
    suspend fun setAccentColor(color: Long) { /* accent color persisted through ThemeManager */ }
    suspend fun setSongSort(sort: SortOption) { context.dataStore.edit { it[KEY_SONG_SORT] = sort.name } }
    suspend fun setVideoViewMode(mode: ViewMode) { context.dataStore.edit { it[KEY_VIDEO_VIEW_MODE] = mode.name } }
    suspend fun setWallpaperUri(uri: String?) {
        context.dataStore.edit {
            if (uri != null) it[KEY_WALLPAPER_URI] = uri else it.remove(KEY_WALLPAPER_URI)
        }
    }
    suspend fun setWallpaperPresetId(presetId: String) { context.dataStore.edit { it[KEY_WALLPAPER_PRESET_ID] = presetId } }
    suspend fun setWallpaperOpacity(opacity: Float) { context.dataStore.edit { it[KEY_WALLPAPER_OPACITY] = opacity } }
    suspend fun setVaultPin(hash: String?) {
        context.dataStore.edit {
            if (hash != null) it[KEY_VAULT_PIN] = hash else it.remove(KEY_VAULT_PIN)
        }
    }
    suspend fun setVaultPattern(patternHash: String?) {
        context.dataStore.edit {
            if (patternHash != null) it[KEY_VAULT_PATTERN] = patternHash else it.remove(KEY_VAULT_PATTERN)
        }
    }
    suspend fun setVaultLockType(lockType: VaultLockType) { context.dataStore.edit { it[KEY_VAULT_LOCK_TYPE] = lockType.name } }
    suspend fun setAudioSpeed(speed: Float) { context.dataStore.edit { it[KEY_AUDIO_SPEED] = speed } }
    suspend fun setBassBoost(level: Int) { context.dataStore.edit { it[KEY_BASS_BOOST] = level } }
    suspend fun setVirtualizer(enabled: Boolean) { context.dataStore.edit { it[KEY_VIRTUALIZER] = enabled } }
    suspend fun setEqPreset(presetIndex: Int) { context.dataStore.edit { it[KEY_EQ_PRESET] = presetIndex } }
    suspend fun setSongItemDensity(density: Float) { context.dataStore.edit { it[KEY_SONG_ITEM_DENSITY] = density } }
    suspend fun setAppLanguage(lang: String) { context.dataStore.edit { it[KEY_APP_LANGUAGE] = lang } }
    suspend fun setHiResAudio(enabled: Boolean) { context.dataStore.edit { it[KEY_HI_RES_AUDIO] = enabled } }
    suspend fun setSpatialSurround(enabled: Boolean) { context.dataStore.edit { it[KEY_SPATIAL_SURROUND] = enabled } }
    suspend fun setGaplessPlayback(enabled: Boolean) { context.dataStore.edit { it[KEY_GAPLESS_PLAYBACK] = enabled } }
    suspend fun setAutoPauseHeadphones(enabled: Boolean) { context.dataStore.edit { it[KEY_AUTO_PAUSE_HEADPHONES] = enabled } }
    suspend fun setCrossfadeSeconds(sec: Float) { context.dataStore.edit { it[KEY_CROSSFADE_SECONDS] = sec } }
    suspend fun setVocalBoost(level: Int) { context.dataStore.edit { it[KEY_VOCAL_BOOST] = level } }
    suspend fun setNewMediaNotification(enabled: Boolean) { context.dataStore.edit { it[KEY_NEW_MEDIA_NOTIFICATION] = enabled } }
    suspend fun setMediaPlayerNotification(enabled: Boolean) { context.dataStore.edit { it[KEY_MEDIA_PLAYER_NOTIFICATION] = enabled } }
    suspend fun setInstallPermissionPrompted(prompted: Boolean) { context.dataStore.edit { it[KEY_INSTALL_PERMISSION_PROMPTED] = prompted } }
    suspend fun setOnboardingCompleted(completed: Boolean) { context.dataStore.edit { it[KEY_ONBOARDING_COMPLETED] = completed } }
    suspend fun setOnboardingV2Completed(completed: Boolean) {
        context.dataStore.edit {
            it[KEY_ONBOARDING_V2_COMPLETED] = completed
            it[KEY_ONBOARDING_COMPLETED] = completed
        }
    }
    suspend fun setUserName(name: String) { context.dataStore.edit { it[KEY_USER_NAME] = name } }
    suspend fun addSearchQuery(query: String) {
        val q = query.trim()
        if (q.isBlank()) return
        context.dataStore.edit {
            val raw = it[KEY_SEARCH_HISTORY] ?: "ghmagh,tututu,Sad mood,new release,Arjit Singh,Aura player"
            val list = raw.split(",").map { s -> s.trim() }.filter { s -> s.isNotBlank() }.toMutableList()
            list.remove(q)
            list.add(0, q)
            it[KEY_SEARCH_HISTORY] = list.take(15).joinToString(",")
        }
    }
    suspend fun removeSearchQuery(query: String) {
        context.dataStore.edit {
            val raw = it[KEY_SEARCH_HISTORY] ?: ""
            val list = raw.split(",").map { s -> s.trim() }.filter { s -> s.isNotBlank() && s != query }
            it[KEY_SEARCH_HISTORY] = list.joinToString(",")
        }
    }
    suspend fun clearSearchHistory() {
        context.dataStore.edit { it[KEY_SEARCH_HISTORY] = "" }
    }
}