package com.lerzaplayer.notifications

import com.lerzaplayer.update.AppUpdateManager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R
import com.lerzaplayer.analytics.FirebaseSyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Real-time Firestore Push Notification Listener for Lerza Player.
 * Synchronizes with the Web Admin Dashboard's Notification Broadcasts in real-time.
 * 
 * Supports:
 * - Specific targeted Device ID (target_device_id): Only displays if this device matches.
 * - Country / Region targeting (target_country): Displays only if device country matches or 'ALL'.
 * - Big picture preview if image_url is provided.
 * - Direct external URL opening in web browser if a link is provided, or opening app if empty.
 */
object FirestoreNotificationManager {

    private const val TAG = "FirestoreNotifManager"
    private const val PREFS_NAME = "lerza_notifications_cache"
    private const val KEY_SHOWN_NOTIF_IDS = "shown_notification_ids"

    private val notifScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var isListening = false

    fun startListening(context: Context) {
        if (isListening) return
        isListening = true

        try {
            val firestore = FirebaseFirestore.getInstance()
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val currentDeviceId = FirebaseSyncManager.getPermanentDeviceId(context)
            val currentCountry = FirebaseSyncManager.getDeviceCountryCode(context).uppercase(Locale.ROOT)

            val handleDocChanges: (List<DocumentChange>) -> Unit = { changes ->
                val shownIds = prefs.getStringSet(KEY_SHOWN_NOTIF_IDS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
                val currentTime = System.currentTimeMillis()

                for (dc in changes) {
                    if (dc.type == DocumentChange.Type.ADDED || dc.type == DocumentChange.Type.MODIFIED) {
                        val doc = dc.document
                        val notifId = doc.id
                        val updateKey = "${notifId}_${doc.data.hashCode()}"
                        if (shownIds.contains(updateKey)) continue

                        // Flexible field extraction
                        val title = doc.getString("title") 
                            ?: doc.getString("heading") 
                            ?: doc.getString("name") 
                            ?: doc.getString("subject") 
                            ?: "Lerza Player"

                        val body = doc.getString("body") 
                            ?: doc.getString("message") 
                            ?: doc.getString("announcement") 
                            ?: doc.getString("text") 
                            ?: doc.getString("content") 
                            ?: doc.getString("description") 
                            ?: doc.getString("msg") 
                            ?: ""

                        val link = doc.getString("deep_link") 
                            ?: doc.getString("link") 
                            ?: doc.getString("url") 
                            ?: doc.getString("target_url")

                        val imageUrl = doc.getString("image_url") 
                            ?: doc.getString("imageUrl") 
                            ?: doc.getString("banner") 
                            ?: doc.getString("image")

                        val isActive = doc.getBoolean("is_active") 
                            ?: doc.getBoolean("active") 
                            ?: true

                        if (!isActive) continue

                        // Targeting criteria
                        val targetAudience = doc.getString("target_audience") ?: "all_users"
                        val targetDeviceId = doc.getString("target_device_id")?.trim()
                        val targetCountry = doc.getString("target_country")?.trim()?.uppercase(Locale.ROOT)

                        // 1. Device ID specific targeting check
                        if (targetAudience == "specific_device" && !targetDeviceId.isNullOrBlank()) {
                            if (targetDeviceId != currentDeviceId && !currentDeviceId.endsWith(targetDeviceId)) {
                                Log.d(TAG, "Skipping notification: targeted to device '$targetDeviceId', current is '$currentDeviceId'")
                                continue
                            }
                        }

                        // 2. Country targeting check
                        if (targetAudience == "country" && !targetCountry.isNullOrBlank() && targetCountry != "ALL") {
                            if (targetCountry != currentCountry) {
                                Log.d(TAG, "Skipping notification: targeted to country '$targetCountry', current device is '$currentCountry'")
                                continue
                            }
                        }

                        // Check if this push notification is marked as a Mandatory Force Update
                        val isForceUpdateNotif = doc.getBoolean("is_force_update") ?: false
                        if (isForceUpdateNotif) {
                            Log.d(TAG, "Mandatory update notification received - enforcing update dialog")
                            AppUpdateManager.checkForUpdates(context.applicationContext)
                        }

                        if (body.isNotBlank()) {
                            shownIds.add(updateKey)
                            prefs.edit().putStringSet(KEY_SHOWN_NOTIF_IDS, shownIds).apply()

                            notifScope.launch {
                                buildAndShowNotification(
                                    context.applicationContext,
                                    notifId,
                                    title,
                                    body,
                                    link?.trim(),
                                    imageUrl?.trim()
                                )
                            }
                        }
                    }
                }
            }

            // 1. Listen to notifications collection without brittle orderBy requirement
            firestore.collection("notifications")
                .limit(20)
                .addSnapshotListener { snapshots, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore notifications warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshots != null && !snapshots.isEmpty) {
                        handleDocChanges(snapshots.documentChanges)
                    }
                }

            // 2. Listen to announcements collection
            firestore.collection("announcements")
                .limit(20)
                .addSnapshotListener { snapshots, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore announcements warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshots != null && !snapshots.isEmpty) {
                        handleDocChanges(snapshots.documentChanges)
                    }
                }

            Log.d(TAG, "Firestore real-time notification listener activated successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting Firestore notification listener: ${e.message}", e)
        }
    }
    }

    private suspend fun buildAndShowNotification(
        context: Context,
        notificationIdStr: String,
        title: String,
        messageBody: String,
        targetUrl: String?,
        imageUrl: String?
    ) {
        try {
            // 1. Resolve Click Action (Open Web Browser if link provided, else Open App)
            val pendingIntent: PendingIntent = if (!targetUrl.isNullOrBlank() && 
                (targetUrl.startsWith("http://", ignoreCase = true) || targetUrl.startsWith("https://", ignoreCase = true))) {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                PendingIntent.getActivity(
                    context,
                    notificationIdStr.hashCode(),
                    browserIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            } else {
                val appIntent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    if (!targetUrl.isNullOrBlank()) {
                        putExtra("extra_target_url", targetUrl)
                    }
                }
                PendingIntent.getActivity(
                    context,
                    notificationIdStr.hashCode(),
                    appIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }

            val channelId = context.getString(R.string.default_notification_channel_id).ifBlank { "lerza_notifications_channel" }
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            // 2. Real Brand Logo
            val brandLogoBitmap: Bitmap? = try {
                BitmapFactory.decodeResource(context.resources, R.drawable.brand_logo)
            } catch (e: Exception) {
                null
            }

            // 3. Download Banner Image if provided
            var bannerBitmap: Bitmap? = null
            if (!imageUrl.isNullOrBlank() && (imageUrl.startsWith("http://") || imageUrl.startsWith("https://"))) {
                bannerBitmap = withContext(Dispatchers.IO) {
                    try {
                        val url = URL(imageUrl)
                        val conn = url.openConnection() as HttpURLConnection
                        conn.connectTimeout = 5000
                        conn.readTimeout = 5000
                        conn.doInput = true
                        conn.connect()
                        val stream = conn.inputStream
                        BitmapFactory.decodeStream(stream)
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not download notification banner image: ${e.message}")
                        null
                    }
                }
            }

            val notificationBuilder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.brand_logo)
                .setContentTitle(title)
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)

            if (brandLogoBitmap != null) {
                notificationBuilder.setLargeIcon(brandLogoBitmap)
            }

            if (bannerBitmap != null) {
                notificationBuilder.setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bannerBitmap)
                        .setBigContentTitle(title)
                        .setSummaryText(messageBody)
                )
            } else {
                notificationBuilder.setStyle(
                    NotificationCompat.BigTextStyle().bigText(messageBody)
                )
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "Lerza Player Announcements",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Updates, features, and broadcasts for Lerza Player"
                    enableVibration(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val notificationId = (System.currentTimeMillis() % 10000).toInt()
            notificationManager.notify(notificationId, notificationBuilder.build())
            Log.d(TAG, "Notification successfully displayed: '$title'")
        } catch (e: Exception) {
            Log.e(TAG, "Error building notification: ${e.message}", e)
        }
    }
}
