package com.lerzaplayer.ui.songs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.animation.core.animateFloatAsState
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow
import com.lerzaplayer.config.RemoteConfigManager
import com.lerzaplayer.ads.NativeAdFeedItem
import com.lerzaplayer.ads.AdManager
import androidx.compose.foundation.lazy.itemsIndexed

@Composable
fun SongListScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    currentSort: SortOption,
    selectedSongIds: Set<Long>,
    isMultiSelectMode: Boolean,
    densityScale: Float = 1.15f, // موٹائی و سائز اسکیل (سلائیڈر کے لیے)
    onSongClick: (SongItem, Int) -> Unit,
    onToggleSelect: (Long) -> Unit,
    onStartMultiSelect: (Long) -> Unit,
    onSortChanged: (SortOption) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onPlayNext: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    onAddToPlaylist: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var sortMenuExpanded by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val currentLang by com.lerzaplayer.data.language.LanguageManager.currentLanguage.collectAsState()
    val isUrdu = currentLang == com.lerzaplayer.data.language.AppLanguage.URDU
    val songsListAdInterval by RemoteConfigManager.songsListAdInterval.collectAsState()
    val showAllAds by RemoteConfigManager.showAllAds.collectAsState()
    val removeAllAds by RemoteConfigManager.removeAllAds.collectAsState()
    val isSongsListAdEnabled by RemoteConfigManager.enableSongsListAd.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isUrdu) "${songs.size} گانے دستیاب ہیں" else "${songs.size} Songs Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.card)
                        .clickable { sortMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SwapVert,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    val activeSortLabel = if (isUrdu) {
                        when (currentSort) {
                            SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                            SortOption.DATE_ADDED_DESC -> "تاریخ"
                            SortOption.TITLE_ASC -> "عنوان"
                            SortOption.ARTIST_ASC -> "فنکار"
                            SortOption.DURATION_DESC -> "دورانیہ"
                            SortOption.SIZE_DESC -> "سائز"
                        }
                    } else currentSort.displayName
                    Text(
                        text = if (isUrdu) "ترتیب: $activeSortLabel" else "Sort: $activeSortLabel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.textPrimary
                    )
                    Icon(
                        imageVector = LerzaIcons.ArrowDropDown,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    SortOption.values().forEach { option ->
                        val optName = if (isUrdu) {
                            when (option) {
                                SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                                SortOption.DATE_ADDED_DESC -> "شامل کرنے کی تاریخ"
                                SortOption.TITLE_ASC -> "عنوان (الف تا ے)"
                                SortOption.ARTIST_ASC -> "فنکار"
                                SortOption.DURATION_DESC -> "دورانیہ"
                                SortOption.SIZE_DESC -> "فائل سائز"
                            }
                        } else option.displayName
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = optName,
                                    fontSize = 13.sp,
                                    color = if (currentSort == option) Color(0xFF1E60F2) else colors.textPrimary
                                )
                            },
                            onClick = {
                                sortMenuExpanded = false
                                onSortChanged(option)
                            }
                        )
                    }
                }
            }
        }

        // بیزل کے بغیر لسٹ - 120 FPS مکھن جیسی ہموار کائنیٹک سکرولنگ فِلنگ و فاسٹ سکرولر کے ساتھ
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                state = listState,
                flingBehavior = ScrollableDefaults.flingBehavior(),
                contentPadding = PaddingValues(bottom = if (isMultiSelectMode) 80.dp else 140.dp),
                modifier = Modifier.fillMaxSize()
            ) {
            itemsIndexed(
                items = songs,
                key = { _, song -> song.id },
                contentType = { _, _ -> "song_row" }
            ) { index, song ->
                val isSelected = selectedSongIds.contains(song.id)
                val isCurrent = currentSong?.id == song.id
                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = isCurrent,
                    isMultiSelectActive = isMultiSelectMode,
                    isSelected = isSelected,
                    densityScale = densityScale,
                    isUrdu = isUrdu,
                    onSongClick = {
                        onSongClick(song, index)
                    },
                    onSongLongClick = {
                        onStartMultiSelect(song.id)
                    },
                    onToggleSelect = {
                        onToggleSelect(song.id)
                    },
                    onToggleFavorite = {
                        onToggleFavorite(song)
                    },
                    onPlayNext = {
                        onPlayNext(song)
                    },
                    onAddToQueue = {
                        onAddToQueue(song)
                    },
                    onAddToPlaylist = {
                        onAddToPlaylist(song)
                    },
                    onHideInVault = {
                        onHideInVault(song)
                    },
                    onDelete = {
                        onDelete(song)
                    }
                )
                if (showAllAds && !removeAllAds && isSongsListAdEnabled) {
                    val interval: Int = songsListAdInterval.coerceAtLeast(2)
                    if ((index + 1) % interval == 0) {
                        NativeAdFeedItem()
                    }
                }
            }
        }

        // 🌟 Lark Player Signature Fast-Scroll Capsule Pill Handle (اسکرین شاٹ کے عین مطابق)
        if (songs.size > 8) {
            val coroutineScope = rememberCoroutineScope()
            var isDraggingThumb by remember { mutableStateOf(false) }
            var isThumbVisible by remember { mutableStateOf(false) }
            var dragOffsetY by remember { mutableFloatStateOf(0f) }

            // Show thumb whenever user scrolls or drags, auto-hide after 1400ms idle
            val isScrolling = listState.isScrollInProgress
            LaunchedEffect(isScrolling, isDraggingThumb) {
                if (isScrolling || isDraggingThumb) {
                    isThumbVisible = true
                } else {
                    delay(1400)
                    if (!listState.isScrollInProgress && !isDraggingThumb) {
                        isThumbVisible = false
                    }
                }
            }

            val thumbAlpha by animateFloatAsState(
                targetValue = if (isThumbVisible) 1f else 0f,
                animationSpec = tween(durationMillis = 280),
                label = "thumbAlpha"
            )

            val totalItems = songs.size.coerceAtLeast(1)
            val firstIndex = listState.firstVisibleItemIndex
            val scrollFraction = (firstIndex.toFloat() / (totalItems - 1).coerceAtLeast(1)).coerceIn(0f, 1f)

            if (thumbAlpha > 0.01f) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxHeight()
                        .align(Alignment.CenterEnd)
                        .padding(
                            top = 8.dp,
                            bottom = if (isMultiSelectMode) 85.dp else 145.dp,
                            end = 3.dp
                        )
                ) {
                    val trackHeightPx = constraints.maxHeight.toFloat()
                    val thumbHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 54.dp.toPx() }
                    val maxTravelPx = (trackHeightPx - thumbHeightPx).coerceAtLeast(0f)
                    val currentTopPx = if (isDraggingThumb) {
                        dragOffsetY.coerceIn(0f, maxTravelPx)
                    } else {
                        scrollFraction * maxTravelPx
                    }

                    // Floating Pill Handle (Lark Player design)
                    Surface(
                        shape = RoundedCornerShape(percent = 50),
                        color = if (isDraggingThumb) Color(0xFFF8FAFC) else Color(0xFFE2E8F0).copy(alpha = 0.94f),
                        shadowElevation = if (isDraggingThumb) 8.dp else 4.dp,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isDraggingThumb) colors.primary.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier
                            .width(28.dp)
                            .height(54.dp)
                            .graphicsLayer {
                                translationY = currentTopPx
                                alpha = thumbAlpha
                                scaleX = if (isDraggingThumb) 1.08f else 1.0f
                                scaleY = if (isDraggingThumb) 1.08f else 1.0f
                            }
                            .pointerInput(totalItems, maxTravelPx) {
                                detectVerticalDragGestures(
                                    onDragStart = {
                                        isDraggingThumb = true
                                        dragOffsetY = currentTopPx
                                    },
                                    onDragEnd = {
                                        isDraggingThumb = false
                                    },
                                    onDragCancel = {
                                        isDraggingThumb = false
                                    },
                                    onVerticalDrag = { change, dragAmount ->
                                        change.consume()
                                        dragOffsetY = (dragOffsetY + dragAmount).coerceIn(0f, maxTravelPx)
                                        if (maxTravelPx > 0f) {
                                            val newFraction = dragOffsetY / maxTravelPx
                                            val targetIndex = (newFraction * (totalItems - 1)).toInt().coerceIn(0, totalItems - 1)
                                            coroutineScope.launch {
                                                listState.scrollToItem(targetIndex)
                                            }
                                        }
                                    }
                                )
                            }
                    ) {
                        // Two horizontal rounded grip lines as in screenshot
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(13.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isDraggingThumb) colors.primary else Color(0xFF64748B))
                            )
                            Spacer(modifier = Modifier.height(3.5.dp))
                            Box(
                                modifier = Modifier
                                    .width(13.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isDraggingThumb) colors.primary else Color(0xFF64748B))
                            )
                        }
                    }
                }
            }
        }
    }
}
}
