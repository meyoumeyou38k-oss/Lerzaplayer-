package com.lerzaplayer.config

import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.firebase.firestore.FirebaseFirestore
import com.lerzaplayer.R
import com.lerzaplayer.analytics.FirebaseSyncManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Lerza Player Pro - Central Remote Configuration Manager
 * Backed by Firebase Remote Config & Cloud Firestore with real-time sync.
 * Supports targeted announcements (Specific User / Country / All).
 */
object RemoteConfigManager {
    private const val TAG = "RemoteConfigManager"

    // Remote Config Keys
    const val KEY_SHOW_ALL_ADS = "show_all_ads"
    const val KEY_REMOVE_ALL_ADS = "remove_all_ads"
    const val KEY_TEST_ADS_ENABLED = "test_ads_enabled"
    const val KEY_ENABLE_BOTTOM_BANNER_AD = "enable_bottom_banner_ad"
    const val KEY_ENABLE_APP_OPEN_AD = "enable_app_open_ad"
    const val KEY_ENABLE_PLAYER_THUMBNAIL_AD = "enable_player_thumbnail_ad"
    const val KEY_ENABLE_SONGS_LIST_AD = "enable_songs_list_ad"
    const val KEY_ENABLE_VIDEOS_LIST_AD = "enable_videos_list_ad"
    const val KEY_ENABLE_SETTINGS_CLICK_AD = "enable_settings_click_ad"
    const val KEY_ENABLE_VAULT_REWARD_AD = "enable_vault_reward_ad"

    const val KEY_BANNER_AD_UNIT_ID = "banner_ad_unit_id"
    const val KEY_APP_OPEN_AD_UNIT_ID = "app_open_ad_unit_id"
    const val KEY_INTERSTITIAL_AD_UNIT_ID = "interstitial_ad_unit_id"
    const val KEY_NATIVE_AD_UNIT_ID = "native_ad_unit_id"
    const val KEY_REWARDED_AD_UNIT_ID = "rewarded_ad_unit_id"

    const val KEY_BANNER_TEST_AD_UNIT_ID = "banner_test_ad_unit_id"
    const val KEY_APP_OPEN_TEST_AD_UNIT_ID = "app_open_test_ad_unit_id"
    const val KEY_INTERSTITIAL_TEST_AD_UNIT_ID = "interstitial_test_ad_unit_id"
    const val KEY_NATIVE_TEST_AD_UNIT_ID = "native_test_ad_unit_id"
    const val KEY_REWARDED_TEST_AD_UNIT_ID = "rewarded_test_ad_unit_id"

    const val KEY_INTERSTITIAL_AD_FREQUENCY_CLICKS = "interstitial_ad_frequency_clicks"
    const val KEY_INTERSTITIAL_AD_COOLDOWN_SECONDS = "interstitial_ad_cooldown_seconds"
    const val KEY_MAX_INTERSTITIALS_PER_SESSION = "max_interstitials_per_session"

    const val KEY_ENABLE_FEEDBACK_SYSTEM = "enable_feedback_system"
    const val KEY_ENABLE_PLAYTIME_TRACKING = "enable_playtime_tracking"
    const val KEY_LATEST_APP_VERSION_CODE = "latest_app_version_code"
    const val KEY_UPDATE_POPUP_ENABLED = "update_popup_enabled"
    const val KEY_FORCE_UPDATE_REQUIRED = "force_update_required"
    const val KEY_UPDATE_WEBSITE_URL = "update_website_url"
    const val KEY_MAINTENANCE_MODE = "maintenance_mode"
    const val KEY_ENABLE_EQUALIZER = "enable_equalizer"
    const val KEY_ENABLE_SLEEP_TIMER = "enable_sleep_timer"

    const val KEY_ANNOUNCEMENT_BANNER_TEXT = "announcement_banner_text"
    const val KEY_ANNOUNCEMENT_BANNER_LINK = "announcement_banner_link"
    const val KEY_APP_OPEN_FREQUENCY_INTERVAL = "app_open_frequency_interval"
    const val KEY_APP_OPEN_AD_COOLDOWN_SECONDS = "app_open_ad_cooldown_seconds"
    const val KEY_SONGS_LIST_AD_INTERVAL = "songs_list_ad_interval"
    const val KEY_VIDEOS_LIST_AD_INTERVAL = "videos_list_ad_interval"

    // Default Production Ad Units (AdMob Console)
    const val DEFAULT_BANNER_ID = "ca-app-pub-7375534389683057/9757608460"
    const val DEFAULT_APP_OPEN_ID = "ca-app-pub-7375534389683057/3906515984"
    const val DEFAULT_INTERSTITIAL_ID = "ca-app-pub-7375534389683057/1823278127"
    const val DEFAULT_NATIVE_ID = "ca-app-pub-7375534389683057/8388686475"
    const val DEFAULT_REWARDED_ID = "ca-app-pub-7375534389683057/7678240038"

    // Official Google Test Ad Units (Fallbacks)
    const val DEFAULT_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val DEFAULT_TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val DEFAULT_TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val DEFAULT_TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val DEFAULT_TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    const val DEFAULT_UPDATE_WEBSITE_URL = "https://lerzaplayer.vercel.app"

    // ============================================================
    // StateFlows for Reactive Architecture
    // ============================================================
    private val _showAllAds = MutableStateFlow(true)
    val showAllAds: StateFlow<Boolean> = _showAllAds.asStateFlow()

    private val _removeAllAds = MutableStateFlow(false)
    val removeAllAds: StateFlow<Boolean> = _removeAllAds.asStateFlow()

    private val _testAdsEnabled = MutableStateFlow(false)
    val testAdsEnabled: StateFlow<Boolean> = _testAdsEnabled.asStateFlow()

    private val _enableBottomBannerAd = MutableStateFlow(true)
    val enableBottomBannerAd: StateFlow<Boolean> = _enableBottomBannerAd.asStateFlow()

    var isBottomBannerAdEnabledCompose by mutableStateOf(true)
        private set

    val isBottomBannerAdEnabled: Boolean
        get() = _enableBottomBannerAd.value

    private val _enableAppOpenAd = MutableStateFlow(true)
    val enableAppOpenAd: StateFlow<Boolean> = _enableAppOpenAd.asStateFlow()

    private val _enablePlayerThumbnailAd = MutableStateFlow(true)
    val enablePlayerThumbnailAd: StateFlow<Boolean> = _enablePlayerThumbnailAd.asStateFlow()

    private val _enableSongsListAd = MutableStateFlow(true)
    val enableSongsListAd: StateFlow<Boolean> = _enableSongsListAd.asStateFlow()

    private val _enableVideosListAd = MutableStateFlow(true)
    val enableVideosListAd: StateFlow<Boolean> = _enableVideosListAd.asStateFlow()

    private val _enableSettingsClickAd = MutableStateFlow(true)
    val enableSettingsClickAd: StateFlow<Boolean> = _enableSettingsClickAd.asStateFlow()

    private val _enableVaultRewardAd = MutableStateFlow(true)
    val enableVaultRewardAd: StateFlow<Boolean> = _enableVaultRewardAd.asStateFlow()

    private val _bannerAdUnitId = MutableStateFlow(DEFAULT_BANNER_ID)
    val bannerAdUnitId: StateFlow<String> = _bannerAdUnitId.asStateFlow()

    private val _appOpenAdUnitId = MutableStateFlow(DEFAULT_APP_OPEN_ID)
    val appOpenAdUnitId: StateFlow<String> = _appOpenAdUnitId.asStateFlow()

    private val _interstitialAdUnitId = MutableStateFlow(DEFAULT_INTERSTITIAL_ID)
    val interstitialAdUnitId: StateFlow<String> = _interstitialAdUnitId.asStateFlow()

    private val _nativeAdUnitId = MutableStateFlow(DEFAULT_NATIVE_ID)
    val nativeAdUnitId: StateFlow<String> = _nativeAdUnitId.asStateFlow()

    private val _rewardedAdUnitId = MutableStateFlow(DEFAULT_REWARDED_ID)
    val rewardedAdUnitId: StateFlow<String> = _rewardedAdUnitId.asStateFlow()

    private val _interstitialAdFrequencyClicks = MutableStateFlow(4)
    val interstitialAdFrequencyClicks: StateFlow<Int> = _interstitialAdFrequencyClicks.asStateFlow()

    private val _interstitialAdCooldownSeconds = MutableStateFlow(30)
    val interstitialAdCooldownSeconds: StateFlow<Int> = _interstitialAdCooldownSeconds.asStateFlow()

    private val _appOpenFrequencyInterval = MutableStateFlow(1)
    val appOpenFrequencyInterval: StateFlow<Int> = _appOpenFrequencyInterval.asStateFlow()

    private val _appOpenAdCooldownSeconds = MutableStateFlow(30)
    val appOpenAdCooldownSeconds: StateFlow<Int> = _appOpenAdCooldownSeconds.asStateFlow()

    private val _songsListAdInterval = MutableStateFlow(4)
    val songsListAdInterval: StateFlow<Int> = _songsListAdInterval.asStateFlow()

    private val _videosListAdInterval = MutableStateFlow(4)
    val videosListAdInterval: StateFlow<Int> = _videosListAdInterval.asStateFlow()

    private val _maxInterstitialsPerSession = MutableStateFlow(15)
    val maxInterstitialsPerSession: StateFlow<Int> = _maxInterstitialsPerSession.asStateFlow()

    private val _enableFeedbackSystem = MutableStateFlow(true)
    val enableFeedbackSystem: StateFlow<Boolean> = _enableFeedbackSystem.asStateFlow()

    private val _enablePlaytimeTracking = MutableStateFlow(true)
    val enablePlaytimeTracking: StateFlow<Boolean> = _enablePlaytimeTracking.asStateFlow()

    private val _latestAppVersionCode = MutableStateFlow(4)
    val latestAppVersionCode: StateFlow<Int> = _latestAppVersionCode.asStateFlow()

    private val _updatePopupEnabled = MutableStateFlow(false)
    val updatePopupEnabled: StateFlow<Boolean> = _updatePopupEnabled.asStateFlow()

    private val _forceUpdateRequired = MutableStateFlow(false)
    val forceUpdateRequired: StateFlow<Boolean> = _forceUpdateRequired.asStateFlow()

    private val _updateWebsiteUrl = MutableStateFlow(DEFAULT_UPDATE_WEBSITE_URL)
    val updateWebsiteUrl: StateFlow<String> = _updateWebsiteUrl.asStateFlow()

    private val _maintenanceMode = MutableStateFlow(false)
    val maintenanceMode: StateFlow<Boolean> = _maintenanceMode.asStateFlow()

    private val _enableEqualizer = MutableStateFlow(true)
    val enableEqualizer: StateFlow<Boolean> = _enableEqualizer.asStateFlow()

    private val _enableSleepTimer = MutableStateFlow(true)
    val enableSleepTimer: StateFlow<Boolean> = _enableSleepTimer.asStateFlow()

    private val _announcementBannerText = MutableStateFlow("")
    val announcementBannerText: StateFlow<String> = _announcementBannerText.asStateFlow()

    private val _announcementBannerLink = MutableStateFlow("")
    val announcementBannerLink: StateFlow<String> = _announcementBannerLink.asStateFlow()

    // Direct Compose State properties for UI access
    var showAllAdsCompose by mutableStateOf(true)
        private set

    var enableEqualizerCompose by mutableStateOf(true)
        private set

    var enableSleepTimerCompose by mutableStateOf(true)
        private set

    var announcementTextCompose by mutableStateOf("")
        private set

    var announcementLinkCompose by mutableStateOf("")
        private set

    var maintenanceModeCompose by mutableStateOf(false)
        private set

    /**
     * Master Ad Logic:
     * EffectiveAds = showAllAds && !removeAllAds
     */
    val effectiveAdsEnabled: Boolean
        get() = _showAllAds.value && !_removeAllAds.value

    private var isInitialized = false
    private var hasFirestoreAdConfig = false
    private var hasFirestoreGeneralConfig = false
    private var hasFirestoreAnnouncementConfig = false
    private var lastFetchTimeMs = 0L

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true

        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }

            // Immediately launch real-time Firestore synchronization
            listenToFirestoreConfig(context.applicationContext)

            val remoteConfig = FirebaseRemoteConfig.getInstance()
            val configSettings = FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(15)
                .build()
            remoteConfig.setConfigSettingsAsync(configSettings)
            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

            syncCurrentConfig(remoteConfig)
            fetchAndActivate()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firebase Remote Config: ${e.message}", e)
        }
    }

    fun fetchAndActivate(onComplete: ((Boolean) -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (now - lastFetchTimeMs < 60_000L) {
            onComplete?.invoke(true)
            return
        }
        lastFetchTimeMs = now

        try {
            val remoteConfig = FirebaseRemoteConfig.getInstance()
            remoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "Firebase Remote Config fetch & activate successful.")
                        syncCurrentConfig(remoteConfig)
                        onComplete?.invoke(true)
                    } else {
                        Log.w(TAG, "Firebase Remote Config fetch failed: ${task.exception?.message}")
                        onComplete?.invoke(false)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during fetchAndActivate: ${e.message}", e)
            onComplete?.invoke(false)
        }
    }

    private fun syncCurrentConfig(rc: FirebaseRemoteConfig) {
        try {
            if (!hasFirestoreAdConfig) {
                val show = rc.getBoolean(KEY_SHOW_ALL_ADS)
                val remove = rc.getBoolean(KEY_REMOVE_ALL_ADS)
                _showAllAds.value = show
                _removeAllAds.value = remove
                showAllAdsCompose = show && !remove

                val isTestAds = rc.getBoolean(KEY_TEST_ADS_ENABLED)
                _testAdsEnabled.value = isTestAds

                val enableBanner = rc.getBoolean(KEY_ENABLE_BOTTOM_BANNER_AD)
                _enableBottomBannerAd.value = enableBanner
                isBottomBannerAdEnabledCompose = enableBanner

                _enableAppOpenAd.value = rc.getBoolean(KEY_ENABLE_APP_OPEN_AD)
                _enablePlayerThumbnailAd.value = rc.getBoolean(KEY_ENABLE_PLAYER_THUMBNAIL_AD)
                _enableSongsListAd.value = rc.getBoolean(KEY_ENABLE_SONGS_LIST_AD)
                _enableVideosListAd.value = rc.getBoolean(KEY_ENABLE_VIDEOS_LIST_AD)
                _enableSettingsClickAd.value = rc.getBoolean(KEY_ENABLE_SETTINGS_CLICK_AD)
                _enableVaultRewardAd.value = rc.getBoolean(KEY_ENABLE_VAULT_REWARD_AD)

                if (isTestAds) {
                    _bannerAdUnitId.value = DEFAULT_TEST_BANNER_ID
                    _appOpenAdUnitId.value = DEFAULT_TEST_APP_OPEN_ID
                    _interstitialAdUnitId.value = DEFAULT_TEST_INTERSTITIAL_ID
                    _nativeAdUnitId.value = DEFAULT_TEST_NATIVE_ID
                    _rewardedAdUnitId.value = DEFAULT_TEST_REWARDED_ID
                } else {
                    val banner = rc.getString(KEY_BANNER_AD_UNIT_ID).trim()
                    if (banner.isNotBlank()) _bannerAdUnitId.value = banner
                    val appOpen = rc.getString(KEY_APP_OPEN_AD_UNIT_ID).trim()
                    if (appOpen.isNotBlank()) _appOpenAdUnitId.value = appOpen
                    val interstitial = rc.getString(KEY_INTERSTITIAL_AD_UNIT_ID).trim()
                    if (interstitial.isNotBlank()) _interstitialAdUnitId.value = interstitial
                    val nativeAd = rc.getString(KEY_NATIVE_AD_UNIT_ID).trim()
                    if (nativeAd.isNotBlank()) _nativeAdUnitId.value = nativeAd
                    val rewarded = rc.getString(KEY_REWARDED_AD_UNIT_ID).trim()
                    if (rewarded.isNotBlank()) _rewardedAdUnitId.value = rewarded
                }

                val freq = rc.getLong(KEY_INTERSTITIAL_AD_FREQUENCY_CLICKS).toInt()
                if (freq > 0) _interstitialAdFrequencyClicks.value = freq
                val cooldown = rc.getLong(KEY_INTERSTITIAL_AD_COOLDOWN_SECONDS).toInt()
                if (cooldown >= 0) _interstitialAdCooldownSeconds.value = cooldown

                val appOpenInterval = rc.getLong(KEY_APP_OPEN_FREQUENCY_INTERVAL).toInt()
                if (appOpenInterval > 0) _appOpenFrequencyInterval.value = appOpenInterval

                val appOpenCooldown = rc.getLong(KEY_APP_OPEN_AD_COOLDOWN_SECONDS).toInt()
                val songsInterval = rc.getLong(KEY_SONGS_LIST_AD_INTERVAL).toInt()
                if (songsInterval > 0) _songsListAdInterval.value = songsInterval.coerceIn(1, 50)
                val videosInterval = rc.getLong(KEY_VIDEOS_LIST_AD_INTERVAL).toInt()
                if (videosInterval > 0) _videosListAdInterval.value = videosInterval.coerceIn(1, 50)
                if (appOpenCooldown >= 0) _appOpenAdCooldownSeconds.value = appOpenCooldown
                val maxPerSession = rc.getLong(KEY_MAX_INTERSTITIALS_PER_SESSION).toInt()
                if (maxPerSession > 0) _maxInterstitialsPerSession.value = maxPerSession
            }

            if (!hasFirestoreGeneralConfig) {
                _enableFeedbackSystem.value = rc.getBoolean(KEY_ENABLE_FEEDBACK_SYSTEM)
                _enablePlaytimeTracking.value = rc.getBoolean(KEY_ENABLE_PLAYTIME_TRACKING)
                val vCode = rc.getLong(KEY_LATEST_APP_VERSION_CODE).toInt()
                if (vCode > 0) _latestAppVersionCode.value = vCode
                _updatePopupEnabled.value = rc.getBoolean(KEY_UPDATE_POPUP_ENABLED)
                _forceUpdateRequired.value = rc.getBoolean(KEY_FORCE_UPDATE_REQUIRED)
                val updateUrl = rc.getString(KEY_UPDATE_WEBSITE_URL).trim()
                if (updateUrl.isNotBlank()) _updateWebsiteUrl.value = updateUrl
                val maintenance = rc.getBoolean(KEY_MAINTENANCE_MODE)
                _maintenanceMode.value = maintenance
                maintenanceModeCompose = maintenance
                val eq = rc.getBoolean(KEY_ENABLE_EQUALIZER)
                _enableEqualizer.value = eq
                enableEqualizerCompose = eq
                val sleepTimer = rc.getBoolean(KEY_ENABLE_SLEEP_TIMER)
                _enableSleepTimer.value = sleepTimer
                enableSleepTimerCompose = sleepTimer
            }

            if (!hasFirestoreAnnouncementConfig) {
                val announcement = rc.getString(KEY_ANNOUNCEMENT_BANNER_TEXT).trim()
                _announcementBannerText.value = announcement
                announcementTextCompose = announcement
                val announcementLink = rc.getString(KEY_ANNOUNCEMENT_BANNER_LINK).trim()
                _announcementBannerLink.value = announcementLink
                announcementLinkCompose = announcementLink
            }

            Log.d(TAG, "Config sync completed: adsEnabled=$showAllAdsCompose, testAds=${_testAdsEnabled.value}")
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing config values: ${e.message}", e)
        }
    }

    /**
     * Real-time Cloud Firestore synchronization.
     * Keeps app configuration in instant sync with the Web Admin Dashboard.
     * Supports device-specific and country-specific announcement filters.
     */
    private fun listenToFirestoreConfig(appContext: Context) {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val myDeviceId = FirebaseSyncManager.getPermanentDeviceId(appContext)
            val myCountry = FirebaseSyncManager.getDeviceCountryCode(appContext).uppercase(Locale.ROOT)

            // 1. Live AdMob Controls
            firestore.collection("app_config").document("ads")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore app_config/ads sync warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val data = snapshot.data ?: return@addSnapshotListener
                        hasFirestoreAdConfig = true
                        Log.d(TAG, "Live Firestore Ad Config received: $data")

                        (data["show_all_ads"] as? Boolean)?.let { _showAllAds.value = it }
                        (data["remove_all_ads"] as? Boolean)?.let { _removeAllAds.value = it }
                        showAllAdsCompose = _showAllAds.value && !_removeAllAds.value

                        val isTestMode = (data["test_ads_enabled"] as? Boolean) ?: _testAdsEnabled.value
                        _testAdsEnabled.value = isTestMode

                        if (isTestMode) {
                            _bannerAdUnitId.value = DEFAULT_TEST_BANNER_ID
                            _appOpenAdUnitId.value = DEFAULT_TEST_APP_OPEN_ID
                            _interstitialAdUnitId.value = DEFAULT_TEST_INTERSTITIAL_ID
                            _nativeAdUnitId.value = DEFAULT_TEST_NATIVE_ID
                            _rewardedAdUnitId.value = DEFAULT_TEST_REWARDED_ID
                        } else {
                            (data["banner_ad_unit_id"] as? String)?.takeIf { it.isNotBlank() }?.let { _bannerAdUnitId.value = it }
                                ?: run { _bannerAdUnitId.value = DEFAULT_BANNER_ID }
                            (data["app_open_ad_unit_id"] as? String)?.takeIf { it.isNotBlank() }?.let { _appOpenAdUnitId.value = it }
                                ?: run { _appOpenAdUnitId.value = DEFAULT_APP_OPEN_ID }
                            (data["interstitial_ad_unit_id"] as? String)?.takeIf { it.isNotBlank() }?.let { _interstitialAdUnitId.value = it }
                                ?: run { _interstitialAdUnitId.value = DEFAULT_INTERSTITIAL_ID }
                            (data["native_ad_unit_id"] as? String)?.takeIf { it.isNotBlank() }?.let { _nativeAdUnitId.value = it }
                                ?: run { _nativeAdUnitId.value = DEFAULT_NATIVE_ID }
                            (data["rewarded_ad_unit_id"] as? String)?.takeIf { it.isNotBlank() }?.let { _rewardedAdUnitId.value = it }
                                ?: run { _rewardedAdUnitId.value = DEFAULT_REWARDED_ID }
                        }

                        (data["enable_bottom_banner_ad"] as? Boolean)?.let { 
                            _enableBottomBannerAd.value = it
                            isBottomBannerAdEnabledCompose = it
                        }
                        (data["enable_app_open_ad"] as? Boolean)?.let { _enableAppOpenAd.value = it }
                        (data["enable_player_thumbnail_ad"] as? Boolean)?.let { _enablePlayerThumbnailAd.value = it }
                        (data["enable_songs_list_ad"] as? Boolean)?.let { _enableSongsListAd.value = it }
                        (data["enable_videos_list_ad"] as? Boolean)?.let { _enableVideosListAd.value = it }
                        (data["enable_settings_click_ad"] as? Boolean)?.let { _enableSettingsClickAd.value = it }
                        (data["enable_vault_reward_ad"] as? Boolean)?.let { _enableVaultRewardAd.value = it }

                        val rawFreq = data["interstitial_ad_frequency_clicks"]
                        val parsedFreq = when (rawFreq) {
                            is Number -> rawFreq.toInt()
                            is String -> rawFreq.trim().toIntOrNull() ?: 4
                            else -> 4
                        }
                        if (parsedFreq > 0) _interstitialAdFrequencyClicks.value = parsedFreq.coerceIn(1, 1000)

                        val rawCooldown = data["interstitial_ad_cooldown_seconds"]
                        val parsedCooldown = when (rawCooldown) {
                            is Number -> rawCooldown.toInt()
                            is String -> rawCooldown.trim().toIntOrNull() ?: 30
                            else -> 30
                        }
                        if (parsedCooldown >= 0) _interstitialAdCooldownSeconds.value = parsedCooldown.coerceIn(0, 86400)

                        val rawAppOpenInterval = data["app_open_frequency_interval"]
                        val parsedAppOpenInterval = when (rawAppOpenInterval) {
                            is Number -> rawAppOpenInterval.toInt()
                            is String -> rawAppOpenInterval.trim().toIntOrNull() ?: 3
                            else -> 3
                        }
                        if (parsedAppOpenInterval > 0) _appOpenFrequencyInterval.value = parsedAppOpenInterval.coerceIn(1, 100)

                        val rawAppOpenCooldown = data["app_open_ad_cooldown_seconds"]
                        val parsedAppOpenCooldown = when (rawAppOpenCooldown) {
                            is Number -> rawAppOpenCooldown.toInt()
                            is String -> rawAppOpenCooldown.trim().toIntOrNull() ?: 30
                            else -> 30
                        }
                        if (parsedAppOpenCooldown >= 0) _appOpenAdCooldownSeconds.value = parsedAppOpenCooldown.coerceIn(0, 86400)
                        val rawSongsInterval = data["songs_list_ad_interval"]
                        val parsedSongsInterval = when (rawSongsInterval) {
                            is Number -> rawSongsInterval.toInt()
                            is String -> rawSongsInterval.trim().toIntOrNull() ?: 4
                            else -> 4
                        }
                        if (parsedSongsInterval > 0) _songsListAdInterval.value = parsedSongsInterval.coerceIn(1, 50)
                        val rawVideosInterval = data["videos_list_ad_interval"]
                        val parsedVideosInterval = when (rawVideosInterval) {
                            is Number -> rawVideosInterval.toInt()
                            is String -> rawVideosInterval.trim().toIntOrNull() ?: 4
                            else -> 4
                        }
                        if (parsedVideosInterval > 0) _videosListAdInterval.value = parsedVideosInterval.coerceIn(1, 50)

                        Log.d(TAG, "Ad Config updated from Firestore: showAllAds=$showAllAdsCompose, testMode=$isTestMode")
                    }
                }

            // 2. Live Feature Flags & Maintenance
            firestore.collection("app_config").document("general")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore app_config/general sync warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val data = snapshot.data ?: return@addSnapshotListener
                        hasFirestoreGeneralConfig = true
                        Log.d(TAG, "Live Firestore General Config received: $data")

                        (data["enable_equalizer"] as? Boolean)?.let { 
                            _enableEqualizer.value = it
                            enableEqualizerCompose = it
                        }
                        (data["enable_sleep_timer"] as? Boolean)?.let { 
                            _enableSleepTimer.value = it
                            enableSleepTimerCompose = it
                        }
                        (data["enable_feedback_system"] as? Boolean)?.let { _enableFeedbackSystem.value = it }
                        (data["enable_playtime_tracking"] as? Boolean)?.let { _enablePlaytimeTracking.value = it }
                        (data["maintenance_mode"] as? Boolean)?.let { 
                            _maintenanceMode.value = it
                            maintenanceModeCompose = it
                        }
                        (data["update_popup_enabled"] as? Boolean)?.let { _updatePopupEnabled.value = it }
                        (data["force_update_required"] as? Boolean)?.let { _forceUpdateRequired.value = it }
                        (data["latest_app_version_code"] as? Number)?.toInt()?.let { _latestAppVersionCode.value = it }
                        (data["update_website_url"] as? String)?.takeIf { it.isNotBlank() }?.let { _updateWebsiteUrl.value = it }

                        // Fallback general announcement if dedicated announcement not present
                        if (!hasFirestoreAnnouncementConfig) {
                            (data["announcement_banner_text"] as? String)?.let { text ->
                                _announcementBannerText.value = text
                                announcementTextCompose = text
                            }
                            (data["announcement_banner_link"] as? String)?.let { link ->
                                _announcementBannerLink.value = link
                                announcementLinkCompose = link
                            }
                        }
                    }
                }

            // 3. Live Dedicated Announcement Ribbon Sync with Universal Field & Collection Support
            val updateAnnouncementIfMatched: (Map<String, Any?>) -> Unit = { data ->
                val isActive = when (val a = data["is_active"] ?: data["active"] ?: data["enabled"] ?: data["show"]) {
                    is Boolean -> a
                    is String -> !a.equals("false", ignoreCase = true)
                    else -> true
                }
                val text = (data["text"] ?: data["announcement"] ?: data["message"] ?: data["body"] 
                    ?: data["content"] ?: data["description"] ?: data["announcement_banner_text"] 
                    ?: data["title"] ?: data["heading"])?.toString()?.trim() ?: ""
                val link = (data["link"] ?: data["announcement_banner_link"] ?: data["url"] 
                    ?: data["target_url"] ?: data["deep_link"])?.toString()?.trim() ?: ""

                // Targeting rules
                val targetAudience = (data["target_audience"] ?: "all_users").toString().trim()
                val targetDeviceId = data["target_device_id"]?.toString()?.trim()
                val targetCountry = data["target_country"]?.toString()?.trim()?.uppercase(Locale.ROOT)

                var isTargetMatched = true
                if (targetAudience.equals("specific_device", ignoreCase = true) && !targetDeviceId.isNullOrBlank()) {
                    if (targetDeviceId != myDeviceId && !myDeviceId.contains(targetDeviceId) && !targetDeviceId.contains(myDeviceId)) {
                        isTargetMatched = false
                    }
                } else if (targetAudience.equals("country", ignoreCase = true) && !targetCountry.isNullOrBlank() && targetCountry != "ALL") {
                    if (myCountry.isNotBlank() && targetCountry != myCountry) {
                        isTargetMatched = false
                    }
                }

                if (isActive && text.isNotBlank() && isTargetMatched) {
                    hasFirestoreAnnouncementConfig = true
                    _announcementBannerText.value = text
                    announcementTextCompose = text
                    _announcementBannerLink.value = link
                    announcementLinkCompose = link
                    Log.d(TAG, "Live Announcement Banner activated: '$text'")
                } else if (!isActive || !isTargetMatched) {
                    _announcementBannerText.value = ""
                    announcementTextCompose = ""
                    _announcementBannerLink.value = ""
                    announcementLinkCompose = ""
                }
            }

            // 3a. Listen to document app_config/announcement
            firestore.collection("app_config").document("announcement")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore app_config/announcement warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        snapshot.data?.let { updateAnnouncementIfMatched(it) }
                    }
                }

            // 3b. Listen to live announcements collection in Firestore
            firestore.collection("announcements")
                .limit(10)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore announcements collection warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        for (doc in snapshot.documents) {
                            doc.data?.let { updateAnnouncementIfMatched(it) }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception attaching Firestore config listener: ${e.message}", e)
        }
    }
}
