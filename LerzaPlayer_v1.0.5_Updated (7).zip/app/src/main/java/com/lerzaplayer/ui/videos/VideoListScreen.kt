package com.lerzaplayer.ui.videos

import android.widget.Toast
import android.content.Intent
import androidx.compose.ui.platform.LocalContext

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.BoxWithConstraints
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import com.lerzaplayer.ads.NativeAdFeedItem
import com.lerzaplayer.ads.AdManager
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.CustomTitleManager
import com.lerzaplayer.data.model.ViewMode
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun VideoListScreen(
    videos: List<VideoItem>,
    viewMode: ViewMode,
    onVideoClick: (VideoItem) -> Unit,
    onViewModeToggle: () -> Unit,
    onScanDevice: () -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onHideInVault: (VideoItem) -> Unit,
    onDelete: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var activeActionVideo by remember { mutableStateOf<VideoItem?>(null) }
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()
    val videosListAdInterval by com.lerzaplayer.config.RemoteConfigManager.videosListAdInterval.collectAsState()
    val showAllAds by com.lerzaplayer.config.RemoteConfigManager.showAllAds.collectAsState()
    val removeAllAds by com.lerzaplayer.config.RemoteConfigManager.removeAllAds.collectAsState()
    val isVideosListAdEnabled by com.lerzaplayer.config.RemoteConfigManager.enableVideosListAd.collectAsState()

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${videos.size} Videos Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onScanDevice,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Scan", fontSize = 11.sp)
                }

                IconButton(
                    onClick = onViewModeToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (viewMode == ViewMode.GRID) LerzaIcons.ViewList else LerzaIcons.GridView,
                        contentDescription = "Toggle View",
                        tint = colors.textPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (viewMode == ViewMode.GRID) {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Fixed(2),
                    flingBehavior = ScrollableDefaults.flingBehavior(),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    videos.forEachIndexed { index, video ->
                        item(key = video.id) {
                            VideoGridCard(
                                video = video,
                                onClick = { onVideoClick(video) },
                                onLongClick = { activeActionVideo = video },
                                onToggleFavorite = { onToggleFavorite(video) },
                                onHideInVault = { onHideInVault(video) },
                                onDelete = { onDelete(video) }
                            )
                        }
                        if (index == 3 || index == 11 || index == 21) {
                            item(span = { GridItemSpan(2) }, key = "grid_ad_$index") {
                                NativeAdFeedItem(isForVideo = true)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    flingBehavior = ScrollableDefaults.flingBehavior(),
                    contentPadding = PaddingValues(bottom = 90.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(
                        items = videos,
                        key = { _, video -> video.id },
                        contentType = { _, _ -> "video_row" }
                    ) { index, video ->
                        VideoListRow(
                            video = video,
                            onClick = { onVideoClick(video) },
                            onLongClick = { activeActionVideo = video },
                            onToggleFavorite = { onToggleFavorite(video) },
                            onHideInVault = { onHideInVault(video) },
                            onDelete = { onDelete(video) }
                        )
                        if (showAllAds && !removeAllAds && isVideosListAdEnabled) {
                            val interval: Int = videosListAdInterval.coerceAtLeast(2)
                            if ((index + 1) % interval == 0) {
                                NativeAdFeedItem(isForVideo = true)
                            }
                        }
                    }
                }
            }

            // 🌟 Fast-Scroll Capsule Pill Handle for Videos
            if (videos.size > 8) {
                var isDraggingThumb by remember { mutableStateOf(false) }
                var isThumbVisible by remember { mutableStateOf(false) }
                var dragOffsetY by remember { mutableFloatStateOf(0f) }

                val isScrolling = if (viewMode == ViewMode.GRID) gridState.isScrollInProgress else listState.isScrollInProgress
                LaunchedEffect(isScrolling, isDraggingThumb) {
                    if (isScrolling || isDraggingThumb) {
                        isThumbVisible = true
                    } else {
                        delay(1400)
                        val stillScrolling = if (viewMode == ViewMode.GRID) gridState.isScrollInProgress else listState.isScrollInProgress
                        if (!stillScrolling && !isDraggingThumb) {
                            isThumbVisible = false
                        }
                    }
                }

                val thumbAlpha by animateFloatAsState(
                    targetValue = if (isThumbVisible) 1f else 0f,
                    animationSpec = tween(durationMillis = 280),
                    label = "videoThumbAlpha"
                )

                val totalItems = videos.size.coerceAtLeast(1)
                val firstIndex = if (viewMode == ViewMode.GRID) gridState.firstVisibleItemIndex else listState.firstVisibleItemIndex
                val scrollFraction = (firstIndex.toFloat() / (totalItems - 1).coerceAtLeast(1)).coerceIn(0f, 1f)

                if (thumbAlpha > 0.01f) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxHeight()
                            .align(Alignment.CenterEnd)
                            .padding(top = 8.dp, bottom = 95.dp, end = 3.dp)
                    ) {
                        val trackHeightPx = constraints.maxHeight.toFloat()
                        val thumbHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { 54.dp.toPx() }
                        val maxTravelPx = (trackHeightPx - thumbHeightPx).coerceAtLeast(0f)
                        val currentTopPx = if (isDraggingThumb) {
                            dragOffsetY.coerceIn(0f, maxTravelPx)
                        } else {
                            scrollFraction * maxTravelPx
                        }

                        Surface(
                            shape = RoundedCornerShape(percent = 50),
                            color = if (isDraggingThumb) Color(0xFFF8FAFC) else Color(0xFFE2E8F0).copy(alpha = 0.94f),
                            shadowElevation = if (isDraggingThumb) 8.dp else 4.dp,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isDraggingThumb) colors.primary.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.7f)
                            ),
                            modifier = Modifier
                                .width(28.dp)
                                .height(54.dp)
                                .graphicsLayer {
                                    translationY = currentTopPx
                                    alpha = thumbAlpha
                                    scaleX = if (isDraggingThumb) 1.08f else 1.0f
                                    scaleY = if (isDraggingThumb) 1.08f else 1.0f
                                }
                                .pointerInput(totalItems, maxTravelPx, viewMode) {
                                    detectVerticalDragGestures(
                                        onDragStart = {
                                            isDraggingThumb = true
                                            dragOffsetY = currentTopPx
                                        },
                                        onDragEnd = { isDraggingThumb = false },
                                        onDragCancel = { isDraggingThumb = false },
                                        onVerticalDrag = { change, dragAmount ->
                                            change.consume()
                                            dragOffsetY = (dragOffsetY + dragAmount).coerceIn(0f, maxTravelPx)
                                            if (maxTravelPx > 0f) {
                                                val newFraction = dragOffsetY / maxTravelPx
                                                val targetIndex = (newFraction * (totalItems - 1)).toInt().coerceIn(0, totalItems - 1)
                                                coroutineScope.launch {
                                                    if (viewMode == ViewMode.GRID) {
                                                        gridState.scrollToItem(targetIndex)
                                                    } else {
                                                        listState.scrollToItem(targetIndex)
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(13.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (isDraggingThumb) colors.primary else Color(0xFF64748B))
                                )
                                Spacer(modifier = Modifier.height(3.5.dp))
                                Box(
                                    modifier = Modifier
                                        .width(13.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (isDraggingThumb) colors.primary else Color(0xFF64748B))
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 🌟 لانگ پریس باٹم شیٹ: شیئر (درمیان)، ہائیڈ (بائیں)، ڈیلیٹ (دائیں)
    if (activeActionVideo != null) {
        val selectedVideo = activeActionVideo!!
        ModalBottomSheet(
            onDismissRequest = { activeActionVideo = null },
            containerColor = colors.surface,
            dragHandle = { BottomSheetDefaults.DragHandle() },
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // ویڈیو کا پریویو اور عنوان
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 68.dp, height = 46.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black)
                    ) {
                        AsyncImage(
                            model = selectedVideo.contentUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(3.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.Black.copy(alpha = 0.8f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = selectedVideo.durationFormatted,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedVideo.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${selectedVideo.folderName} • ${selectedVideo.resolution}",
                            fontSize = 11.5.sp,
                            color = colors.textSecondary
                        )
                    }
                }

                HorizontalDivider(color = colors.card, thickness = 0.8.dp)
                Spacer(modifier = Modifier.height(20.dp))

                // 3 ایکشن بٹنز: ہائیڈ (بائیں)، شیئر (درمیان)، ڈیلیٹ (دائیں)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. Hide (بائیں جانب) -> والٹ میں محفوظ کرے
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                val target = selectedVideo
                                activeActionVideo = null
                                onHideInVault(target)
                                Toast.makeText(context, "Video moved to Private Vault", Toast.LENGTH_SHORT).show()
                            }
                            .padding(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF8B5CF6).copy(alpha = 0.15f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VisibilityOff,
                                    contentDescription = "Hide in Vault",
                                    tint = Color(0xFF8B5CF6),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Hide",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary
                        )
                    }

                    // 2. Share (درمیان میں) -> اینڈرائیڈ شیئر ڈائیلاگ
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                val target = selectedVideo
                                activeActionVideo = null
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/*"
                                        putExtra(Intent.EXTRA_STREAM, target.contentUri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share: ${target.title}"))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not share video: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF0EA5E9).copy(alpha = 0.15f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share Video",
                                    tint = Color(0xFF0EA5E9),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Share",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary
                        )
                    }

                    // 3. Delete (دائیں جانب) -> ڈیلیٹ کنفرمیشن ڈائیلاگ
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                val target = selectedVideo
                                activeActionVideo = null
                                onDelete(target)
                            }
                            .padding(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFFF334B).copy(alpha = 0.15f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Video",
                                    tint = Color(0xFFFF334B),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Delete",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFF334B)
                        )
                    }
                }
            }
        }
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoGridCard(
    video: VideoItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var newVideoTitle by remember(video.title) { mutableStateOf(video.title) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(Color.Black)
        ) {
            AsyncImage(
                model = video.contentUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF00B0FF))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "HD",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.title,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = video.folderName,
                    fontSize = 11.5.sp,
                    color = colors.textSecondary
                )
            }

            Box {
                Surface(
                    shape = CircleShape,
                    color = colors.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(32.dp)
                ) {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = LerzaIcons.MoreVert,
                            contentDescription = "Options",
                            tint = colors.textPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    VideoActionItem(
                        icon = Icons.Default.Edit,
                        title = "Rename Video",
                        accentColor = Color(0xFFFFB300),
                        onClick = {
                            menuExpanded = false
                            showRenameDialog = true
                        }
                    )
                    VideoActionItem(
                        icon = LerzaIcons.Info,
                        title = "Video Info",
                        accentColor = colors.primary,
                        onClick = {
                            menuExpanded = false
                            showDetailsDialog = true
                        }
                    )
                    VideoActionItem(
                        icon = if (video.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        title = if (video.isFavorite) "Remove Favorite" else "Add to Favorites",
                        accentColor = Color(0xFFFF334B),
                        onClick = {
                            menuExpanded = false
                            onToggleFavorite()
                        }
                    )
                    VideoActionItem(
                        icon = LerzaIcons.VisibilityOff,
                        title = "Hide in Vault",
                        accentColor = Color(0xFF9C27B0),
                        onClick = {
                            menuExpanded = false
                            onHideInVault()
                        }
                    )
                    HorizontalDivider(color = colors.card, thickness = 0.6.dp)
                    VideoActionItem(
                        icon = LerzaIcons.Delete,
                        title = "Delete",
                        accentColor = Color(0xFFFF334B),
                        textColor = Color(0xFFFF334B),
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }


    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Video", fontWeight = FontWeight.Bold, color = colors.textPrimary) },
            text = {
                Column {
                    Text("Enter new name for video:", fontSize = 13.sp, color = colors.textSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newVideoTitle,
                        onValueChange = { newVideoTitle = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newVideoTitle.isNotBlank()) {
                        CustomTitleManager.setTitle(video.id, newVideoTitle)
                        Toast.makeText(context, "Video renamed!", Toast.LENGTH_SHORT).show()
                    }
                    showRenameDialog = false
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = colors.surface
        )
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Video Details",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${video.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Folder: ${video.folderName}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${video.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Resolution: ${video.resolution}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Path: ${video.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = Color(0xFF1E60F2))
                }
            },
            containerColor = colors.surface
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoListRow(
    video: VideoItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var newVideoTitle by remember(video.title) { mutableStateOf(video.title) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { onClick() },
                onLongClick = onLongClick
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 84.dp, height = 52.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.Black)
        ) {
            AsyncImage(
                model = video.contentUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(3.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Device Videos • ${video.folderName}",
                fontSize = 12.sp,
                color = colors.textSecondary
            )
        }

        Box {
            Surface(
                shape = CircleShape,
                color = colors.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(34.dp)
            ) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = colors.textPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(colors.surface)
            ) {
                VideoActionItem(
                    icon = LerzaIcons.Info,
                    title = "Video Info",
                    accentColor = colors.primary,
                    onClick = {
                        menuExpanded = false
                        showDetailsDialog = true
                    }
                )
                VideoActionItem(
                    icon = if (video.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                    title = if (video.isFavorite) "Remove Favorite" else "Add to Favorites",
                    accentColor = Color(0xFFFF334B),
                    onClick = {
                        menuExpanded = false
                        onToggleFavorite()
                    }
                )
                VideoActionItem(
                    icon = LerzaIcons.VisibilityOff,
                    title = "Hide in Vault",
                    accentColor = Color(0xFF9C27B0),
                    onClick = {
                        menuExpanded = false
                        onHideInVault()
                    }
                )
                HorizontalDivider(color = colors.card, thickness = 0.6.dp)
                VideoActionItem(
                    icon = LerzaIcons.Delete,
                    title = "Delete",
                    accentColor = Color(0xFFFF334B),
                    textColor = Color(0xFFFF334B),
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }


    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Video", fontWeight = FontWeight.Bold, color = colors.textPrimary) },
            text = {
                Column {
                    Text("Enter new name for video:", fontSize = 13.sp, color = colors.textSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newVideoTitle,
                        onValueChange = { newVideoTitle = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newVideoTitle.isNotBlank()) {
                        CustomTitleManager.setTitle(video.id, newVideoTitle)
                        Toast.makeText(context, "Video renamed!", Toast.LENGTH_SHORT).show()
                    }
                    showRenameDialog = false
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = colors.surface
        )
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Video Details",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${video.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Folder: ${video.folderName}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${video.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Resolution: ${video.resolution}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Path: ${video.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = Color(0xFF1E60F2))
                }
            },
            containerColor = colors.surface
        )
    }
}

/**
 * Modern styled action item for video dropdown menus with rounded colored icon badge
 */
@Composable
private fun VideoActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentColor: Color,
    textColor: Color? = null,
    onClick: () -> Unit
) {
    val finalTextColor = textColor ?: LocalLerzaColors.current.textPrimary
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = finalTextColor,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium
            )
        },
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    )
}