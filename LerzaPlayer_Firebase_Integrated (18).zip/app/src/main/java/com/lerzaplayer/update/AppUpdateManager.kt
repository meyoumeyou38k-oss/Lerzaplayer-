package com.lerzaplayer.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import com.lerzaplayer.config.RemoteConfigManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UpdateInfo(
    val versionName: String,
    val versionCode: Int,
    val releaseTitle: String,
    val websiteUrl: String,
    val isForceUpdate: Boolean = false
)

/**
 * Amazon Appstore & Google Play Compliant AppUpdateManager
 * 
 * Completely replaces obsolete in-app APK downloading and PackageInstaller logic.
 * Reads update parameters dynamically from Firebase Remote Config:
 * - latest_app_version_code
 * - update_popup_enabled
 * - update_website_url
 * - maintenance_mode
 * 
 * Redirects the user securely to the official website or app store via standard browser Intent.ACTION_VIEW.
 */
object AppUpdateManager {
    private const val TAG = "AppUpdateManager"

    private val _availableUpdate = MutableStateFlow<UpdateInfo?>(null)
    val availableUpdate: StateFlow<UpdateInfo?> = _availableUpdate.asStateFlow()

    /**
     * Checks if a new update is available by comparing installed versionCode
     * with Firebase Remote Config's latest_app_version_code.
     */
    fun checkForUpdates(context: Context): UpdateInfo? {
        val isPopupEnabled = RemoteConfigManager.updatePopupEnabled.value
        val latestVersionCode = RemoteConfigManager.latestAppVersionCode.value

        val currentVersionCode = try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pInfo.longVersionCode.toInt()
            } else {
                @Suppress("DEPRECATION")
                pInfo.versionCode
            }
        } catch (e: Exception) {
            1
        }

        Log.d(TAG, "Update check: current=$currentVersionCode, remoteLatest=$latestVersionCode, popupEnabled=$isPopupEnabled")

        if (isPopupEnabled && latestVersionCode > currentVersionCode) {
            val updateUrl = RemoteConfigManager.updateWebsiteUrl.value.ifBlank {
                RemoteConfigManager.DEFAULT_UPDATE_WEBSITE_URL
            }

            val info = UpdateInfo(
                versionName = "v${latestVersionCode}.0",
                versionCode = latestVersionCode,
                releaseTitle = "New Update Available!",
                websiteUrl = updateUrl,
                isForceUpdate = false
            )
            _availableUpdate.value = info
            return info
        } else {
            _availableUpdate.value = null
            return null
        }
    }

    /**
     * Redirects user safely to developer website / app store via standard browser intent.
     * Compliant with Amazon Appstore & Google Play security guidelines (NO direct APK downloading).
     */
    fun openUpdateWebsite(context: Context) {
        try {
            val rawUrl = RemoteConfigManager.updateWebsiteUrl.value.ifBlank {
                RemoteConfigManager.DEFAULT_UPDATE_WEBSITE_URL
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(rawUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open update website: ${e.message}", e)
        }
    }

    fun dismissUpdate() {
        _availableUpdate.value = null
    }
}
