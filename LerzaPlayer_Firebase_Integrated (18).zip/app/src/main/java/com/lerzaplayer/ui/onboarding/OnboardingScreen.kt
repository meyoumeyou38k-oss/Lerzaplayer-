package com.lerzaplayer.ui.onboarding

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch
import java.security.MessageDigest

@Composable
fun OnboardingScreen(
    prefManager: PreferenceManager,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activeColor = ThemeManager.currentThemeColor
    val colors = LocalLerzaColors.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    var currentStep by remember { mutableIntStateOf(1) }
    val totalSteps = 8

    // Language state
    val currentLang by LanguageManager.currentLanguage.collectAsState()

    // Theme & wallpaper state
    var selectedThemeMode by remember { mutableStateOf(ThemeManager.currentThemeMode) }
    var selectedWallpaperUri by remember { mutableStateOf<Uri?>(null) }
    var wallpaperOpacity by remember { mutableFloatStateOf(0.75f) }

    // User name state
    var userNameInput by remember { mutableStateOf("") }

    // Vault 4-Digit In-App Keypad State
    var enteredPin by remember { mutableStateOf("") }
    var tempPinFirst by remember { mutableStateOf("") }
    var isConfirmStep by remember { mutableStateOf(false) }
    var isVaultPinConfigured by remember { mutableStateOf(false) }
    var pinErrorMessage by remember { mutableStateOf<String?>(null) }

    // Interactive Notification Preview States in Step 6
    var previewIsFavorite by remember { mutableStateOf(false) }
    var previewIsPlaying by remember { mutableStateOf(true) }
    var previewNotificationDismissed by remember { mutableStateOf(false) }

    // Permission states
    var isNotificationAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var isAudioAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isVideoAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isPhotosAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var isAllFilesAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else true
        )
    }

    // Permission Launchers
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationAllowed = granted
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isAudioAllowed = granted
    }

    val videoPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isVideoAllowed = granted
    }

    val photosPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isPhotosAllowed = granted
    }

    val allFilesPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            isAllFilesAllowed = Environment.isExternalStorageManager()
        }
    }

    val wallpaperPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedWallpaperUri = uri
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    // Auto-prompt notification on step 6
    LaunchedEffect(currentStep) {
        if (currentStep == 6) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                isNotificationAllowed = granted
                if (!granted) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            } else {
                isNotificationAllowed = true
            }
        }
        if (currentStep == 7) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                isAllFilesAllowed = Environment.isExternalStorageManager()
            }
        }
    }

    BackHandler(enabled = currentStep > 1) {
        currentStep -= 1
    }

    fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(pin.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    // Step 5 handles PIN logic when 4 digits are entered
    LaunchedEffect(enteredPin) {
        if (enteredPin.length == 4) {
            if (!isConfirmStep) {
                tempPinFirst = enteredPin
                enteredPin = ""
                isConfirmStep = true
                pinErrorMessage = null
            } else {
                if (enteredPin == tempPinFirst) {
                    val hashed = hashPin(enteredPin)
                    scope.launch {
                        prefManager.setVaultPin(hashed)
                        VaultManager.getInstance(context).updatePin(enteredPin)
                    }
                    isVaultPinConfigured = true
                    pinErrorMessage = null
                } else {
                    pinErrorMessage = "PINs do not match. Please re-enter."
                    enteredPin = ""
                    tempPinFirst = ""
                    isConfirmStep = false
                }
            }
        }
    }

    val allStep7PermissionsGranted = isAudioAllowed && isVideoAllowed && isPhotosAllowed && isAllFilesAllowed

    val isNextEnabled = when (currentStep) {
        5 -> isVaultPinConfigured
        6 -> isNotificationAllowed
        7 -> allStep7PermissionsGranted
        else -> true
    }

    val showNextButton = when (currentStep) {
        6 -> isNotificationAllowed
        7 -> allStep7PermissionsGranted
        else -> true
    }

    val emeraldGradient = Brush.linearGradient(
        listOf(Color(0xFF10B981), Color(0xFF059669))
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                })
            }
    ) {
        // Background custom wallpaper preview if selected
        if (selectedWallpaperUri != null) {
            AsyncImage(
                model = selectedWallpaperUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Top subtle ambient glow
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            activeColor.copy(alpha = 0.22f),
                            Color.Transparent
                        )
                    )
                )
        )

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LERZA PLAYER",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            color = activeColor
                        )

                        Text(
                            text = "STEP $currentStep OF $totalSteps",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Animated Progress Bar
                    val animatedProgress by animateFloatAsState(
                        targetValue = currentStep.toFloat() / totalSteps.toFloat(),
                        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
                        label = "ProgressBar"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(colors.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(animatedProgress)
                                .fillMaxHeight()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(activeColor, activeColor.copy(alpha = 0.6f))
                                    )
                                )
                        )
                    }
                }
            },
            bottomBar = {
                Surface(
                    color = colors.surface.copy(alpha = 0.95f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    shadowElevation = 16.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentStep > 1) {
                            OutlinedButton(
                                onClick = { currentStep -= 1 },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = colors.textPrimary
                                ),
                                border = BorderStroke(1.dp, colors.divider)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (currentLang == AppLanguage.URDU) "پیچھے" else if (currentLang == AppLanguage.HINDI) "पीछे" else "Back",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.width(1.dp))
                        }

                        // Next / Launch Player button
                        AnimatedVisibility(
                            visible = showNextButton,
                            enter = fadeIn(tween(200)) + expandHorizontally(),
                            exit = fadeOut(tween(150)) + shrinkHorizontally()
                        ) {
                            Button(
                                onClick = {
                                    if (currentStep < totalSteps) {
                                        currentStep += 1
                                    } else {
                                        scope.launch {
                                            prefManager.setOnboardingV2Completed(true)
                                            prefManager.setUserName(userNameInput.trim())
                                            onComplete()
                                        }
                                    }
                                },
                                enabled = isNextEnabled,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (currentStep == totalSteps) Color(0xFF10B981) else activeColor,
                                    disabledContainerColor = colors.surfaceVariant
                                )
                            ) {
                                Text(
                                    text = if (currentStep == totalSteps) {
                                        if (currentLang == AppLanguage.URDU) "شروع کریں 🚀" else if (currentLang == AppLanguage.HINDI) "शुरू करें 🚀" else "Launch Player 🚀"
                                    } else {
                                        if (currentLang == AppLanguage.URDU) "اگلا" else if (currentLang == AppLanguage.HINDI) "आगे" else "Next"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isNextEnabled) Color.White else colors.textSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (currentStep == totalSteps) Icons.Default.RocketLaunch else Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isNextEnabled) Color.White else colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> -width } + fadeOut()
                        )
                    } else {
                        (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> width } + fadeOut()
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                label = "StepContent"
            ) { targetStep ->
                when (targetStep) {
                    // 🌟 STEP 1: WELCOME
                    1 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            ModernStepHeader(
                                badge = "WELCOME TO THE FUTURE",
                                title = if (currentLang == AppLanguage.URDU) "خوش آمدید لرزا پلیئر میں" else if (currentLang == AppLanguage.HINDI) "लर्ज़ा प्लेयर में आपका स्वागत है" else "Next-Gen Audio Experience",
                                desc = if (currentLang == AppLanguage.URDU) "اعلیٰ ترین آواز، جدید ڈیزائن اور شاندار کنٹرولز کا بے مثال امتزاج۔" else if (currentLang == AppLanguage.HINDI) "सर्वोच्च ध्वनि गुणवत्ता और आधुनिक डिज़ाइन का अनुभव करें।" else "Studio-grade lossless audio playback powered by modern edge technology.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(8.dp, RoundedCornerShape(20.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(activeColor.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.GraphicEq,
                                                contentDescription = null,
                                                tint = activeColor,
                                                modifier = Modifier.size(26.dp)
                                            )
                                        }

                                        Column {
                                            Text(
                                                text = "32-Bit Lossless Engine",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = colors.textPrimary
                                            )
                                            Text(
                                                text = "Low latency audio pipeline with hardware acceleration",
                                                fontSize = 12.sp,
                                                color = colors.textSecondary
                                            )
                                        }
                                    }

                                    HorizontalDivider(color = colors.divider)

                                    HighlightFeatureRow(
                                        icon = Icons.Default.Security,
                                        title = "Private Media Vault",
                                        desc = "AES-256 encrypted hidden folder for private audio & video",
                                        colors = colors
                                    )
                                    HighlightFeatureRow(
                                        icon = Icons.Default.PictureInPicture,
                                        title = "Floating Picture-in-Picture",
                                        desc = "Watch and listen while multitasking across apps",
                                        colors = colors
                                    )
                                    HighlightFeatureRow(
                                        icon = Icons.Default.VolumeUp,
                                        title = "Pro Loudness Booster",
                                        desc = "Boost volume up to 200% safely without distortion",
                                        colors = colors
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = colors.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Translate,
                                        contentDescription = null,
                                        tint = activeColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Language can be changed anytime in the next step or settings.",
                                        fontSize = 12.sp,
                                        color = colors.textSecondary
                                    )
                                }
                            }
                        }
                    }

                    // 🌟 STEP 2: LANGUAGE SELECTION
                    2 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            ModernStepHeader(
                                badge = "STEP 2 OF 8",
                                title = if (currentLang == AppLanguage.URDU) "اپنی پسندیدہ زبان منتخب کریں" else if (currentLang == AppLanguage.HINDI) "अपनी पसंदीदा भाषा चुनें" else "Choose App Language",
                                desc = if (currentLang == AppLanguage.URDU) "مکمل ایپ آپ کی منتخب کردہ زبان میں فوراً ڈھل جائے گی۔" else if (currentLang == AppLanguage.HINDI) "पूरी ऐप आपकी चुनी हुई भाषा में तुरंत बदल जाएगी।" else "Lerza Player is fully localized in English, Urdu, and Hindi.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            ModernLanguageCard(
                                title = "English",
                                nativeTitle = "English (International)",
                                isSelected = currentLang == AppLanguage.ENGLISH,
                                activeColor = activeColor,
                                colors = colors,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.ENGLISH)
                                    }
                                }
                            )

                            ModernLanguageCard(
                                title = "Urdu",
                                nativeTitle = "اردو (Urdu)",
                                isSelected = currentLang == AppLanguage.URDU,
                                activeColor = activeColor,
                                colors = colors,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.URDU)
                                    }
                                }
                            )

                            ModernLanguageCard(
                                title = "Hindi",
                                nativeTitle = "हिन्दी (Hindi)",
                                isSelected = currentLang == AppLanguage.HINDI,
                                activeColor = activeColor,
                                colors = colors,
                                onClick = {
                                    scope.launch {
                                        LanguageManager.setLanguage(context, AppLanguage.HINDI)
                                    }
                                }
                            )
                        }
                    }

                    // 🌟 STEP 3: DISPLAY MODE & ACCENT COLOR
                    3 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            ModernStepHeader(
                                badge = "STEP 3 OF 8",
                                title = if (currentLang == AppLanguage.URDU) "رنگ اور وال پیپر کی تھیم" else if (currentLang == AppLanguage.HINDI) "रंग और वॉलपेपर थीम" else "Visual Style & Wallpaper",
                                desc = if (currentLang == AppLanguage.URDU) "اپنے پلیئر کو اپنے ذوق کے مطابق نفاست سے سجائیں۔" else if (currentLang == AppLanguage.HINDI) "अपने प्लेयर को अपनी पसंद के रंगों और वॉलपेपर से सजाएँ।" else "Pick your accent hue, display mode, or set a custom background wallpaper.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            Text(
                                text = "DISPLAY MODE",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = colors.textSecondary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val isDarkSelected = selectedThemeMode == "Dark"
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isDarkSelected) activeColor.copy(alpha = 0.15f) else colors.surface,
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (isDarkSelected) activeColor else colors.divider
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedThemeMode = "Dark"
                                            ThemeManager.setMode(context, "Dark")
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DarkMode,
                                            contentDescription = null,
                                            tint = if (isDarkSelected) activeColor else colors.textSecondary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Text(
                                            text = "Dark",
                                            fontSize = 12.sp,
                                            fontWeight = if (isDarkSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isDarkSelected) activeColor else colors.textPrimary
                                        )
                                    }
                                }

                                val isLightSelected = selectedThemeMode == "Light"
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isLightSelected) activeColor.copy(alpha = 0.15f) else colors.surface,
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (isLightSelected) activeColor else colors.divider
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedThemeMode = "Light"
                                            ThemeManager.setMode(context, "Light")
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LightMode,
                                            contentDescription = null,
                                            tint = if (isLightSelected) activeColor else colors.textSecondary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Text(
                                            text = "Light",
                                            fontSize = 12.sp,
                                            fontWeight = if (isLightSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isLightSelected) activeColor else colors.textPrimary
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "ACCENT COLOR PALETTE",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = colors.textSecondary
                            )

                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, colors.divider),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    val colorPresets = listOf(
                                        ColorPreset("Electric Purple", Color(0xFF9333EA)),
                                        ColorPreset("Neon Emerald", Color(0xFF10B981)),
                                        ColorPreset("Ocean Blue", Color(0xFF3B82F6)),
                                        ColorPreset("Sunset Amber", Color(0xFFF59E0B)),
                                        ColorPreset("Crimson Red", Color(0xFFEF4444)),
                                        ColorPreset("Cyber Cyan", Color(0xFF06B6D4)),
                                        ColorPreset("Hot Pink", Color(0xFFEC4899)),
                                        ColorPreset("Lime Zing", Color(0xFF84CC16))
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        colorPresets.take(4).forEach { preset ->
                                            ColorPaletteItem(
                                                preset = preset,
                                                isSelected = ThemeManager.currentThemeColor == preset.color,
                                                onClick = {
                                                    scope.launch {
                                                        ThemeManager.setTheme(context, preset.color, preset.name)
                                                    }
                                                }
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        colorPresets.drop(4).forEach { preset ->
                                            ColorPaletteItem(
                                                preset = preset,
                                                isSelected = ThemeManager.currentThemeColor == preset.color,
                                                onClick = {
                                                    scope.launch {
                                                        ThemeManager.setTheme(context, preset.color, preset.name)
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "CUSTOM BACKGROUND WALLPAPER (OPTIONAL)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = colors.textSecondary
                            )

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, colors.divider),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Wallpaper,
                                                contentDescription = null,
                                                tint = activeColor
                                            )
                                            Column {
                                                Text(
                                                    text = if (selectedWallpaperUri != null) "Custom Wallpaper Active" else "No Wallpaper Set",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.5.sp,
                                                    color = colors.textPrimary
                                                )
                                                Text(
                                                    text = "Select any HD photo or artwork from your device",
                                                    fontSize = 11.5.sp,
                                                    color = colors.textSecondary
                                                )
                                            }
                                        }

                                        Button(
                                            onClick = { wallpaperPickerLauncher.launch("image/*") },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Choose", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (selectedWallpaperUri != null) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Dim Overlay: ${(wallpaperOpacity * 100).toInt()}%",
                                                fontSize = 12.sp,
                                                color = colors.textSecondary
                                            )
                                            TextButton(
                                                onClick = {
                                                    selectedWallpaperUri = null
                                                    scope.launch { prefManager.setWallpaperUri(null) }
                                                }
                                            ) {
                                                Text("Remove", color = Color(0xFFEF4444), fontSize = 12.sp)
                                            }
                                        }

                                        Slider(
                                            value = wallpaperOpacity,
                                            onValueChange = { wallpaperOpacity = it },
                                            valueRange = 0.2f..0.95f,
                                            colors = SliderDefaults.colors(
                                                thumbColor = activeColor,
                                                activeTrackColor = activeColor
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 🌟 STEP 4: USER NAME
                    4 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            ModernStepHeader(
                                badge = "STEP 4 OF 8",
                                title = if (currentLang == AppLanguage.URDU) "اپنا نام درج کریں" else if (currentLang == AppLanguage.HINDI) "अपना नाम दर्ज करें" else "What Should We Call You?",
                                desc = if (currentLang == AppLanguage.URDU) "آپ کی ہوم اسکرین اور پلے لسٹس آپ کے نام کے ساتھ خوش آمدید کہیں گی۔" else if (currentLang == AppLanguage.HINDI) "आपकी होम स्क्रीन और प्लेलिस्ट आपके नाम से सजेंगी।" else "Personalize your header greeting and tailored playback sessions.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(90.dp)
                                        .clip(CircleShape)
                                        .background(activeColor.copy(alpha = 0.15f))
                                        .border(2.dp, activeColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (userNameInput.trim().isNotEmpty()) {
                                        Text(
                                            text = userNameInput.trim().first().uppercase(),
                                            fontSize = 38.sp,
                                            fontWeight = FontWeight.Black,
                                            color = activeColor
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = activeColor,
                                            modifier = Modifier.size(44.dp)
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = userNameInput,
                                onValueChange = { if (it.length <= 25) userNameInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = {
                                    Text(
                                        text = "e.g., Alex or Music Lover",
                                        color = colors.textSecondary.copy(alpha = 0.6f)
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Badge,
                                        contentDescription = null,
                                        tint = activeColor
                                    )
                                },
                                trailingIcon = {
                                    if (userNameInput.isNotEmpty()) {
                                        IconButton(onClick = { userNameInput = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = activeColor,
                                    unfocusedBorderColor = colors.divider,
                                    focusedContainerColor = colors.surfaceVariant,
                                    unfocusedContainerColor = colors.surface
                                )
                            )

                            Text(
                                text = "You can change or remove this at any time in Settings.",
                                fontSize = 12.sp,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // 🌟 STEP 5: VAULT PIN
                    5 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            ModernStepHeader(
                                badge = "STEP 5 OF 8 • MANDATORY SETUP",
                                title = if (isConfirmStep) "Confirm Your 4-Digit PIN" else "Set Private Vault PIN",
                                desc = if (isConfirmStep) "Re-enter the exact 4 digits to verify and protect your private media safe." else "Choose a 4-digit numeric code to protect your private audio and video files.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            if (pinErrorMessage != null) {
                                Surface(
                                    color = Color(0xFFEF4444).copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = pinErrorMessage!!,
                                        color = Color(0xFFEF4444),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            if (isVaultPinConfigured) {
                                Surface(
                                    color = Color(0xFF10B981).copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, Color(0xFF10B981)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "Vault PIN Secured & Stored!",
                                            color = Color(0xFF10B981),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier.padding(vertical = 12.dp)
                            ) {
                                for (i in 0 until 4) {
                                    val isFilled = i < enteredPin.length
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isFilled) activeColor else colors.surfaceVariant
                                            )
                                            .border(
                                                2.dp,
                                                if (isFilled) activeColor else colors.divider,
                                                CircleShape
                                            )
                                    )
                                }
                            }

                            if (!isVaultPinConfigured) {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val keypadRows = listOf(
                                        listOf("1", "2", "3"),
                                        listOf("4", "5", "6"),
                                        listOf("7", "8", "9"),
                                        listOf("C", "0", "⌫")
                                    )

                                    keypadRows.forEach { row ->
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(18.dp),
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            row.forEach { key ->
                                                Surface(
                                                    shape = RoundedCornerShape(16.dp),
                                                    color = if (key == "C" || key == "⌫") colors.surfaceVariant else colors.surface,
                                                    border = BorderStroke(1.dp, colors.divider),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(58.dp)
                                                        .clickable {
                                                            when (key) {
                                                                "C" -> enteredPin = ""
                                                                "⌫" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                                                else -> if (enteredPin.length < 4) enteredPin += key
                                                            }
                                                        }
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = key,
                                                            fontSize = 20.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (key == "C") Color(0xFFEF4444) else colors.textPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 🌟 STEP 6: NOTIFICATION PREVIEW & PERMISSION
                    6 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            ModernStepHeader(
                                badge = "STEP 6 OF 8 • BACKGROUND AUDIO",
                                title = if (currentLang == AppLanguage.URDU) "نوٹیفکیشن اور بیک گراؤنڈ پلیئر" else if (currentLang == AppLanguage.HINDI) "बैकग्राउंड मीडिया व नोटिफिकेशन" else "Lockscreen & Notification Player",
                                desc = if (currentLang == AppLanguage.URDU) "اسکرین لاک ہونے پر بھی بغیر کسی رکاوٹ کے گانے اور آڈیو کنٹرول کریں۔" else if (currentLang == AppLanguage.HINDI) "स्क्रीन लॉक होने पर भी गाने सहजता से नियंत्रित करें।" else "Enjoy seamless lockscreen playback and status bar audio controls.",
                                colors = colors,
                                activeColor = activeColor
                            )

                            if (!previewNotificationDismissed) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color(0xFF1E1E2C),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .shadow(12.dp, RoundedCornerShape(20.dp))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.MusicNote,
                                                    contentDescription = null,
                                                    tint = activeColor,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Text(
                                                    text = "Lerza Player • Now Playing",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White.copy(alpha = 0.7f)
                                                )
                                            }

                                            IconButton(
                                                onClick = { previewNotificationDismissed = true },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Dismiss Preview",
                                                    tint = Color.White.copy(alpha = 0.6f),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(52.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(
                                                        Brush.linearGradient(
                                                            listOf(activeColor, activeColor.copy(alpha = 0.5f))
                                                        )
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.GraphicEq,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(26.dp)
                                                )
                                            }

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Midnight Horizon (Lossless)",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Text(
                                                    text = "Lerza Audio Lab • 96kHz / 24-bit",
                                                    fontSize = 11.5.sp,
                                                    color = Color.White.copy(alpha = 0.6f)
                                                )
                                            }

                                            IconButton(
                                                onClick = { previewIsFavorite = !previewIsFavorite }
                                            ) {
                                                Icon(
                                                    imageVector = if (previewIsFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                    contentDescription = "Favorite",
                                                    tint = if (previewIsFavorite) Color(0xFFEF4444) else Color.White.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(Color.White.copy(alpha = 0.15f))
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(0.42f)
                                                    .fillMaxHeight()
                                                    .background(activeColor)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceEvenly,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(onClick = {}) {
                                                Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = Color.White)
                                            }
                                            IconButton(
                                                onClick = { previewIsPlaying = !previewIsPlaying },
                                                modifier = Modifier
                                                    .size(42.dp)
                                                    .clip(CircleShape)
                                                    .background(activeColor)
                                            ) {
                                                Icon(
                                                    imageVector = if (previewIsPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = Color.White
                                                )
                                            }
                                            IconButton(onClick = {}) {
                                                Icon(Icons.Default.SkipNext, contentDescription = null, tint = Color.White)
                                            }
                                        }
                                    }
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { previewNotificationDismissed = false },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Restore Live Notification Preview")
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isNotificationAllowed) Color(0xFF10B981).copy(alpha = 0.15f) else colors.surfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (isNotificationAllowed) Color(0xFF10B981) else colors.divider
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isNotificationAllowed) Icons.Default.CheckCircle else Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = if (isNotificationAllowed) Color(0xFF10B981) else activeColor
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isNotificationAllowed) "Notification Permission Granted" else "Notification Permission Required",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = colors.textPrimary
                                            )
                                            Text(
                                                text = "Required on Android 13+ to control music from status bar & lockscreen",
                                                fontSize = 11.5.sp,
                                                color = colors.textSecondary
                                            )
                                        }
                                    }

                                    if (!isNotificationAllowed) {
                                        Button(
                                            onClick = {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = activeColor)
                                        ) {
                                            Text("Grant Notification Permission", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 🌟 STEP 7: STORAGE & PERMISSIONS
                    7 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Column {
                                Text(
                                    text = if (currentLang == AppLanguage.URDU) "اسٹوریج اور اجازتیں" else if (currentLang == AppLanguage.HINDI) "स्टोरेज और अनुमतियाँ" else "Storage & Permissions",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = if (currentLang == AppLanguage.URDU) "مقامی آڈیو اور ویڈیو فائلز چلانے کے لیے تمام اجازتیں الاؤ کریں۔" else if (currentLang == AppLanguage.HINDI) "स्थानीय ऑडियो और वीडियो फ़ाइलें चलाने के लिए सभी अनुमतियाँ दें।" else "Grant permissions to discover and play your local audio & video library.",
                                    fontSize = 11.5.sp,
                                    color = colors.textSecondary
                                )
                            }

                            ModernPermissionCard(
                                title = "Music & Audio Files",
                                desc = "Scan and play MP3, FLAC, WAV, and M4A lossless tracks.",
                                icon = Icons.Default.MusicNote,
                                isGranted = isAudioAllowed,
                                activeColor = Color(0xFF10B981),
                                colors = colors,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }
                            )

                            ModernPermissionCard(
                                title = "Video Library Access",
                                desc = "Enable background video audio and Picture-in-Picture playback.",
                                icon = Icons.Default.VideoLibrary,
                                isGranted = isVideoAllowed,
                                activeColor = Color(0xFF3B82F6),
                                colors = colors,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_MEDIA_VIDEO)
                                    } else {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }
                            )

                            ModernPermissionCard(
                                title = "Album Artwork & Wallpapers",
                                desc = "Display HD cover artwork and custom UI player themes.",
                                icon = Icons.Default.Image,
                                isGranted = isPhotosAllowed,
                                activeColor = Color(0xFF8B5CF6),
                                colors = colors,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        photosPermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES)
                                    } else {
                                        photosPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }
                            )

                            ModernPermissionCard(
                                title = "All Files Storage Access",
                                desc = "Browse SD card folders and manage private safe vault files.",
                                icon = Icons.Default.Folder,
                                isGranted = isAllFilesAllowed,
                                activeColor = Color(0xFFF59E0B),
                                colors = colors,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                            data = Uri.parse("package:${context.packageName}")
                                        }
                                        allFilesPermissionLauncher.launch(intent)
                                    } else {
                                        isAllFilesAllowed = true
                                    }
                                }
                            )
                        }
                    }

                    // 🌟 STEP 8: LAUNCH READY
                    8 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(CircleShape)
                                    .background(emeraldGradient)
                                    .shadow(12.dp, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(48.dp)
                                )
                            }

                            Text(
                                text = if (currentLang == AppLanguage.URDU) "سب کچھ تیار ہے! 🎉" else if (currentLang == AppLanguage.HINDI) "सब कुछ तैयार है! 🎉" else "You're All Set! 🎉",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = colors.textPrimary,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = if (currentLang == AppLanguage.URDU) "آپ کا لرزا پلیئر مکمل طور پر ترتیب پا چکا ہے۔ اعلیٰ کوالٹی موسیقی کا لطف اٹھائیں۔" else if (currentLang == AppLanguage.HINDI) "आपका लर्ज़ा प्लेयर पूरी तरह तैयार है। बेहतरीन संगीत का आनंद लें।" else "All permissions configured. Your ultra-responsive studio player is ready.",
                                fontSize = 13.5.sp,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center
                            )

                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, colors.divider),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ReviewSummaryRow("Language", currentLang.name)
                                    ReviewSummaryRow("Display Mode", selectedThemeMode)
                                    ReviewSummaryRow("Vault PIN", if (isVaultPinConfigured) "Configured (Encrypted)" else "Default")
                                    ReviewSummaryRow("Storage Access", "100% Granted")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// HELPER COMPONENTS
// ============================================================

@Composable
fun ModernStepHeader(
    badge: String,
    title: String,
    desc: String,
    colors: LerzaColorPalette,
    activeColor: Color
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = activeColor.copy(alpha = 0.15f)
        ) {
            Text(
                text = badge,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = activeColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }

        Text(
            text = title,
            fontSize = 21.sp,
            fontWeight = FontWeight.ExtraBold,
            color = colors.textPrimary
        )

        Text(
            text = desc,
            fontSize = 12.5.sp,
            color = colors.textSecondary,
            lineHeight = 17.sp
        )
    }
}

@Composable
fun ModernLanguageCard(
    title: String,
    nativeTitle: String,
    isSelected: Boolean,
    activeColor: Color,
    colors: LerzaColorPalette,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) activeColor.copy(alpha = 0.12f) else colors.surface,
        border = BorderStroke(
            1.5.dp,
            if (isSelected) activeColor else colors.divider
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) activeColor else colors.textPrimary
                )
                Text(
                    text = nativeTitle,
                    fontSize = 12.5.sp,
                    color = colors.textSecondary
                )
            }

            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = activeColor)
            )
        }
    }
}

@Composable
fun ModernPermissionCard(
    title: String,
    desc: String,
    icon: ImageVector,
    isGranted: Boolean,
    activeColor: Color,
    colors: LerzaColorPalette,
    onAllow: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = colors.surface,
        border = BorderStroke(
            1.dp,
            if (isGranted) activeColor.copy(alpha = 0.5f) else colors.divider
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isGranted) activeColor.copy(alpha = 0.18f) else colors.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isGranted) activeColor else colors.textSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = desc,
                    fontSize = 9.5.sp,
                    color = colors.textSecondary,
                    lineHeight = 12.sp,
                    maxLines = 1
                )
            }

            if (isGranted) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = activeColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Granted",
                        color = activeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            } else {
                Button(
                    onClick = onAllow,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Allow", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun HighlightFeatureRow(
    icon: ImageVector,
    title: String,
    desc: String,
    colors: LerzaColorPalette
) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp)
        )
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Text(
                text = desc,
                fontSize = 11.5.sp,
                color = colors.textSecondary
            )
        }
    }
}

data class ColorPreset(val name: String, val color: Color)

@Composable
fun ColorPaletteItem(
    preset: ColorPreset,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(preset.color)
            .clickable(onClick = onClick)
            .then(
                if (isSelected) {
                    Modifier.border(3.dp, Color.White, CircleShape)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun ReviewSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF10B981),
                modifier = Modifier.size(16.dp)
            )
            Text(text = label, fontSize = 12.5.sp, color = Color.Gray)
        }
        Text(text = value, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
    }
}
