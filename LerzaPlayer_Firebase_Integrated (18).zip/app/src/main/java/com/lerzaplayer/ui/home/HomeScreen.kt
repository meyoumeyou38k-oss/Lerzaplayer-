package com.lerzaplayer.ui.home

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.model.ViewMode
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.ads.AdManager
import com.lerzaplayer.ads.DynamicBannerAdView
import com.lerzaplayer.config.RemoteConfigManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import com.lerzaplayer.ui.common.AddToPlaylistDialog
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.common.WallpaperBackground
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()

    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = ViewMode.GRID)
    val songDensity by prefManager.songItemDensityFlow.collectAsState(initial = 1.15f)

    // Firebase Remote Config Cloud Parameters
    val announcementText by RemoteConfigManager.announcementBannerText.collectAsState()
    val announcementLink by RemoteConfigManager.announcementBannerLink.collectAsState()
    val isBottomBannerEnabled by RemoteConfigManager.enableBottomBannerAd.collectAsState()
    val showAllAds by RemoteConfigManager.showAllAds.collectAsState()
    val removeAllAds by RemoteConfigManager.removeAllAds.collectAsState()
    val maintenanceMode by RemoteConfigManager.maintenanceMode.collectAsState()
    var isAnnouncementDismissed by remember { mutableStateOf(false) }

    // 🌟 Reset dismissal whenever a new or updated announcement is broadcasted from Web Admin
    LaunchedEffect(announcementText) {
        if (announcementText.isNotBlank()) {
            isAnnouncementDismissed = false
        }
    }

    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })
    var headerVisible by remember { mutableStateOf(true) }

    // لارک پلیئر سوائپ ٹو ری لوڈ
    var isReloading by remember { mutableStateOf(false) }
    var pullOffsetY by remember { mutableFloatStateOf(0f) }

    fun triggerReload() {
        if (!isReloading) {
            isReloading = true
            onScanDevice()
            // Pull-to-refresh exclusively rescans device media without unnecessary Firebase network traffic
            scope.launch {
                delay(1200)
                isReloading = false
                pullOffsetY = 0f
            }
        }
    }

    // 🌟 Butter-smooth 120 FPS nested scroll connection:
    // Header remains solidly visible with zero layout jumps, ensuring stable list height during flings
    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                // Only activate pull-to-refresh when user is at the top (consumed.y == 0) and dragging downward
                if (consumed.y == 0f && available.y > 0 && source == NestedScrollSource.Drag) {
                    pullOffsetY = (pullOffsetY + available.y * 0.22f).coerceAtMost(200f)
                    if (pullOffsetY >= 150f && !isReloading) {
                        triggerReload()
                    }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                if (!isReloading) {
                    pullOffsetY = 0f
                }
                return androidx.compose.ui.unit.Velocity.Zero
            }
        }
    }

    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongIds = remember { mutableStateListOf<Long>() }
    var songsForPlaylistDialog by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    BackHandler(enabled = isMultiSelectMode) {
        isMultiSelectMode = false
        selectedSongIds.clear()
    }

    BackHandler(enabled = !isMultiSelectMode && pagerState.currentPage != 1) {
        scope.launch { pagerState.animateScrollToPage(1) }
    }

    fun toggleSongSelection(id: Long) {
        if (selectedSongIds.contains(id)) {
            selectedSongIds.remove(id)
            if (selectedSongIds.isEmpty()) isMultiSelectMode = false
        } else {
            selectedSongIds.add(id)
        }
    }

    WallpaperBackground(
        wallpaperUri = wallpaperUri,
        opacity = wallpaperOpacity
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AutoHidingHeader(
                    visible = headerVisible,
                    onSearchClick = onSearchClick,
                    onSettingsClick = onSettingsClick
                )

                TabsRow(
                    selectedTab = pagerState.currentPage,
                    onTabSelected = { index ->
                        scope.launch { pagerState.animateScrollToPage(index) }
                    }
                )

                // 🌟 Firebase Remote Config Maintenance Mode Banner
                AnimatedVisibility(visible = maintenanceMode) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE11D48).copy(alpha = 0.9f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Notice: Server maintenance underway. Offline playback functions smoothly.",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // 🌟 Firebase Remote Config Announcement Banner (Dynamic Text & Clickable URL)
                AnimatedVisibility(visible = announcementText.isNotBlank() && !isAnnouncementDismissed) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clickable(enabled = announcementLink.isNotBlank()) {
                                try {
                                    val targetUrl = announcementLink.trim()
                                    val webUrl = if (targetUrl.startsWith("http://", ignoreCase = true) || targetUrl.startsWith("https://", ignoreCase = true)) {
                                        targetUrl
                                    } else {
                                        "https://$targetUrl"
                                    }
                                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(browserIntent)
                                } catch (e: Exception) {
                                    android.util.Log.e("HomeScreen", "Error opening announcement link: ${e.message}")
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF7C3AED).copy(alpha = 0.92f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = announcementText,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(
                                onClick = { isAnnouncementDismissed = true },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f)
                ) { page ->
                    when (page) {
                        0 -> {
                            VideoListScreen(
                                videos = videos,
                                viewMode = videoViewMode,
                                onVideoClick = onPlayVideo,
                                onViewModeToggle = {
                                    scope.launch {
                                        val nextMode = if (videoViewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
                                        prefManager.setVideoViewMode(nextMode)
                                    }
                                },
                                onScanDevice = ::triggerReload,
                                onToggleFavorite = onToggleFavoriteVideo,
                                onHideInVault = onHideVideoInVault,
                                onDelete = onDeleteVideo
                            )
                        }
                        1 -> {
                            SongListScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                currentSort = songSort,
                                selectedSongIds = selectedSongIds.toSet(),
                                isMultiSelectMode = isMultiSelectMode,
                                densityScale = songDensity,
                                onSongClick = { song, index ->
                                    val act = context as? Activity
                                    AdManager.onSongActionClicked(act) {
                                        playerManager.playSongList(songs, index)
                                        onExpandFullPlayer()
                                    }
                                },
                                onToggleSelect = ::toggleSongSelection,
                                onStartMultiSelect = { id ->
                                    isMultiSelectMode = true
                                    if (!selectedSongIds.contains(id)) selectedSongIds.add(id)
                                },
                                onSortChanged = { option ->
                                    scope.launch { prefManager.setSongSort(option) }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onPlayNext = { playerManager.playNext(it) },
                                onAddToQueue = { playerManager.addToQueue(it) },
                                onAddToPlaylist = { song -> songsForPlaylistDialog = listOf(song) },
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        2 -> {
                            PlaylistsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    val act = context as? Activity
                                    AdManager.onSongActionClicked(act) {
                                        playerManager.playSongList(list, index)
                                        onExpandFullPlayer()
                                    }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        3 -> {
                            FoldersScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    val act = context as? Activity
                                    AdManager.onSongActionClicked(act) {
                                        playerManager.playSongList(list, index)
                                        onExpandFullPlayer()
                                    }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        4 -> {
                            AlbumsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    val act = context as? Activity
                                    AdManager.onSongActionClicked(act) {
                                        playerManager.playSongList(list, index)
                                        onExpandFullPlayer()
                                    }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        else -> {
                            ArtistsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    val act = context as? Activity
                                    AdManager.onSongActionClicked(act) {
                                        playerManager.playSongList(list, index)
                                        onExpandFullPlayer()
                                    }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                    }
                }
            }

            // لارک پلیئر ری لوڈ بیج
            AnimatedVisibility(
                visible = isReloading || pullOffsetY > 25f,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 110.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 8.dp,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        val infiniteTransition = rememberInfiniteTransition(label = "larkReloadSpin")
                        val rotationAngle by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(700, easing = LinearEasing),
                                repeatMode = RepeatMode.Restart
                            ),
                            label = "spin"
                        )

                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reloading",
                            tint = colors.primary,
                            modifier = Modifier
                                .size(24.dp)
                                .graphicsLayer {
                                    rotationZ = if (isReloading) rotationAngle else pullOffsetY * 2f
                                }
                        )
                    }
                }
            }

            // 🌟 Docked Bottom Area: MiniPlayer and Dynamic Google AdMob Banner Ad safely above navigation bar
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // بغیر بیزل کے منی پلیئر
                if (currentSong != null && !isMultiSelectMode) {
                    MiniPlayer(
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        onExpand = onExpandFullPlayer,
                        onPlayPause = { playerManager.playPause() },
                        onNext = { playerManager.playNextTrack() },
                        onOpenQueue = onExpandFullPlayer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                // 🌟 Dynamic Google AdMob Banner Ad (Reactively controlled via Firebase Remote Config & Firestore)
                if (!isMultiSelectMode && showAllAds && !removeAllAds && isBottomBannerEnabled) {
                    DynamicBannerAdView(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp, bottom = 2.dp)
                    )
                }
            }

            // 🌟 گانوں کو پلے لسٹ میں شامل کرنے کا ڈائیلاگ
            if (songsForPlaylistDialog.isNotEmpty()) {
                AddToPlaylistDialog(
                    songs = songsForPlaylistDialog,
                    onDismiss = {
                        songsForPlaylistDialog = emptyList()
                        if (isMultiSelectMode) {
                            selectedSongIds.clear()
                            isMultiSelectMode = false
                        }
                    }
                )
            }

            MultiSelectActionBar(
                visible = isMultiSelectMode,
                selectedCount = selectedSongIds.size,
                onClearSelection = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onSelectAll = {
                    selectedSongIds.clear()
                    selectedSongIds.addAll(songs.map { it.id })
                },
                onAddToPlaylistSelected = {
                    val selected = songs.filter { selectedSongIds.contains(it.id) }
                    if (selected.isNotEmpty()) {
                        songsForPlaylistDialog = selected
                    }
                },
                onAddToQueueSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach { playerManager.addToQueue(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onPlayNextSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .asReversed()
                        .forEach { playerManager.playNext(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onShareSelected = {
                    val selectedSongs = songs.filter { selectedSongIds.contains(it.id) }
                    if (selectedSongs.isNotEmpty()) {
                        val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "audio/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(selectedSongs.map { it.contentUri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share songs"))
                    }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onHideSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach(onHideSongInVault)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onDeleteSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach(onDeleteSong)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}