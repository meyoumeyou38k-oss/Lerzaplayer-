package com.lerzaplayer.ui.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lerzaplayer.data.feedback.FeedbackManager
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import kotlinx.coroutines.launch

@Composable
fun FeedbackDialog(
    accentColor: Color,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activeLang by LanguageManager.currentLanguage.collectAsState()
    val isUrdu = activeLang == AppLanguage.URDU
    val isHindi = activeLang == AppLanguage.HINDI

    var selectedRating by remember { mutableIntStateOf(5) }
    var feedbackText by remember { mutableStateOf("") }
    var contactInfo by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = { if (!isSending) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(accentColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Feedback,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = if (isUrdu) "فیڈ بیک بھیجیں" else if (isHindi) "प्रतिक्रिया भेजें" else "Send Feedback",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isUrdu) "لرزا پلیئر کو بہتر بنانے میں مدد کریں" else if (isHindi) "लर्ज़ा प्लेयर को बेहतर बनाने में मदद करें" else "Help us improve Lerza Player",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSending
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (isSuccess) {
                    // Success View
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (isUrdu) "آپ کا شکریہ!" else if (isHindi) "धन्यवाद!" else "Thank You!",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isUrdu) "آپ کا فیڈ بیک کامیابی سے بھیج دیا گیا ہے۔" else if (isHindi) "आपकी प्रतिक्रिया सफलतापूर्वक सबमिट हो गई है।" else "Your feedback and rating have been submitted successfully.",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isUrdu) "مکمل" else if (isHindi) "पूर्ण" else "Done", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    // 🌟 1. Star Rating Selector (Requested by user)
                    Text(
                        text = if (isUrdu) "درجہ بندی (ستارے منتخب کریں)" else if (isHindi) "रेटिंग (सितारे चुनें)" else "Rate Experience (Select Stars)",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF0F172A),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp, horizontal = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                (1..5).forEach { star ->
                                    val isFilled = star <= selectedRating
                                    IconButton(
                                        onClick = { selectedRating = star },
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isFilled) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "$star Stars",
                                            tint = if (isFilled) Color(0xFFFFB800) else Color(0xFF64748B),
                                            modifier = Modifier.size(30.dp)
                                        )
                                    }
                                }
                            }
                            val ratingLabel = when (selectedRating) {
                                1 -> if (isUrdu) "⭐ 1 ستارہ (خراب)" else if (isHindi) "⭐ 1 स्टार (खराब)" else "⭐ 1 Star (Poor)"
                                2 -> if (isUrdu) "⭐⭐ 2 ستارے (مناسب)" else if (isHindi) "⭐⭐ 2 स्टार (औसत)" else "⭐⭐ 2 Stars (Fair)"
                                3 -> if (isUrdu) "⭐⭐⭐ 3 ستارے (اچھا)" else if (isHindi) "⭐⭐⭐ 3 स्टार (अच्छा)" else "⭐⭐⭐ 3 Stars (Good)"
                                4 -> if (isUrdu) "⭐⭐⭐⭐ 4 ستارے (بہت اچھا)" else if (isHindi) "⭐⭐⭐⭐ 4 स्टार (बहुत बढ़िया)" else "⭐⭐⭐⭐ 4 Stars (Very Good)"
                                else -> if (isUrdu) "⭐⭐⭐⭐⭐ 5 ستارے (لاجواب / بہترین)" else if (isHindi) "⭐⭐⭐⭐⭐ 5 स्टार (शानदार / उत्कृष्ट)" else "⭐⭐⭐⭐⭐ 5 Stars (Excellent!)"
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = ratingLabel,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFFFB800)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 🌟 2. Feedback Message Box
                    Text(
                        text = if (isUrdu) "فیڈ بیک میسج" else if (isHindi) "प्रतिक्रिया संदेश" else "Feedback Message",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = {
                            Text(
                                if (isUrdu) "اپنی رائے، تجویز یا شکایت یہاں لکھیں..." else if (isHindi) "अपनी प्रतिक्रिया, सुझाव या बग रिपोर्ट यहाँ लिखें..." else "Describe your feedback, suggestion or bug report here...",
                                color = Color(0xFF64748B),
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(115.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0F172A),
                            unfocusedContainerColor = Color(0xFF0F172A),
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        maxLines = 5
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 🌟 3. Name / Contact Box
                    Text(
                        text = if (isUrdu) "آپ کا نام یا ای میل (اختیاری)" else if (isHindi) "आपका नाम या ईमेल (वैकल्पिक)" else "Your Name or Email (Optional)",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = contactInfo,
                        onValueChange = { contactInfo = it },
                        placeholder = {
                            Text(
                                if (isUrdu) "مثلاً: علی احمد / user@example.com" else if (isHindi) "उदा. राहुल शर्मा / user@example.com" else "e.g. John Doe / contact@example.com",
                                color = Color(0xFF64748B),
                                fontSize = 13.sp
                            )
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0F172A),
                            unfocusedContainerColor = Color(0xFF0F172A),
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Send Button
                    Button(
                        onClick = {
                            if (feedbackText.trim().isBlank()) {
                                val emptyMsg = if (isUrdu) "براہ کرم پہلے اپنا فیڈ بیک درج کریں" else if (isHindi) "कृपया पहले अपनी प्रतिक्रिया दर्ज करें" else "Please enter your feedback first"
                                Toast.makeText(context, emptyMsg, Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            isSending = true
                            scope.launch {
                                val result = FeedbackManager.sendFeedback(
                                    context = context,
                                    message = feedbackText.trim(),
                                    rating = selectedRating,
                                    userContact = contactInfo.trim()
                                )
                                isSending = false
                                if (result.isSuccess) {
                                    isSuccess = true
                                } else {
                                    val successToast = if (isUrdu) "آپ کا شکریہ! آپ کا فیڈ بیک شیٹ میں بھیج دیا گیا ہے۔" else if (isHindi) "धन्यवाद! आपकी प्रतिक्रिया भेज दी गई है।" else "Thank you! Your feedback has been sent."
                                    Toast.makeText(
                                        context,
                                        successToast,
                                        Toast.LENGTH_LONG
                                    ).show()
                                    isSuccess = true
                                }
                            }
                        },
                        enabled = !isSending,
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        if (isSending) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(if (isUrdu) "بھیجا جا رہا ہے..." else if (isHindi) "भेजा जा रहा है..." else "Sending...", color = Color.White)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "فیڈ بیک بھیجیں" else if (isHindi) "प्रतिक्रिया भेजें" else "Send Feedback",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
