package com.lerzaplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.playback.NotificationHelper
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.player.EqualizerSheet
import com.lerzaplayer.update.AppUpdateManager
import kotlinx.coroutines.launch
import java.io.File

data class AboutFeatureItem(
    val icon: ImageVector,
    val title: String,
    val description: String,
    val tag: String = "Pro"
)

val LERZA_FEATURES = listOf(
    AboutFeatureItem(
        Icons.Default.Tune,
        "10-Band Pro Equalizer & Bass",
        "Fine-tune 10 discrete frequency bands • Perfect bass control for audiophiles",
        "Audio"
    ),
    AboutFeatureItem(
        Icons.Default.VolumeUp,
        "300% Volume Boost (5X Gain)",
        "Ultra-high hardware amplification • Real-time loudness processing, zero clipping distortion",
        "Boost"
    ),
    AboutFeatureItem(
        Icons.Default.PictureInPicture,
        "Floating Window (PiP) Player",
        "Multi-task smoothly • Floating player with Play, Pause, Next controls",
        "PiP"
    ),
    AboutFeatureItem(
        Icons.Default.Headphones,
        "Seamless Video-to-Audio Mode",
        "Switch any video to background audio • Continue playback while multitasking",
        "Background"
    ),
    AboutFeatureItem(
        Icons.Default.Lock,
        "Secure Private Vault",
        "Hide and encrypt files • PIN and biometric protected safe vault",
        "Vault"
    ),
    AboutFeatureItem(
        Icons.Default.SurroundSound,
        "Sound Quality & 3D Spatial Virtualizer",
        "24-Bit/192kHz Hi-Res • 3D spatial surround sound virtualizer",
        "3D Hi-Res"
    ),
    AboutFeatureItem(
        Icons.Default.Language,
        "Multi-Language System",
        "English • Urdu (اردو) • Hindi (हिन्दी) • Intuitive local experience",
        "Locale"
    ),
    AboutFeatureItem(
        Icons.Default.AccessTime,
        "Live Playtime & Sleep Timer",
        "Live playtime tracking • Smart bedtime auto-stop timer",
        "Timer"
    )
)

val URDU_LERZA_FEATURES = listOf(
    AboutFeatureItem(
        Icons.Default.Tune,
        "10-بینڈ پرو ایکویلائزر اور باس",
        "10 فریکوئنسی بینڈز کنٹرول کریں • آڈیو کے لیے بہترین باس بوسٹ",
        "آڈیو"
    ),
    AboutFeatureItem(
        Icons.Default.VolumeUp,
        "300% والیوم بوسٹ (5 گنا طاقتور)",
        "انتہائی طاقتور ہارڈ ویئر ایمپلیفیکیشن • بنا کسی خرابی کے صاف اور بلند آواز",
        "بوسٹ"
    ),
    AboutFeatureItem(
        Icons.Default.PictureInPicture,
        "فلوٹنگ ونڈو (PiP) پلیئر",
        "دیگر ایپس استعمال کرتے ہوئے چھوٹی اسکرین پر ویڈیو چلائیں",
        "پی آئی پی"
    ),
    AboutFeatureItem(
        Icons.Default.Headphones,
        "ویڈیو سے پس منظر آڈیو موڈ",
        "کسی بھی ویڈیو کو پس منظر میں بطور آڈیو چلائیں اور ملٹی ٹاسکنگ کریں",
        "پس منظر"
    ),
    AboutFeatureItem(
        Icons.Default.Lock,
        "محفوظ نجی والٹ (خفیہ فائلیں)",
        "فائلیں چھپائیں اور خفیہ رکھیں • پن کوڈ اور بائیو میٹرک سیکیورٹی کے ساتھ",
        "والٹ"
    ),
    AboutFeatureItem(
        Icons.Default.SurroundSound,
        "صوتی معیار اور 3D اسپیشل ورچوئلائزر",
        "24-بٹ / 192kHz ہائی ریزولوشن • 3D اسپیشل سراؤنڈ ورچوئلائزر",
        "تھری ڈی"
    ),
    AboutFeatureItem(
        Icons.Default.Language,
        "کثیر لسانی نظام",
        "انگریزی • اردو (اردو) • ہندی (हिन्दी) • مکمل مقامی اور آسان تجربہ",
        "زبان"
    ),
    AboutFeatureItem(
        Icons.Default.AccessTime,
        "لائیو پلے ٹائم اور سلیپ ٹائمر",
        "روزانہ سننے کا وقت ٹریک کریں • سونے کے وقت خودکار بند ہونے والا ٹائمر",
        "ٹائمر"
    )
)

val HINDI_LERZA_FEATURES = listOf(
    AboutFeatureItem(
        Icons.Default.Tune,
        "10-बैंड प्रो इक्वलाइज़र और बास",
        "10 फ़्रीक्वेंसी बैंड नियंत्रित करें • बेहतरीन बास बूस्ट और स्पष्टता",
        "ऑडियो"
    ),
    AboutFeatureItem(
        Icons.Default.VolumeUp,
        "300% वॉल्यूम बूस्ट (5 गुना शक्तिशाली)",
        "शक्तिशाली हार्डवेयर प्रवर्धन • बिना विकृति के स्पष्ट और तेज़ आवाज़",
        "बूस्ट"
    ),
    AboutFeatureItem(
        Icons.Default.PictureInPicture,
        "फ्लोटिंग विंडो (PiP) प्लेयर",
        "अन्य ऐप्स का उपयोग करते हुए छोटी स्क्रीन पर वीडियो देखें",
        "पीआईपी"
    ),
    AboutFeatureItem(
        Icons.Default.Headphones,
        "वीडियो बैकग्राउंड ऑडियो मोड",
        "किसी भी वीडियो को बैकग्राउंड में ऑडियो की तरह चलाएं",
        "बैकग्राउंड"
    ),
    AboutFeatureItem(
        Icons.Default.Lock,
        "सुरक्षित निजी वॉल्ट (निजी फ़ाइलें)",
        "फ़ाइलें छिपाएं और सुरक्षित रखें • पिन कोड और बायोमेट्रिक सुरक्षा",
        "वॉल्ट"
    ),
    AboutFeatureItem(
        Icons.Default.SurroundSound,
        "ध्वनि गुणवत्ता और 3D स्थानिक वर्चुअलाइज़र",
        "24-बिट / 192kHz स्टूडियो मास्टर • 3D सराउंड वर्चुअलाइज़र",
        "3D"
    ),
    AboutFeatureItem(
        Icons.Default.Language,
        "बहुभाषी प्रणाली",
        "अंग्रेजी • उर्दू (اردو) • हिन्दी (हिन्दी) • सहज अनुभव",
        "भाषा"
    ),
    AboutFeatureItem(
        Icons.Default.AccessTime,
        "लाइव प्ले टाइम और स्लीप टाइमर",
        "दैनिक सुनने का समय ट्रैक करें • स्मार्ट ऑटो-स्टॉप टाइमर",
        "टाइमर"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit = {},
    onScanMedia: () -> Unit = {},
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onOpenOnboarding: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor

    val sleepMinutes by (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager?.sleepTimerRemainingMinutes?.collectAsState() ?: remember { mutableIntStateOf(0) }
    val playerManager = (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager ?: remember { PlayerManager.getInstance(context) }

    LaunchedEffect(Unit) {
        PlaytimeTracker.init(context)
    }
    val musicPlaytimeMs by PlaytimeTracker.musicPlaytimeMs.collectAsState()
    val videoPlaytimeMs by PlaytimeTracker.videoPlaytimeMs.collectAsState()
    val livePlaytime = remember(musicPlaytimeMs, videoPlaytimeMs) {
        PlaytimeTracker.formatLarkTime(musicPlaytimeMs + videoPlaytimeMs)
    }

    val currentLangCode by prefManager.appLanguageFlow.collectAsState(initial = "en")
    val activeLang = remember(currentLangCode) { AppLanguage.fromCode(currentLangCode) }
    val appStrings = remember(activeLang) { LanguageManager.getStringsFor(activeLang) }
    val isUrdu = activeLang == AppLanguage.URDU
    val isHindi = activeLang == AppLanguage.HINDI

    var currentSubScreen by remember { mutableStateOf<String?>(null) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }

    val isEqFeatureEnabled by com.lerzaplayer.config.RemoteConfigManager.enableEqualizer.collectAsState()
    val isSleepTimerFeatureEnabled by com.lerzaplayer.config.RemoteConfigManager.enableSleepTimer.collectAsState()
    val isFeedbackFeatureEnabled by com.lerzaplayer.config.RemoteConfigManager.enableFeedbackSystem.collectAsState()

    BackHandler(enabled = currentSubScreen != null || showEqualizerSheet) {
        if (showEqualizerSheet) {
            showEqualizerSheet = false
        } else {
            currentSubScreen = null
        }
    }

    // Direct 10-Band Equalizer Sheet
    if (showEqualizerSheet) {
        EqualizerSheet(
            playerManager = playerManager,
            onDismiss = { showEqualizerSheet = false }
        )
    }

    if (currentSubScreen == "playtime") {
        PlaytimeScreen(
            onBack = { currentSubScreen = null }
        )
        return
    }

    if (currentSubScreen == "theme") {
        ThemeScreen(
            prefManager = prefManager,
            onBack = { currentSubScreen = null }
        )
        return
    }

        // Replacement Option for Scan Media: Sound Quality & Audio Effects
    if (currentSubScreen == "audio_effects") {
        val hiResAudio by prefManager.hiResAudioFlow.collectAsState(initial = true)
        val spatialSurround by prefManager.spatialSurroundFlow.collectAsState(initial = true)
        val gaplessPlayback by prefManager.gaplessPlaybackFlow.collectAsState(initial = true)
        val autoPauseHeadphones by prefManager.autoPauseHeadphonesFlow.collectAsState(initial = true)
        val crossfadeSeconds by prefManager.crossfadeSecondsFlow.collectAsState(initial = 3.0f)
        val vocalBoostLevel by prefManager.vocalBoostFlow.collectAsState(initial = 0)

        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = appStrings.soundQualityTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(activeColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, tint = activeColor, modifier = Modifier.size(22.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(appStrings.hiResTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                                    Text(appStrings.hiResDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                                }
                                Switch(
                                    checked = hiResAudio,
                                    onCheckedChange = {
                                        scope.launch {
                                            prefManager.setHiResAudio(it)
                                            playerManager.setHiResAudio(it)
                                        }
                                    },
                                    colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                                )
                            }
                        }
                    }
                }

                item {
                    SettingsGroupCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.spatialSurroundTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.spatialSurroundDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = spatialSurround,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setSpatialSurround(it)
                                        playerManager.setSpatialSurround(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                        SettingsDivider()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.gaplessTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.gaplessDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = gaplessPlayback,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setGaplessPlayback(it)
                                        playerManager.setGaplessPlayback(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                        SettingsDivider()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.autoPauseTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.autoPauseDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = autoPauseHeadphones,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setAutoPauseHeadphones(it)
                                        playerManager.setAutoPauseHeadphones(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                    }
                }

                // Vocal Booster Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(appStrings.vocalBoosterTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text("${(vocalBoostLevel / 10)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = activeColor)
                            }
                            Text(appStrings.vocalBoosterDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            Slider(
                                value = vocalBoostLevel.toFloat(),
                                onValueChange = {
                                    val safe = it.toInt()
                                    scope.launch {
                                        prefManager.setVocalBoost(safe)
                                        playerManager.setVocalBoost(safe)
                                    }
                                },
                                valueRange = 0f..1000f,
                                colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                            )
                        }
                    }
                }

                // Crossfade Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(appStrings.crossfadeTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text("${crossfadeSeconds.toInt()}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = activeColor)
                            }
                            Text(appStrings.crossfadeDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            Slider(
                                value = crossfadeSeconds,
                                onValueChange = {
                                    scope.launch {
                                        prefManager.setCrossfadeSeconds(it)
                                        playerManager.setCrossfadeSeconds(it)
                                    }
                                },
                                valueRange = 0f..10f,
                                steps = 9,
                                colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                            )
                        }
                    }
                }
            }
        }
        return
    }

    // Language Selection Subscreen (English, Urdu, Hindi)
    if (currentSubScreen == "language") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "App Language • زبان • भाषा",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Select App Language",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Choose between English, Urdu, or Hindi for the app interface",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                }

                item {
                    SettingsGroupCard {
                        AppLanguage.entries.forEachIndexed { index, lang ->
                            val isSelected = activeLang == lang
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch {
                                            prefManager.setAppLanguage(lang.code)
                                            LanguageManager.setLanguage(lang)
                                            Toast.makeText(context, "${lang.displayName} selected", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = lang.nativeName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) activeColor else colors.textPrimary
                                    )
                                    Text(
                                        text = lang.displayName,
                                        fontSize = 12.sp,
                                        color = colors.textSecondary
                                    )
                                }
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(activeColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (index < AppLanguage.entries.size - 1) {
                                SettingsDivider()
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // Backup & Restore Screen
    if (currentSubScreen == "backup_restore") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = appStrings.backupRestoreTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = colors.card,
                    border = BorderStroke(1.dp, activeColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(activeColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = activeColor,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Text(
                            text = appStrings.comingSoon,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textPrimary
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = activeColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = appStrings.waitForUpdate,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = appStrings.backupRestoreNotice,
                            fontSize = 13.sp,
                            color = colors.textSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 19.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { currentSubScreen = null },
                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Text(appStrings.okBack, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
        return
    }

    // 🌟 THEME-MATCHED ABOUT SCREEN (Dynamically matches user's active theme!)
    if (currentSubScreen == "about") {
        val isDark = colors.isDark
        val themeBackground = if (isDark) {
            Brush.verticalGradient(
                colors = listOf(
                    colors.background,
                    activeColor.copy(alpha = 0.05f),
                    colors.background
                )
            )
        } else {
            Brush.verticalGradient(
                colors = listOf(
                    activeColor.copy(alpha = 0.08f),
                    Color(0xFFF8FAFC),
                    activeColor.copy(alpha = 0.03f),
                    Color(0xFFFFFFFF)
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(themeBackground)
        ) {
            // Ambient glowing radial spots matching theme color
            Box(
                modifier = Modifier
                    .size(320.dp)
                    .align(Alignment.TopEnd)
                    .graphicsLayer(alpha = 0.25f)
                    .background(
                        Brush.radialGradient(
                            listOf(activeColor, Color.Transparent)
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.BottomStart)
                    .graphicsLayer(alpha = 0.20f)
                    .background(
                        Brush.radialGradient(
                            listOf(activeColor.copy(alpha = 0.7f), Color.Transparent)
                        )
                    )
            )

            Scaffold(
                topBar = {
                    Surface(
                        color = Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { currentSubScreen = null }) {
                                Icon(
                                    imageVector = LerzaIcons.ArrowBack,
                                    contentDescription = "Back",
                                    tint = colors.textPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = appStrings.aboutTitle,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                    }
                },
                containerColor = Color.Transparent
            ) { padding ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. Top Hero Card (Theme-Matched)
                    item {
                        Surface(
                            shape = RoundedCornerShape(26.dp),
                            color = colors.card.copy(alpha = 0.92f),
                            border = BorderStroke(1.dp, activeColor.copy(alpha = 0.35f)),
                            shadowElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 26.dp, horizontal = 20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Theme-Colored App Icon with White Music Note
                                Box(
                                    modifier = Modifier
                                        .size(76.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(activeColor, activeColor.copy(alpha = 0.75f))
                                            )
                                        )
                                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(22.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }

                                Text(
                                    text = "LerzaPlayer Pro",
                                    fontSize = 25.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = colors.textPrimary,
                                    letterSpacing = (-0.3).sp
                                )

                                // Version 1.0.5 Badge (Theme-Colored)
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = activeColor.copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, activeColor.copy(alpha = 0.45f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(activeColor)
                                        )
                                        Text(
                                            text = if (isUrdu) "ورژن 1.0.5 (2026 باضابطہ ایڈیشن)" else if (isHindi) "संस्करण 1.0.5 (2026 आधिकारिक संस्करण)" else "Version 1.0.5 (2026 Official Edition)",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = activeColor
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = if (isUrdu) "اگلی نسل کا لاس لیس میوزک اور ویڈیو پلیئر" else if (isHindi) "अगली पीढ़ी का दोषरहित संगीत और वीडियो प्लेयर" else "Next-Generation Lossless Music & Video Player",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = colors.textSecondary,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    Text(
                                        text = if (isUrdu) "صوتی شائقین کے لیے تیار کردہ" else if (isHindi) "ऑडियोफाइल्स के लिए विशेष रूप से डिज़ाइन किया गया" else "Engineered for Audiophiles",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = colors.textSecondary,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    // 2. Section Header: PREMIUM FEATURES / Built-in Tools
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isUrdu) "نمایاں خصوصیات" else if (isHindi) "प्रीमियम सुविधाएँ" else "PREMIUM FEATURES",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.textPrimary,
                                letterSpacing = 0.8.sp
                            )
                            val activeFeatures = if (isUrdu) URDU_LERZA_FEATURES else if (isHindi) HINDI_LERZA_FEATURES else LERZA_FEATURES
                            Text(
                                text = if (isUrdu) "${activeFeatures.size} بلٹ ان اوزار" else if (isHindi) "${activeFeatures.size} इन-बिल्ट टूल्स" else "${activeFeatures.size} Built-in Tools",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor
                            )
                        }
                    }

                    // 3. Built-in Tools Feature Cards (Theme-Matched)
                    val activeFeatures = if (isUrdu) URDU_LERZA_FEATURES else if (isHindi) HINDI_LERZA_FEATURES else LERZA_FEATURES
                    items(activeFeatures.size) { index ->
                        val feature = activeFeatures[index]
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = colors.card.copy(alpha = 0.88f),
                            border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Theme gradient rounded square with crisp white icon
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(activeColor, activeColor.copy(alpha = 0.75f))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = feature.icon,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = feature.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = feature.description,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Normal,
                                        color = colors.textSecondary,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }

                    // 4. Developer Footer Card (Theme-Matched)
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = colors.card.copy(alpha = 0.88f),
                            border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 18.dp, horizontal = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Crafted with passion by Faraz",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = if (isUrdu) "ڈیزائن اور ڈیولپمنٹ بذریعہ فراز" else if (isHindi) "फ़राज़ द्वारा लगन से तैयार किया गया" else "Engineered with Precision & Care",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activeColor
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "© 2026 LerzaPlayer Pro • All Rights Reserved",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = colors.textSecondary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // 5. Terms & Conditions / Privacy Policy Link
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = activeColor.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, activeColor.copy(alpha = 0.35f)),
                                modifier = Modifier.clickable { currentSubScreen = "terms_and_conditions" }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = null,
                                        tint = activeColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (isUrdu) "شرائط و ضوابط • رازداری کی پالیسی" else if (isHindi) "नियम व शर्तें • गोपनीयता नीति" else "Terms & Conditions • Privacy Policy",
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = activeColor
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowForward,
                                        contentDescription = null,
                                        tint = activeColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (isUrdu) "قوانین و ضوابط اور پرائیویسی پالیسی پڑھنے کے لیے ٹیپ کریں" else if (isHindi) "नियम, शर्तें और गोपनीयता नीति पढ़ने के लिए टैप करें" else "Tap to read terms, conditions and privacy policy",
                                fontSize = 10.5.sp,
                                color = colors.textSecondary.copy(alpha = 0.75f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }
        return
    }

    // 🌟 DEDICATED TERMS & CONDITIONS & PRIVACY POLICY SCREEN
    if (currentSubScreen == "terms_and_conditions") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = "about" }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Terms & Conditions",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Privacy Policy & User Rights (2026)",
                                fontSize = 11.5.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                }
            },
            containerColor = colors.background
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = activeColor.copy(alpha = 0.15f),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Security,
                                            contentDescription = null,
                                            tint = activeColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Official Privacy & Terms Accord",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = "Last Updated: October 2026 • Valid for All Users",
                                        fontSize = 11.sp,
                                        color = colors.textSecondary
                                    )
                                }
                            }
                            Text(
                                text = "Welcome to LerzaPlayer Pro. By accessing or using this application, you agree to comply with the terms and privacy practices outlined below. LerzaPlayer is built on the philosophy of local-first privacy and audiophile engineering.",
                                fontSize = 12.5.sp,
                                color = colors.textSecondary,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                val termsSections = listOf(
                    Triple(
                        "1. Local Media & Absolute Privacy (مکمل رازداری)",
                        Icons.Default.Lock,
                        "LerzaPlayer operates entirely offline on your local device. Audio, video, and personal media files are indexed and processed strictly within your hardware sandbox. No songs, videos, recordings, or metadata are ever uploaded, synced, or transmitted to any remote servers. Your private data remains solely in your custody."
                    ),
                    Triple(
                        "2. Encrypted Private Vault (محفوظ انکرپٹڈ والٹ)",
                        Icons.Default.EnhancedEncryption,
                        "The Private Vault utilizes device-level SHA-256 and AES hardware-accelerated encryption. The 4-digit security PIN is stored locally with cryptographic hashing. LerzaPlayer does not retain or transmit any master keys or backdoor recovery codes. Users maintain complete responsibility for remembering their security PIN."
                    ),
                    Triple(
                        "3. YouTube In-App Streaming (یوٹیوب اسٹریمنگ)",
                        Icons.Default.PlayCircle,
                        "When using the optional YouTube In-App streaming features, playback is facilitated through compliant media endpoints in accordance with YouTube API Terms of Service. LerzaPlayer does not bypass intellectual property restrictions or enable unauthorized extraction of proprietary content."
                    ),
                    Triple(
                        "4. One-Tap In-App Updates (خودکار اپڈیٹس)",
                        Icons.Default.SystemUpdate,
                        "To deliver seamless performance enhancements and security patches, the app incorporates an optional one-tap update mechanism. Updates are verified through official digital cryptographic signatures. Users can review release notes prior to installation at any time."
                    ),
                    Triple(
                        "5. Audio Amplification & Ear Safety (صوتی تحفظ)",
                        Icons.Default.VolumeUp,
                        "The 300% Volume Boost and 10-Band Graphic Equalizer utilize custom hardware digital signal processors (DSP). While engineered to eliminate digital clipping, prolonged exposure to extreme volume levels can cause hearing impairment. Users are advised to listen at safe, comfortable listening thresholds."
                    ),
                    Triple(
                        "6. Analytics & Advertising Disclosure (تجزیات اور اشتہارات)",
                        Icons.Default.BarChart,
                        "LerzaPlayer integrates Google AdMob strictly for standard app monetization. AdMob may utilize anonymous advertising identifiers in conformity with Google Play Developer policies. No personal media files, vault contents, or listening histories are accessible to advertisers."
                    ),
                    Triple(
                        "7. Intellectual Property & Fair Use (دانشورانہ حقوق)",
                        Icons.Default.Copyright,
                        "Users are responsible for ensuring that all audio and video media files loaded onto their devices comply with applicable copyright and intellectual property legislation. LerzaPlayer serves as a high-fidelity playback client and does not distribute copyrighted musical recordings."
                    ),
                    Triple(
                        "8. Warranty Disclaimer & Developer Attribution (دستبرداری)",
                        Icons.Default.VerifiedUser,
                        "LerzaPlayer is provided on an 'as-is' and 'as-available' basis. Designed and developed with passion by Faraz (ڈیزائن اور ڈیولپمنٹ بذریعہ فراز). For feedback, bug reports, and assistance, please refer to official developer release channels."
                    )
                )

                items(termsSections.size) { index ->
                    val (title, icon, body) = termsSections[index]
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, colors.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = activeColor,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = title,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                            }
                            Text(
                                text = body,
                                fontSize = 12.sp,
                                color = colors.textSecondary,
                                lineHeight = 17.5.sp
                            )
                        }
                    }
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = activeColor.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "© 2026 Lerza Player Pro • All Rights Reserved",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Crafted with dedication by Faraz",
                                fontSize = 11.sp,
                                color = activeColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
        return
    }

    if (currentSubScreen == "recently_deleted") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Recently deleted (${recentlyDeleted.size})",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            if (recentlyDeleted.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (isUrdu) "ری سائیکل بن خالی ہے۔ حذف شدہ فائلیں یہاں 30 دن تک رہتی ہیں۔" else "Trash is empty. Deleted items remain here for 30 days.", color = colors.textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentlyDeleted.size) { idx ->
                        val item = recentlyDeleted[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.card)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onPlayRecentlyDeleted(item) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(activeColor.copy(alpha = 0.2f))
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = activeColor)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.originalName, color = colors.textPrimary, fontSize = 13.sp, maxLines = 1)
                                Text("Auto-deletes in 30 days", color = colors.accent, fontSize = 10.sp)
                            }
                            Button(
                                onClick = { onRestoreRecentlyDeleted(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Restore", fontSize = 11.sp, color = colors.onPrimary)
                            }
                            IconButton(onClick = { onPermanentlyDeleteRecentlyDeleted(item) }) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFFF5252))
                            }
                        }
                    }
                }
            }
        }
        return
    }

    if (currentSubScreen == "notification") {
        val newMediaNotif by prefManager.newMediaNotificationFlow.collectAsState(initial = true)
        val pushNotif by prefManager.mediaPlayerNotificationFlow.collectAsState(initial = true)
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = appStrings.notificationsTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SettingsGroupCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(appStrings.newMediaNotifTitle, fontSize = 15.sp, color = colors.textPrimary)
                            Text(appStrings.newMediaNotifDesc, fontSize = 12.sp, color = colors.textSecondary)
                        }
                        Switch(
                            checked = newMediaNotif,
                            onCheckedChange = { isChecked ->
                                scope.launch {
                                    prefManager.setNewMediaNotification(isChecked)
                                    if (!isChecked) {
                                        NotificationHelper.cancelAllNewMediaNotifications(context)
                                    }
                                    android.widget.Toast.makeText(context, if (isChecked) "New Media Notifications Enabled" else "New Media Notifications Disabled", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                        )
                    }
                    SettingsDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(appStrings.playerTimelineNotifTitle, fontSize = 15.sp, color = colors.textPrimary)
                            Text(appStrings.playerTimelineNotifDesc, fontSize = 12.sp, color = colors.textSecondary)
                        }
                        Switch(
                            checked = pushNotif,
                            onCheckedChange = { isChecked -> scope.launch { prefManager.setMediaPlayerNotification(isChecked)
android.widget.Toast.makeText(context, if (isChecked) "Player Controls Notification Enabled" else "Player Controls Notification Disabled", android.widget.Toast.LENGTH_SHORT).show() } },
                            colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                        )
                    }
                }
            }
        }
        return
    }

    // Main Settings Screen
    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                modifier = Modifier.fillMaxWidth().statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Settings",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Group 1: Playtime & Backup & Restore
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.PlayCircleOutline,
                        title = appStrings.playtimeTitle,
                        badge = livePlaytime,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "playtime"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.CloudSync,
                        title = appStrings.backupRestoreTitle,
                        badge = if (isUrdu) "جلد دستیاب ہوگا" else "Coming Soon",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "backup_restore"
                        }
                    )
                }
            }

            // Group 2: Theme & Sleep Timer & Equalizer (Opens 10-Band EQ Sheet directly)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.Palette,
                        title = appStrings.themeTitle,
                        badge = ThemeManager.currentThemeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "theme"
                        }
                    )
                    if (isSleepTimerFeatureEnabled) {
                        SettingsDivider()
                        LarkSettingsRow(
                            icon = Icons.Default.Alarm,
                            title = appStrings.sleepTimerTitle,
                            badge = if (sleepMinutes > 0) "$sleepMinutes min" else if (isUrdu) "بند ہے" else "Off",
                            accentColor = activeColor,
                            onClick = {
                                showSleepTimerSheet = true
                            }
                        )
                    }
                    if (isEqFeatureEnabled) {
                        SettingsDivider()
                        LarkSettingsRow(
                            icon = Icons.Default.GraphicEq,
                            title = appStrings.equalizerTitle,
                            badge = "10-Band EQ",
                            accentColor = activeColor,
                            onClick = {
                                showEqualizerSheet = true
                            }
                        )
                    }
                }
            }

            // Group 3: Hidden Files & Recently Deleted & Sound Quality (Replaced Scan Media Library)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.VisibilityOff,
                        title = appStrings.vaultTitle,
                        badge = if (isUrdu) "محفوظ" else "Protected",
                        accentColor = activeColor,
                        onClick = onOpenVault
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.DeleteOutline,
                        title = appStrings.recentlyDeletedTitle,
                        badge = if (isUrdu) "${recentlyDeleted.size} فائلیں" else "${recentlyDeleted.size} files",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "recently_deleted"
                        }
                    )
                    SettingsDivider()
                    // NEW EXTRA TAB replacing "Scan Media Library"
                    LarkSettingsRow(
                        icon = Icons.Default.Tune,
                        title = appStrings.soundQualityTitle,
                        badge = "Hi-Res HD",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "audio_effects"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.NotificationsNone,
                        title = appStrings.notificationsTitle,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "notification"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Language,
                        title = appStrings.languageTitle,
                        badge = activeLang.nativeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "language"
                        }
                    )
                }
            }

            // Group 4: About & In-App OTA Update Check
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.SystemUpdate,
                        title = appStrings.checkForUpdatesTitle,
                        badge = if (isUrdu) "ابھی چیک کریں" else "Check now",
                        accentColor = activeColor,
                        onClick = {
                            scope.launch {
                                Toast.makeText(context, if (isUrdu) "سرور سے اپ ڈیٹس چیک کی جا رہی ہیں..." else "Checking server for updates...", Toast.LENGTH_SHORT).show()
                                val update = AppUpdateManager.checkForUpdates(context)
                                if (update == null) {
                                    Toast.makeText(context, if (isUrdu) "آپ پہلے ہی تازہ ترین ورژن استعمال کر رہے ہیں!" else "You are using the latest version!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Info,
                        title = appStrings.aboutTitle,
                        badge = "v1.0.5 • 2026",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "about"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Feedback,
                        title = if (activeLang == AppLanguage.URDU) "فیڈ بیک بھیجیں" else if (activeLang == AppLanguage.HINDI) "प्रतिक्रिया भेजें" else "Send Feedback",
                        badge = if (!isFeedbackFeatureEnabled) (if (isUrdu) "معطل" else "Paused") else (if (activeLang == AppLanguage.URDU) "براہِ راست" else if (activeLang == AppLanguage.HINDI) "डायरेक्ट" else "Direct"),
                        accentColor = activeColor,
                        onClick = {
                            if (isFeedbackFeatureEnabled) {
                                showFeedbackDialog = true
                            } else {
                                Toast.makeText(context, if (isUrdu) "فیڈ بیک سسٹم عارضی طور پر معطل ہے۔" else "Feedback system is temporarily paused.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
    }

    if (showSleepTimerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = colors.surface,
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 30.dp)
            ) {
                Text(
                    text = appStrings.sleepTimerTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(18.dp))
                SleepTimerOptionRow(
                    title = if (isUrdu) "بند کریں" else "Turn off",
                    isSelected = sleepMinutes == 0,
                    accentColor = activeColor,
                    onClick = {
                        playerManager.setSleepTimer(0)
                        showSleepTimerSheet = false
                    }
                )
                listOf(10, 20, 30, 60).forEach { mins ->
                    SleepTimerOptionRow(
                        title = if (isUrdu) "$mins منٹ بعد" else "$mins minutes later",
                        isSelected = sleepMinutes == mins,
                        accentColor = activeColor,
                        onClick = {
                            playerManager.setSleepTimer(mins)
                            showSleepTimerSheet = false
                            Toast.makeText(context, if (isUrdu) "پلے بیک $mins منٹ بعد رک جائے گا" else "Playback will pause in $mins minutes", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    if (showFeedbackDialog) {
        FeedbackDialog(
            accentColor = activeColor,
            onDismiss = { showFeedbackDialog = false }
        )
    }
}

@Composable
private fun SettingsGroupCard(content: @Composable ColumnScope.() -> Unit) {
    val colors = LocalLerzaColors.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            content()
        }
    }
}

@Composable
private fun LarkSettingsRow(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (badge != null) {
            Text(
                text = badge,
                fontSize = 13.sp,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = colors.textSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    val colors = LocalLerzaColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(0.6.dp)
            .background(colors.divider)
    )
}

@Composable
private fun SleepTimerOptionRow(
    title: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isSelected) accentColor else colors.textPrimary
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = accentColor)
        }
    }
}