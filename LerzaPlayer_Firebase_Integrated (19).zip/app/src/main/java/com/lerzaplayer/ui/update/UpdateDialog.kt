package com.lerzaplayer.ui.update

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Sparkles
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lerzaplayer.update.AppUpdateManager
import com.lerzaplayer.update.UpdateInfo

/**
 * Ultra-Modern Luxury Glassmorphic Update Modal
 * Supports both Optional ("Later" + "Update") and Mandatory / Force Update ("Update Now" only).
 * If Force Update is active, back press & outside dismissal are strictly disabled.
 */
@Composable
fun UpdateDialog(
    updateInfo: UpdateInfo,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isMandatory = updateInfo.isForceUpdate

    Dialog(
        onDismissRequest = {
            if (!isMandatory) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = !isMandatory,
            dismissOnClickOutside = !isMandatory,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(32.dp),
                color = Color(0xFF0F121C),
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .shadow(36.dp, RoundedCornerShape(32.dp), spotColor = if (isMandatory) Color(0xFFFF416C) else Color(0xFF8B5CF6))
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(
                            colors = if (isMandatory) listOf(
                                Color(0xFFFF416C).copy(alpha = 0.8f),
                                Color(0xFFFF4B2B).copy(alpha = 0.4f),
                                Color.Transparent
                            ) else listOf(
                                Color(0xFFA855F7).copy(alpha = 0.8f),
                                Color(0xFF06B6D4).copy(alpha = 0.5f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(32.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Glowing Orb Icon
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isMandatory) listOf(
                                        Color(0xFFFF416C),
                                        Color(0xFF800E13)
                                    ) else listOf(
                                        Color(0xFFA855F7),
                                        Color(0xFF4C1D95)
                                    )
                                )
                            )
                            .border(
                                width = 2.dp,
                                brush = Brush.linearGradient(
                                    listOf(Color.White.copy(alpha = 0.6f), Color.Transparent)
                                ),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMandatory) Icons.Default.Lock else Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Badge Pill
                    Surface(
                        color = if (isMandatory) Color(0xFFFF416C).copy(alpha = 0.18f) else Color(0xFF8B5CF6).copy(alpha = 0.18f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isMandatory) Color(0xFFFF416C).copy(alpha = 0.4f) else Color(0xFF8B5CF6).copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (isMandatory) "CRITICAL MANDATORY UPDATE" else "NEW VERSION AVAILABLE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp,
                                color = if (isMandatory) Color(0xFFFF6B8B) else Color(0xFFC084FC)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Title
                    Text(
                        text = if (isMandatory) "Update Required to Continue" else updateInfo.releaseTitle.ifBlank { "New Update Available!" },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Subtitle / Description
                    Text(
                        text = if (isMandatory) {
                            "This older build of Lerza Player is discontinued. Please update to Build ${updateInfo.versionCode} to continue enjoying music playback and latest features without interruptions."
                        } else {
                            "A newer version (Build ${updateInfo.versionCode}) of Lerza Player is ready! Enjoy improved audio fidelity, faster playback, and new features."
                        },
                        fontSize = 13.5.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(26.dp))

                    // Action Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // If it's NOT mandatory, allow "Later"
                        if (!isMandatory) {
                            OutlinedButton(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFF94A3B8)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                            ) {
                                Text(
                                    text = "Later",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }

                        // Primary "Update Now" Action
                        Button(
                            onClick = {
                                AppUpdateManager.openUpdateWebsite(context)
                                if (!isMandatory) {
                                    onDismiss()
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isMandatory) Color(0xFFFF416C) else Color(0xFF8B5CF6)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
                            modifier = Modifier
                                .weight(if (isMandatory) 1f else 1.4f)
                                .height(50.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "Update Now",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
