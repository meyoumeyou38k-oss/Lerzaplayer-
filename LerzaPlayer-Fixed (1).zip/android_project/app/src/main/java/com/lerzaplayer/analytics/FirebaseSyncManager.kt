import android.net.ConnectivityManager
import android.net.NetworkCapabilities
package com.lerzaplayer.analytics

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.lerzaplayer.config.RemoteConfigManager
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.playback.PlaytimeTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * FirebaseSyncManager - Replaces all third-party endpoints with Cloud Firestore.
 * 100% Google Cloud / Firebase native storage without external tokens or servers.
 * Collects hardware telemetry, language, country/region, and listening habits.
 */
object FirebaseSyncManager {

    private const val TAG = "FirebaseSyncManager"
    private const val PREFS_NAME = "lerza_analytics_prefs"
    private const val KEY_PERM_ID = "perm_device_id"
    private const val KEY_FCM_TOKEN = "cached_fcm_token"
    private const val KEY_LAST_SYNC_MS = "last_sync_timestamp"

    private val _isDeviceBlocked = MutableStateFlow(false)
    val isDeviceBlocked: StateFlow<Boolean> = _isDeviceBlocked.asStateFlow()

    private val _blockedReason = MutableStateFlow("Access has been restricted by the administrator.")
    val blockedReason: StateFlow<String> = _blockedReason.asStateFlow()

    private var syncJob: Job? = null
    private var isInitialized = false

        /**
     * Checks if active network has internet capability.
     */
    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }
    @SuppressLint("HardwareIds")
    fun getPermanentDeviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cached = prefs.getString(KEY_PERM_ID, null)
        if (!cached.isNullOrBlank()) return cached

        var deviceId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (e: Exception) {
            null
        }

        if (deviceId.isNullOrBlank() || deviceId == "9774d56d682e549c") {
            deviceId = UUID.randomUUID().toString().replace("-", "").take(16)
        }

        val finalId = "dev_$deviceId"
        prefs.edit().putString(KEY_PERM_ID, finalId).apply()
        return finalId
    }

    /**
     * Resolves user country code from device Locale or Network.
     * Returns ISO 2-letter uppercase country code (e.g., PK, IN, US, SA, AE, GB).
     */
    fun getDeviceCountryCode(context: Context): String {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
            val simCountry = tm?.simCountryIso?.uppercase(Locale.ROOT)
            if (!simCountry.isNullOrBlank() && simCountry.length == 2) {
                return simCountry
            }
            val netCountry = tm?.networkCountryIso?.uppercase(Locale.ROOT)
            if (!netCountry.isNullOrBlank() && netCountry.length == 2) {
                return netCountry
            }
            val localeCountry = Locale.getDefault().country.uppercase(Locale.ROOT)
            if (localeCountry.isNotBlank() && localeCountry.length == 2) {
                return localeCountry
            }
            "PK"
        } catch (e: Exception) {
            "PK"
        }
    }

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true
        val appContext = context.applicationContext

        // Retrieve FCM Token asynchronously
        fetchAndStoreFcmToken(appContext)

        // Initial Firestore sync (immediate registration on app open)
        syncNow(appContext)

        // Listen for device block status in real-time
        listenToDeviceStatus(appContext)

        // 🌟 20-Minute Scheduled Heartbeat & Playtime Sync
        // Updates device playtime (audio & video minutes) and online status every 20 minutes while app is running
        syncJob?.cancel()
        syncJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                delay(20 * 60 * 1000L) // Exactly 20 minutes
                Log.d(TAG, "20-minute scheduled sync: updating playtime minutes in Firestore...")
                performSync(appContext, isHeartbeat = true)
            }
        }
    }

    fun syncNow(context: Context) {
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            performSync(appContext, isHeartbeat = false)
        }
    }

    fun updateFcmToken(context: Context, token: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_FCM_TOKEN, token).apply()

        // Sync token directly to Firestore device document
        val deviceId = getPermanentDeviceId(context)
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("devices").document(deviceId)
                .set(mapOf("fcm_token" to token, "last_active_time" to FieldValue.serverTimestamp()), SetOptions.merge())
                .addOnSuccessListener {
                    Log.d(TAG, "FCM token synced successfully to Firestore.")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating FCM token to Firestore: ${e.message}")
        }
    }

    private fun fetchAndStoreFcmToken(context: Context) {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    if (!token.isNullOrBlank()) {
                        updateFcmToken(context, token)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseMessaging not available or initial token fetch failed: ${e.message}")
        }
    }

    private fun listenToDeviceStatus(context: Context) {
        try {
            val deviceId = getPermanentDeviceId(context)
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("devices").document(deviceId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error listening to device status: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val blocked = snapshot.getBoolean("is_blocked") ?: false
                        val reason = snapshot.getString("blocked_reason") ?: "Access restricted by administrator."
                        _isDeviceBlocked.value = blocked
                        _blockedReason.value = reason
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up device snapshot listener: ${e.message}")
        }
    }

    private fun performSync(context: Context, isHeartbeat: Boolean) {
        if (!RemoteConfigManager.enablePlaytimeTracking.value) {
            Log.d(TAG, "Playtime tracking is currently paused via Firebase Remote Config.")
            return
        }

        try {
            val deviceId = getPermanentDeviceId(context)
            val countryCode = getDeviceCountryCode(context)
            val manufacturer = Build.MANUFACTURER?.replaceFirstChar { it.uppercase() } ?: "Android"
            val rawModel = Build.MODEL ?: "Device"
            val deviceModel = if (rawModel.startsWith(manufacturer, ignoreCase = true)) {
                rawModel
            } else {
                "$manufacturer $rawModel"
            }
            val androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
            val appVersion = try {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0.5"
            } catch (e: Exception) {
                "1.0.5"
            }
            val appLang = try {
                LanguageManager.currentLanguage.value.code
            } catch (e: Exception) {
                "ur"
            }

            val playtimePrefs = context.getSharedPreferences("lerza_playtime_prefs", Context.MODE_PRIVATE)
            val musicMs = playtimePrefs.getLong("total_music_ms", 0L)
            val videoMs = playtimePrefs.getLong("total_video_ms", 0L)
            val audioMinutes = (musicMs / 60000L).toInt()
            val videoMinutes = (videoMs / 60000L).toInt()
            val totalMinutes = audioMinutes + videoMinutes
            val todayMusicMinutes = (PlaytimeTracker.getTodayPlaytimeMs(context) / 60000L).toInt()
            val monthMusicMinutes = (PlaytimeTracker.getMonthPlaytimeMs(context) / 60000L).toInt()

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val cachedFcmToken = prefs.getString(KEY_FCM_TOKEN, "")
            val firstInstallTime = try {
                context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
            } catch (e: Exception) {
                System.currentTimeMillis()
            }

            val deviceData = mutableMapOf<String, Any>(
                "device_id" to deviceId,
                "country_code" to countryCode,
                "device_model" to deviceModel,
                "device_manufacturer" to manufacturer,
                "android_version" to androidVersion,
                "app_version" to appVersion,
                "app_language" to appLang,
                "audio_playtime_minutes" to audioMinutes,
                "video_playtime_minutes" to videoMinutes,
                "total_playtime_minutes" to totalMinutes,
                "today_music_minutes" to todayMusicMinutes,
                "month_music_minutes" to monthMusicMinutes,
                "first_install_time" to firstInstallTime,
                "last_active_time" to FieldValue.serverTimestamp()
            )

            if (!cachedFcmToken.isNullOrBlank()) {
                deviceData["fcm_token"] = cachedFcmToken
            }

            if (!isHeartbeat) {
                deviceData["session_count"] = FieldValue.increment(1)
            }

            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("devices").document(deviceId)
                .set(deviceData, SetOptions.merge())
                .addOnSuccessListener {
                    prefs.edit().putLong(KEY_LAST_SYNC_MS, System.currentTimeMillis()).apply()
                    Log.d(TAG, "Device data & playtime synced directly to Firebase Firestore [devices/$deviceId] country=$countryCode")
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Firestore sync failed (offline or network error): ${e.message}")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Firestore sync: ${e.message}")
        }
    }
}
