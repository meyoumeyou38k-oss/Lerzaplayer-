package com.lerzaplayer.ui.settings

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lerzaplayer.data.feedback.FeedbackManager
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Ultra-Modern Glassmorphic Feedback & Review Dialog
 * Stores directly in Firebase Cloud Firestore collection: 'feedback'
 * With full support for Star Ratings, Category tags, Contact info, and real-time synchronization.
 */
@Composable
fun FeedbackDialog(
    accentColor: Color = Color(0xFF8B5CF6),
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedRating by remember { mutableStateOf(5) }
    var selectedCategory by remember { mutableStateOf("Feedback") }
    var feedbackText by remember { mutableStateOf("") }
    var contactInfo by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }

    val locale = Locale.getDefault().language
    val isUrdu = locale.startsWith("ur")
    val isHindi = locale.startsWith("hi")

    val categories = if (isUrdu) {
        listOf("فیڈ بیک", "نئی تجویز", "مسئلہ / بگ", "تعریف")
    } else if (isHindi) {
        listOf("प्रतिक्रिया", "नया सुझाव", "समस्या / बग", "समीक्षा")
    } else {
        listOf("Feedback", "Suggestion", "Bug Report", "Appreciation")
    }

    Dialog(
        onDismissRequest = { if (!isSending) onDismiss() },
        properties = DialogProperties(
            dismissOnBackPress = !isSending,
            dismissOnClickOutside = !isSending,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.72f))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(32.dp),
                color = Color(0xFF0F131F),
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .shadow(32.dp, RoundedCornerShape(32.dp), spotColor = accentColor.copy(alpha = 0.6f))
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                accentColor.copy(alpha = 0.8f),
                                Color(0xFF06B6D4).copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(32.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isSuccess) {
                        // Success Screen
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = 0.18f))
                                .border(1.5.dp, Color(0xFF10B981), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = if (isUrdu) "بہت بہت شکریہ!" else if (isHindi) "बहुत-बहुत धन्यवाद!" else "Feedback Received!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isUrdu) 
                                "آپ کا فیڈ بیک ہمارے پاس فائر بیس کلاؤڈ ڈیٹا بیس میں کامیابی سے محفوظ ہو گیا ہے۔ ہم ہر فیڈ بیک کو دیکھ کر ایپ کو مزید بہتر بناتے ہیں۔" 
                            else if (isHindi) 
                                "आपकी प्रतिक्रिया हमारे पास फायरबेस क्लाउड डेटाबेस में सुरक्षित रूप से दर्ज कर ली गई है। धन्यवाद!" 
                            else 
                                "Your review has been successfully stored in our Firebase database. We review every suggestion to improve Lerza Player!",
                            fontSize = 13.5.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(26.dp))

                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text(
                                text = if (isUrdu) "مکمل ہوا" else if (isHindi) "ठीक है" else "Done",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    } else {
                        // Header with Close Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(accentColor.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RateReview,
                                        contentDescription = null,
                                        tint = accentColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isUrdu) "فیڈ بیک اور تجاویز" else if (isHindi) "प्रतिक्रिया व सुझाव" else "Feedback & Review",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isUrdu) "ہمیں اپنی رائے سے آگاہ کریں" else if (isHindi) "अपनी बहुमूल्य राय साझा करें" else "Help us make Lerza Player better",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.08f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color.White.copy(alpha = 0.7f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Category Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            categories.forEach { cat ->
                                val isSelected = selectedCategory == cat
                                Surface(
                                    onClick = { selectedCategory = cat },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) accentColor.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) accentColor else Color.White.copy(alpha = 0.08f)
                                    ),
                                    modifier = Modifier.weight(1f).height(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = cat,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Star Rating Card
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF161B2E),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    for (starIndex in 1..5) {
                                        val isFilled = starIndex <= selectedRating
                                        Icon(
                                            imageVector = if (isFilled) Icons.Default.Star else Icons.Outlined.StarOutline,
                                            contentDescription = "Rating $starIndex",
                                            tint = if (isFilled) Color(0xFFFFB800) else Color(0xFF475569),
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clickable(
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    indication = null
                                                ) {
                                                    selectedRating = starIndex
                                                }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                val ratingLabel = when (selectedRating) {
                                    1 -> "⭐ 1 Star (Very Poor)"
                                    2 -> "⭐⭐ 2 Stars (Needs Work)"
                                    3 -> "⭐⭐⭐ 3 Stars (Average)"
                                    4 -> "⭐⭐⭐⭐ 4 Stars (Good!)"
                                    else -> "⭐⭐⭐⭐⭐ 5 Stars (Excellent!)"
                                }
                                Text(
                                    text = ratingLabel,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFFFB800)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Message Box
                        OutlinedTextField(
                            value = feedbackText,
                            onValueChange = { feedbackText = it },
                            placeholder = {
                                Text(
                                    if (isUrdu) "اپنی رائے، تجویز یا مسئلہ یہاں لکھیں..." 
                                    else if (isHindi) "अपनी प्रतिक्रिया, सुझाव या बग रिपोर्ट यहाँ लिखें..." 
                                    else "Describe your feedback, feature request or issue...",
                                    color = Color(0xFF64748B),
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF131828),
                                unfocusedContainerColor = Color(0xFF131828),
                                focusedBorderColor = accentColor,
                                unfocusedBorderColor = Color(0xFF28324A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            maxLines = 5
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Contact Box
                        OutlinedTextField(
                            value = contactInfo,
                            onValueChange = { contactInfo = it },
                            placeholder = {
                                Text(
                                    if (isUrdu) "نام یا ای میل (اختیاری)" 
                                    else if (isHindi) "नाम या ईमेल (वैकल्पिक)" 
                                    else "Your Name or Email (Optional)",
                                    color = Color(0xFF64748B),
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Default.MailOutline, null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF131828),
                                unfocusedContainerColor = Color(0xFF131828),
                                focusedBorderColor = accentColor,
                                unfocusedBorderColor = Color(0xFF28324A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Send Button
                        Button(
                            onClick = {
                                if (feedbackText.trim().isBlank()) {
                                    val emptyMsg = if (isUrdu) "براہ کرم پہلے کچھ لکھیں" else if (isHindi) "कृपया पहले कुछ लिखें" else "Please enter your message first"
                                    Toast.makeText(context, emptyMsg, Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                isSending = true
                                scope.launch {
                                    val fullMessage = "[Category: $selectedCategory] " + feedbackText.trim()
                                    val result = FeedbackManager.sendFeedback(
                                        context = context,
                                        message = fullMessage,
                                        rating = selectedRating,
                                        userContact = contactInfo.trim()
                                    )
                                    isSending = false
                                    // Feedback is stored in Firebase Cloud Firestore
                                    isSuccess = true
                                }
                            },
                            enabled = !isSending,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            if (isSending) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(if (isUrdu) "بھیجا جا رہا ہے..." else if (isHindi) "भेजा जा रहा है..." else "Submitting...", color = Color.White)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isUrdu) "فیڈ بیک بھیجیں" else if (isHindi) "प्रतिक्रिया भेजें" else "Submit Feedback",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
