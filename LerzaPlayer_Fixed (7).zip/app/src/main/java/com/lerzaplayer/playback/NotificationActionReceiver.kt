package com.lerzaplayer.playback

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver for handling media notification actions reliably across all Android versions
 * (Android 8 to 15), avoiding foreground service start restrictions.
 */
class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val playerManager = PlayerManager.getInstance(context)

        when (action) {
            PlaybackService.ACTION_CLOSE, PlaybackService.ACTION_STOP -> {
                // Immediately stop audio playback and clear queue
                runCatching {
                    playerManager.pause()
                    playerManager.clearQueue()
                }
                // Dismiss notification immediately from system tray
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                nm?.cancel(NotificationHelper.NOTIFICATION_ID)

                // Instruct service to cleanly terminate and remove foreground
                val serviceIntent = Intent(context, PlaybackService::class.java).apply {
                    this.action = PlaybackService.ACTION_CLOSE
                }
                runCatching { context.startService(serviceIntent) }
            }

            PlaybackService.ACTION_FAVORITE -> {
                val song = playerManager.currentSong.value ?: return
                val newFav = !song.isFavorite

                // Toggle favorite in PlayerManager memory and state flows
                playerManager.updateFavoriteStatus(song.id, newFav)

                // Persist favorite toggle in Room database (Room Flow will automatically notify MediaRepository & UI)
                CoroutineScope(Dispatchers.IO).launch {
                    val favDao = AppDatabase.getDatabase(context).favoriteDao()
                    if (!newFav) {
                        favDao.removeFavorite(song.id, "AUDIO")
                    } else {
                        favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                    }
                }

                // Forward to service with already_toggled=true to refresh notification icon immediately without double-inverting
                val favIntent = Intent(context, PlaybackService::class.java).apply {
                    this.action = PlaybackService.ACTION_FAVORITE
                    putExtra("already_toggled", true)
                }
                runCatching { context.startService(favIntent) }
            }

            PlaybackService.ACTION_PLAY -> playerManager.play()
            PlaybackService.ACTION_PAUSE -> playerManager.pause()
            PlaybackService.ACTION_NEXT -> playerManager.playNextTrack()
            PlaybackService.ACTION_PREV -> playerManager.playPreviousTrack()
        }
    }
}
