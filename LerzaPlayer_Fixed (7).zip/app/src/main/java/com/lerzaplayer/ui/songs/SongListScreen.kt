package com.lerzaplayer.ui.songs

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow
import com.lerzaplayer.config.RemoteConfigManager
import com.lerzaplayer.ads.NativeAdFeedItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * 🌟 High Performance Song List with Lark Player Style Fast Scrollbar Handle (ڈنڈا):
 * - Buttery-smooth 120 FPS fling scrolling physics.
 * - Draggable side scroll thumb (ڈنڈا) moves in sync with scrolling and can be dragged directly by finger.
 * - Auto-fades after 1.2s of inactivity so it leaves the screen clean and unobstructed.
 * - Positioned safely on the far right edge so 3-dots action menu buttons remain completely unblocked.
 */
@Composable
fun SongListScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    currentSort: SortOption,
    selectedSongIds: Set<Long>,
    isMultiSelectMode: Boolean,
    densityScale: Float = 1.15f,
    onSongClick: (SongItem, Int) -> Unit,
    onToggleSelect: (Long) -> Unit,
    onStartMultiSelect: (Long) -> Unit,
    onSortChanged: (SortOption) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onPlayNext: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    onAddToPlaylist: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var sortMenuExpanded by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    val currentLang by com.lerzaplayer.data.language.LanguageManager.currentLanguage.collectAsState()
    val isUrdu = currentLang == com.lerzaplayer.data.language.AppLanguage.URDU

    val songsListAdInterval by RemoteConfigManager.songsListAdInterval.collectAsState()
    val showAllAds by RemoteConfigManager.showAllAds.collectAsState()
    val removeAllAds by RemoteConfigManager.removeAllAds.collectAsState()
    val isSongsListAdEnabled by RemoteConfigManager.enableSongsListAd.collectAsState()

    // 🌟 Fast Scroller Handle State Management
    var trackHeightPx by remember { mutableFloatStateOf(1f) }
    var isDraggingThumb by remember { mutableStateOf(false) }
    var isScrollbarVisible by remember { mutableStateOf(false) }
    var autoHideJob by remember { mutableStateOf<Job?>(null) }

    // Show scrollbar handle on scroll or drag, auto-fade after 1.2 seconds of stillness
    val isScrolling = listState.isScrollInProgress
    LaunchedEffect(isScrolling, isDraggingThumb) {
        if (isScrolling || isDraggingThumb) {
            autoHideJob?.cancel()
            isScrollbarVisible = true
        } else {
            autoHideJob?.cancel()
            autoHideJob = scope.launch {
                delay(1200)
                isScrollbarVisible = false
            }
        }
    }

    val scrollbarAlpha by animateFloatAsState(
        targetValue = if (isScrollbarVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 200),
        label = "scrollbarAlpha"
    )

    // Calculate current scroll fraction
    val totalSongs = songs.size.coerceAtLeast(1)
    val firstVisible = listState.firstVisibleItemIndex
    val scrollProgress = (firstVisible.toFloat() / totalSongs.toFloat()).coerceIn(0f, 1f)

    Column(modifier = modifier.fillMaxSize()) {
        // Top Header: Song Count & Sort Dropdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isUrdu) "${songs.size} گانے دستیاب ہیں" else "${songs.size} Songs Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.card)
                        .clickable { sortMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SwapVert,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )

                    val activeSortLabel = if (isUrdu) {
                        when (currentSort) {
                            SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                            SortOption.DATE_ADDED_DESC -> "تاریخ"
                            SortOption.TITLE_ASC -> "عنوان"
                            SortOption.ARTIST_ASC -> "فنکار"
                            SortOption.DURATION_DESC -> "دورانیہ"
                            SortOption.SIZE_DESC -> "سائز"
                        }
                    } else currentSort.displayName

                    Text(
                        text = if (isUrdu) "ترتیب: $activeSortLabel" else "Sort: $activeSortLabel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.textPrimary
                    )

                    Icon(
                        imageVector = LerzaIcons.ArrowDropDown,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    SortOption.values().forEach { option ->
                        val optName = if (isUrdu) {
                            when (option) {
                                SortOption.FAVORITES_FIRST -> "پسندیدہ پہلے ❤️"
                                SortOption.DATE_ADDED_DESC -> "شامل کرنے کی تاریخ"
                                SortOption.TITLE_ASC -> "عنوان (الف تا ے)"
                                SortOption.ARTIST_ASC -> "فنکار"
                                SortOption.DURATION_DESC -> "دورانیہ"
                                SortOption.SIZE_DESC -> "فائل سائز"
                            }
                        } else option.displayName

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = optName,
                                    fontSize = 13.sp,
                                    color = if (currentSort == option) Color(0xFF1E60F2) else colors.textPrimary
                                )
                            },
                            onClick = {
                                sortMenuExpanded = false
                                onSortChanged(option)
                            }
                        )
                    }
                }
            }
        }

        // List Area with Overlay Draggable Side Handle (ڈنڈا)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { coordinates ->
                    trackHeightPx = coordinates.size.height.toFloat().coerceAtLeast(1f)
                }
        ) {
            // Lark Player Style Ultra-Smooth 120 FPS LazyColumn
            LazyColumn(
                state = listState,
                flingBehavior = ScrollableDefaults.flingBehavior(),
                contentPadding = PaddingValues(
                    bottom = if (isMultiSelectMode) 80.dp else 140.dp
                ),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(
                    items = songs,
                    key = { _, song -> song.id },
                    contentType = { _, _ -> "song_row" }
                ) { index, song ->
                    val isSelected = selectedSongIds.contains(song.id)
                    val isCurrent = currentSong?.id == song.id

                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrent = isCurrent,
                        isMultiSelectActive = isMultiSelectMode,
                        isSelected = isSelected,
                        densityScale = densityScale,
                        isUrdu = isUrdu,
                        onSongClick = { onSongClick(song, index) },
                        onSongLongClick = { onStartMultiSelect(song.id) },
                        onToggleSelect = { onToggleSelect(song.id) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onPlayNext = { onPlayNext(song) },
                        onAddToQueue = { onAddToQueue(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) },
                        onHideInVault = { onHideInVault(song) },
                        onDelete = { onDelete(song) }
                    )

                    if (showAllAds && !removeAllAds && isSongsListAdEnabled) {
                        val interval: Int = songsListAdInterval.coerceAtLeast(2)
                        if ((index + 1) % interval == 0) {
                            NativeAdFeedItem()
                        }
                    }
                }
            }

            // 🌟 Draggable Side Scrollbar Handle (سکرولنگ ڈنڈا):
            // Smoothly glides up and down with scroll; user can touch and drag it anywhere!
            // Inset so it never covers or obstructs 3-dots action buttons!
            if (songs.size > 6 && scrollbarAlpha > 0.01f) {
                val thumbHeightDp = 48.dp
                val thumbHeightPx = with(density) { thumbHeightDp.toPx() }
                val maxTravelPx = max(1f, trackHeightPx - thumbHeightPx - 140f)
                val currentThumbYPx = (scrollProgress * maxTravelPx).coerceIn(0f, maxTravelPx)
                val currentThumbYDp = with(density) { currentThumbYPx.toDp() }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 2.dp, top = 8.dp, bottom = 120.dp)
                        .fillMaxHeight()
                        .width(36.dp) // Generous touch target for easy finger grabbing
                        .graphicsLayer { alpha = scrollbarAlpha }
                        .pointerInput(songs.size, trackHeightPx) {
                            detectVerticalDragGestures(
                                onDragStart = { isDraggingThumb = true },
                                onDragEnd = { isDraggingThumb = false },
                                onDragCancel = { isDraggingThumb = false },
                                onVerticalDrag = { change, _ ->
                                    change.consume()
                                    val touchY = change.position.y.coerceIn(0f, maxTravelPx)
                                    val progress = (touchY / maxTravelPx).coerceIn(0f, 1f)
                                    val targetIndex = (progress * (songs.size - 1)).toInt().coerceIn(0, songs.size - 1)
                                    scope.launch {
                                        listState.scrollToItem(targetIndex)
                                    }
                                }
                            )
                        }
                ) {
                    // Subtle background track
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 4.dp)
                            .width(2.5.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(2.dp))
                            .background(colors.card.copy(alpha = 0.45f))
                    )

                    // Floating Draggable Handle Pill (ڈنڈا)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(y = currentThumbYDp)
                            .padding(end = 2.dp)
                            .width(6.dp)
                            .height(thumbHeightDp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(colors.primary)
                            .shadow(3.dp, RoundedCornerShape(3.dp))
                    )
                }
            }
        }
    }
}
